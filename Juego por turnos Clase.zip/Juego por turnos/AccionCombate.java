import greenfoot.*;

/**
 * Representa una accion de combate como un objeto:
 * nombre, danio y probabilidad de acierto (0-100).
 */
public class AccionCombate
{
    private String nombre;
    private int danio;
    private int probabilidadAcierto;

    public AccionCombate(String nombre, int danio, int probabilidadAcierto)
    {
        this.nombre = nombre;
        this.danio = danio;
        this.probabilidadAcierto = probabilidadAcierto;
    }

    public String getNombre() { return nombre; }
    public int getDanio() { return danio; }
    public int getProbabilidadAcierto() { return probabilidadAcierto; }

    /** Tira un numero 0-99 y compara con la probabilidad de acierto. */
    public boolean acierta()
    {
        return Greenfoot.getRandomNumber(100) < probabilidadAcierto;
    }
}
