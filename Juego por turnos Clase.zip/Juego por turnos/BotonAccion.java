import greenfoot.*;

/**
 * Boton visual de una accion.
 * Pulsa suavemente cuando esta habilitado (comunica "puedes usarme")
 * y llama al gestor cuando se hace clic.
 */
public class BotonAccion extends Actor
{
    private AccionCombate accion;
    private GestorCombate gestor;
    private boolean habilitado = true;
    private int pulso = 0;

    public BotonAccion(AccionCombate accion, GestorCombate gestor)
    {
        this.accion = accion;
        this.gestor = gestor;
        actualizarImagen();
    }

    public void act()
    {
        if (habilitado)
        {
            pulso = (pulso + 1) % 20;
            actualizarImagen();
        }

        if (habilitado && Greenfoot.mouseClicked(this))
        {
            gestor.seleccionarAccion(accion);
        }
    }

    public void setHabilitado(boolean valor)
    {
        habilitado = valor;
        actualizarImagen();
    }

    private void actualizarImagen()
    {
        String texto = accion.getNombre()
            + "\nDanio: " + accion.getDanio()
            + " | Acierto: " + accion.getProbabilidadAcierto() + " %";

        Color fondo = habilitado ? Color.DARK_GRAY : Color.GRAY;
        GreenfootImage img = new GreenfootImage(texto, 20, Color.WHITE, fondo);

        if (habilitado && pulso >= 10)
            img.setTransparency(210);

        setImage(img);
    }
}
