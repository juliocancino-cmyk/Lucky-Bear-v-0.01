import greenfoot.*;

/**
 * Texto animado que comunica el estado actual del combate
 * (tu turno, ejecutando, turno enemigo, victoria/derrota).
 */
public class IndicadorTurno extends Actor
{
    private String texto = "";
    private Color color = Color.WHITE;
    private int pulso = 0;

    public void act()
    {
        pulso = (pulso + 1) % 24;
        actualizar();
    }

    public void mostrar(String texto, Color color)
    {
        this.texto = texto;
        this.color = color;
        actualizar();
    }

    private void actualizar()
    {
        GreenfootImage img = new GreenfootImage(texto, 28, color, Color.BLACK);

        if (pulso >= 12)
            img.setTransparency(205);

        setImage(img);
    }
}
