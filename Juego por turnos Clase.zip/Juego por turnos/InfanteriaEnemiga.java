import greenfoot.*;

/**
 * Combatiente controlado automaticamente por el gestor.
 */
public class InfanteriaEnemiga extends Unidad
{
    public InfanteriaEnemiga()
    {
        super(100);
        setImage(FabricaImagenes.infanteria(Color.RED));
    }
}
