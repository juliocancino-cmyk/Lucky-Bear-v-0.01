import greenfoot.*;

/**
 * Combatiente controlado por el usuario.
 */
public class InfanteriaJugador extends Unidad
{
    public InfanteriaJugador()
    {
        super(100);
        setImage(FabricaImagenes.infanteria(Color.BLUE));
    }
}
