import greenfoot.*;

/**
 * Crea figuras simples para los combatientes.
 * Dibuja una infanteria medieval basica con el color recibido.
 */
public class FabricaImagenes
{
    public static GreenfootImage infanteria(Color color)
    {
        GreenfootImage img = new GreenfootImage(70, 90);

        img.setColor(color);
        img.fillOval(25,  5, 20, 20);   // cabeza
        img.fillRect(23,  4, 24,  8);   // casco
        img.fillRect(22, 28, 26, 35);   // torso
        img.fillRect(23, 63,  8, 24);   // pierna
        img.fillRect(39, 63,  8, 24);   // pierna
        img.fillRect(48, 34, 14,  6);   // brazo

        img.setColor(Color.LIGHT_GRAY);
        img.fillRect(60, 22, 4, 35);    // espada

        img.setColor(Color.DARK_GRAY);
        img.fillOval(4, 32, 22, 30);    // escudo

        return img;
    }
}
