import greenfoot.*;

/**
 * Barra de vida de una unidad. Se redibuja cuando el gestor lo pide.
 */
public class BarraHP extends Actor
{
    private Unidad unidad;

    public BarraHP(Unidad unidad)
    {
        this.unidad = unidad;
        actualizar();
    }

    public void actualizar()
    {
        int ancho = 160;
        int alto = 18;
        GreenfootImage img = new GreenfootImage(ancho, alto);

        img.setColor(Color.DARK_GRAY);
        img.fillRect(0, 0, ancho, alto);

        int anchoVida = (int)(ancho * unidad.proporcionVida());
        img.setColor(Color.GREEN);
        img.fillRect(0, 0, anchoVida, alto);

        img.setColor(Color.WHITE);
        img.drawString(unidad.getHP() + "/" + unidad.getHPMaximo(), 55, 14);

        setImage(img);
    }
}
