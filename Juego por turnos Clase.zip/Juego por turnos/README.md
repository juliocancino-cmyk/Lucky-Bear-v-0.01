# Juego de Combate por Turnos (Greenfoot)

Implementacion de la guia "Desarrollo de un Juego de Combate por Turnos en Greenfoot".

## Como abrirlo

1. Abre Greenfoot.
2. `Scenario > Open...` y selecciona la carpeta **Juego por turnos**.
3. Pulsa **Compile all**.
4. Clic derecho en `JuegoTurnos` > `new JuegoTurnos()`, o simplemente **Run**.

> Si Greenfoot no crea el mundo solo, haz clic derecho sobre la clase `JuegoTurnos`
> en el diagrama y elige `new JuegoTurnos()`.

## Como se juega

- En **TU TURNO** haz clic en uno de los tres botones de accion.
- Cada accion muestra su danio y su probabilidad de acierto:

  | Accion         | Danio | Acierto | Perfil                |
  |----------------|-------|---------|-----------------------|
  | Ataque rapido  | 8     | 90 %    | Seguro, poco danio    |
  | Ataque normal  | 12    | 75 %    | Equilibrado           |
  | Golpe fuerte   | 20    | 50 %    | Alto riesgo/recompensa|

- Tras elegir: animacion -> se resuelve el acierto -> se actualiza el HP -> turno enemigo.
- El combate termina cuando el HP de un combatiente llega a 0 (VICTORIA / DERROTA).

## Arquitectura

```
JuegoTurnos (World)          Crea el escenario y llama a combate.actualizar()
 └─ GestorCombate            Maquina de estados, turnos y resolucion de acciones
     ├─ Unidad (abstract)    HP y comportamiento comun
     │   ├─ InfanteriaJugador
     │   └─ InfanteriaEnemiga
     ├─ AccionCombate        nombre + danio + probabilidad de acierto
     ├─ BotonAccion          Muestra/selecciona una accion (pulsa si esta activa)
     ├─ IndicadorTurno       Estado actual del combate (texto animado)
     ├─ IndicadorObjetivo    Halo detras del objetivo
     ├─ BarraHP              HP restante de cada unidad
     └─ TextoFlotante        "-N HP" / "FALLO"
FabricaImagenes              Dibuja la figura de infanteria
```

### Estados (GestorCombate.Estado)

```
TURNO_JUGADOR -> ANIMANDO_JUGADOR -> TURNO_ENEMIGO -> ANIMANDO_ENEMIGO -> (repite) / FIN
```

`ANIMANDO_*` es la barrera de consistencia: `seleccionarAccion()` ignora clics si el
estado no es `TURNO_JUGADOR`, evitando ejecutar dos acciones en el mismo turno.

## Experimentos de la guia (seccion 26)

- **A - quitar ayudas visuales:** comenta las llamadas a `indicador.mostrar(...)`,
  el pulso en `BotonAccion.act()` y `mostrarResultado(...)`. El juego sigue siendo
  funcional pero mas dificil de entender (funcionalidad != usabilidad).
- **B - cambiar tasas de acierto:** edita el array `acciones` en `GestorCombate.iniciar()`.
- **C - demasiada animacion:** en `animarAtaqueJugador/Enemigo` sube los umbrales
  (por ejemplo 8/16 -> 20/40).
- **D - permitir acciones durante ANIMANDO:** quita el `if (estado != Estado.TURNO_JUGADOR) return;`
  de `seleccionarAccion()` y observa las inconsistencias al hacer varios clics.

## Ideas de extension (seccion 28)

- Accion "Defender" que reduce a la mitad el proximo danio recibido (estado en la `Unidad`).
- Ataque critico: `P(critico)=10%`, `Dcritico=2*D`, con texto distinto.
- Estados temporales: sangrado, aturdimiento, defensa aumentada.
- Combate 2 vs 2: el halo pasa a ser parte del mecanismo de seleccion de objetivo.
