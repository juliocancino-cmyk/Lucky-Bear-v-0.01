import greenfoot.*;

/**
 * Mundo principal del juego de combate por turnos.
 * Solo crea el escenario y delega toda la logica en GestorCombate.
 */
public class JuegoTurnos extends World
{
    private GestorCombate combate;

    public JuegoTurnos()
    {
        super(900, 600, 1);
        combate = new GestorCombate(this);
        combate.iniciar();
    }

    public void act()
    {
        combate.actualizar();
    }
}
