import greenfoot.*;

/**
 * Controla todo el combate: estados, turnos, animaciones y resolucion de acciones.
 *
 * Flujo:
 *   TURNO_JUGADOR -> ANIMANDO_JUGADOR -> TURNO_ENEMIGO -> ANIMANDO_ENEMIGO -> ...
 *   El combate termina (FIN) cuando el HP de alguna unidad llega a 0.
 *
 * El estado ANIMANDO_* actua como barrera de consistencia: impide que el
 * usuario ejecute varias acciones dentro del mismo turno.
 */
public class GestorCombate
{
    public enum Estado
    {
        TURNO_JUGADOR,
        ANIMANDO_JUGADOR,
        TURNO_ENEMIGO,
        ANIMANDO_ENEMIGO,
        FIN
    }

    private JuegoTurnos mundo;
    private InfanteriaJugador jugador;
    private InfanteriaEnemiga enemigo;
    private Estado estado;

    private AccionCombate[] acciones;
    private BotonAccion[] botones;
    private AccionCombate accionActual;
    private AccionCombate accionEnemigo;

    private IndicadorTurno indicador;
    private IndicadorObjetivo halo;
    private BarraHP barraJugador;
    private BarraHP barraEnemigo;

    private int contadorAnimacion = 0;
    private int xJugadorOriginal;
    private int xEnemigoOriginal;

    public GestorCombate(JuegoTurnos mundo)
    {
        this.mundo = mundo;
    }

    // ------------------------------------------------------------------
    // Inicializacion
    // ------------------------------------------------------------------

    public void iniciar()
    {
        jugador = new InfanteriaJugador();
        enemigo = new InfanteriaEnemiga();

        // El halo se agrega primero para que quede DETRAS del enemigo.
        halo = new IndicadorObjetivo();
        mundo.addObject(halo, 680, 280);

        mundo.addObject(jugador, 220, 280);
        mundo.addObject(enemigo, 680, 280);

        xJugadorOriginal = jugador.getX();
        xEnemigoOriginal = enemigo.getX();

        acciones = new AccionCombate[] {
            new AccionCombate("Ataque rapido",  8, 90),
            new AccionCombate("Ataque normal", 12, 75),
            new AccionCombate("Golpe fuerte",  20, 50)
        };

        crearBotones();
        crearIndicador();
        crearBarrasVida();

        estado = Estado.TURNO_JUGADOR;
        actualizarInterfaz();
    }

    private void crearBotones()
    {
        botones = new BotonAccion[acciones.length];

        for (int i = 0; i < acciones.length; i++)
        {
            botones[i] = new BotonAccion(acciones[i], this);
            mundo.addObject(botones[i], 180 + i * 270, 520);
        }
    }

    private void crearIndicador()
    {
        indicador = new IndicadorTurno();
        mundo.addObject(indicador, 450, 50);
    }

    private void crearBarrasVida()
    {
        barraJugador = new BarraHP(jugador);
        barraEnemigo = new BarraHP(enemigo);
        mundo.addObject(barraJugador, 220, 180);
        mundo.addObject(barraEnemigo, 680, 180);
    }

    // ------------------------------------------------------------------
    // Interfaz
    // ------------------------------------------------------------------

    private void actualizarBotones()
    {
        boolean habilitar = estado == Estado.TURNO_JUGADOR;

        for (BotonAccion boton : botones)
            boton.setHabilitado(habilitar);
    }

    private void actualizarBarrasVida()
    {
        barraJugador.actualizar();
        barraEnemigo.actualizar();
    }

    private void actualizarInterfaz()
    {
        actualizarBotones();

        if (estado == Estado.TURNO_JUGADOR)
            indicador.mostrar("TU TURNO - selecciona una accion", Color.GREEN);
        else if (estado == Estado.ANIMANDO_JUGADOR)
            indicador.mostrar("Ejecutando accion...", Color.YELLOW);
        else if (estado == Estado.TURNO_ENEMIGO || estado == Estado.ANIMANDO_ENEMIGO)
            indicador.mostrar("Turno enemigo", Color.RED);
    }

    private void mostrarResultado(String texto, int x, int y, Color color)
    {
        mundo.addObject(new TextoFlotante(texto, color), x, y);
    }

    // ------------------------------------------------------------------
    // Seleccion de accion del jugador
    // ------------------------------------------------------------------

    public void seleccionarAccion(AccionCombate accion)
    {
        // Impide ejecutar dos acciones en el mismo turno.
        if (estado != Estado.TURNO_JUGADOR) return;

        accionActual = accion;
        estado = Estado.ANIMANDO_JUGADOR;
        contadorAnimacion = 0;
        actualizarInterfaz();
    }

    // ------------------------------------------------------------------
    // Maquina de estados (llamada cada ciclo desde JuegoTurnos.act)
    // ------------------------------------------------------------------

    public void actualizar()
    {
        if (estado == Estado.ANIMANDO_JUGADOR)
            animarAtaqueJugador();
        else if (estado == Estado.TURNO_ENEMIGO)
            iniciarTurnoEnemigo();
        else if (estado == Estado.ANIMANDO_ENEMIGO)
            animarAtaqueEnemigo();
    }

    // ------------------------------------------------------------------
    // Ataque del jugador
    // ------------------------------------------------------------------

    private void animarAtaqueJugador()
    {
        contadorAnimacion++;

        if (contadorAnimacion <= 8)
            jugador.setLocation(jugador.getX() + 6, jugador.getY());
        else if (contadorAnimacion <= 16)
            jugador.setLocation(jugador.getX() - 6, jugador.getY());
        else
        {
            jugador.setLocation(xJugadorOriginal, jugador.getY());
            resolverAtaqueJugador();
        }
    }

    private void resolverAtaqueJugador()
    {
        if (accionActual.acierta())
        {
            int danio = accionActual.getDanio();
            enemigo.recibirDanio(danio);
            mostrarResultado("-" + danio + " HP",
                enemigo.getX(), enemigo.getY() - 70, Color.YELLOW);
        }
        else
        {
            mostrarResultado("FALLO",
                enemigo.getX(), enemigo.getY() - 70, Color.WHITE);
        }

        actualizarBarrasVida();

        if (!enemigo.estaViva())
        {
            terminarCombate(true);
            return;
        }

        estado = Estado.TURNO_ENEMIGO;
        actualizarInterfaz();
    }

    // ------------------------------------------------------------------
    // Ataque del enemigo
    // ------------------------------------------------------------------

    private void iniciarTurnoEnemigo()
    {
        AccionCombate[] opciones = {
            new AccionCombate("Corte",     9, 85),
            new AccionCombate("Estocada", 14, 65)
        };

        accionEnemigo = opciones[Greenfoot.getRandomNumber(opciones.length)];

        estado = Estado.ANIMANDO_ENEMIGO;
        contadorAnimacion = 0;
        actualizarInterfaz();
    }

    private void animarAtaqueEnemigo()
    {
        contadorAnimacion++;

        if (contadorAnimacion <= 8)
            enemigo.setLocation(enemigo.getX() - 6, enemigo.getY());
        else if (contadorAnimacion <= 16)
            enemigo.setLocation(enemigo.getX() + 6, enemigo.getY());
        else
        {
            enemigo.setLocation(xEnemigoOriginal, enemigo.getY());
            resolverAtaqueEnemigo();
        }
    }

    private void resolverAtaqueEnemigo()
    {
        if (accionEnemigo.acierta())
        {
            int danio = accionEnemigo.getDanio();
            jugador.recibirDanio(danio);
            mostrarResultado("-" + danio + " HP",
                jugador.getX(), jugador.getY() - 70, Color.RED);
        }
        else
        {
            mostrarResultado("FALLO",
                jugador.getX(), jugador.getY() - 70, Color.WHITE);
        }

        actualizarBarrasVida();

        if (!jugador.estaViva())
        {
            terminarCombate(false);
            return;
        }

        estado = Estado.TURNO_JUGADOR;
        actualizarInterfaz();
    }

    // ------------------------------------------------------------------
    // Fin del combate
    // ------------------------------------------------------------------

    private void terminarCombate(boolean victoria)
    {
        estado = Estado.FIN;
        actualizarBotones();

        String mensaje = victoria ? "VICTORIA" : "DERROTA";
        indicador.mostrar(mensaje, victoria ? Color.GREEN : Color.RED);
        mundo.showText(mensaje, 450, 300);
    }
}
