import greenfoot.*;

/**
 * Halo semitransparente que se coloca detras del objetivo del ataque.
 * Ayuda a responder "a quien voy a atacar".
 */
public class IndicadorObjetivo extends Actor
{
    public IndicadorObjetivo()
    {
        GreenfootImage img = new GreenfootImage(100, 100);
        img.setColor(new Color(255, 255, 0, 80));
        img.fillOval(5, 5, 90, 90);
        setImage(img);
    }
}
