import greenfoot.*;

/**
 * EnemigoPesado (Paso 14): tipo de enemigo con mucha vida y poco movimiento.
 *
 * Demuestra que la arquitectura permite aumentar la dificultad por
 * COMPOSICION DE AMENAZAS y no solo por cantidad de actores.
 * Para usarlo, GestorOleadas.crearEnemigo() puede instanciar esta clase
 * en algunas oleadas en lugar de un SoldadoEnemigo normal.
 */
public class EnemigoPesado extends SoldadoEnemigo
{
    public EnemigoPesado(Jugador jugador)
    {
        super(jugador, 100, 1, 12);
    }
}
