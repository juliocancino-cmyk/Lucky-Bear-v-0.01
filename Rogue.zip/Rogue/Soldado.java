import greenfoot.*;

/**
 * Soldado: clase base con el comportamiento comun de jugador y enemigos.
 *
 * Concern protegido: Modularity / Maintainability.
 * Centraliza vida, velocidad y el ciclo de "recibir danio -> morir",
 * de modo que agregar nuevos tipos de soldado no obliga a reescribir el juego.
 */
public abstract class Soldado extends Actor
{
    protected int vida;
    protected int velocidad;

    public Soldado(int vida, int velocidad)
    {
        this.vida = vida;
        this.velocidad = velocidad;
    }

    public void recibirDanio(int cantidad)
    {
        vida -= cantidad;
        if (vida <= 0)
        {
            morir();
        }
    }

    public int getVida()
    {
        return vida;
    }

    protected void morir()
    {
        World mundo = getWorld();
        if (mundo != null)
        {
            mundo.removeObject(this);
        }
    }
}
