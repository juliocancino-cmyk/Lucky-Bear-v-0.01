import greenfoot.*;

/**
 * JuegoWorld: contiene el sector, inicia los componentes y gestiona el fin de
 * partida. Su act() solo delega en los dos gestores de poblacion
 * (GestorOleadas para naves alien, CampoAsteroides para las rocas) y lleva el
 * puntaje de supervivencia: la logica de dificultad NO vive aqui.
 */
public class JuegoWorld extends World
{
    private Jugador jugador;
    private GestorOleadas gestor;
    private CampoAsteroides campo;

    private int frames;
    private int puntaje;
    private int bajas;
    private boolean terminado;

    public JuegoWorld()
    {
        super(Config.ANCHO_MUNDO, Config.ALTO_MUNDO, 1);
        Greenfoot.setSpeed(55);
        prepararPartida();
    }

    private void prepararPartida()
    {
        removeObjects(getObjects(null));
        setBackground(FabricaImagenes.fondo(getWidth(), getHeight()));
        limpiarCartel();

        frames = 0;
        puntaje = 0;
        bajas = 0;
        terminado = false;

        jugador = new Jugador();
        addObject(jugador, getWidth() / 2, getHeight() / 2);

        gestor = new GestorOleadas(this, jugador);
        campo = new CampoAsteroides(this, gestor);
        addObject(new HUD(this, jugador, gestor), 0, 0);
    }

    public void act()
    {
        if (terminado)
        {
            if (Greenfoot.isKeyDown("r")) prepararPartida();
            return;
        }
        gestor.actualizar();
        campo.actualizar();
        if (++frames % 6 == 0) puntaje++;   // recompensa por sobrevivir
    }

    /** Llamado por SoldadoEnemigo y por Asteroide al ser destruidos. */
    public void registrarBaja(int puntos)
    {
        bajas++;
        puntaje += puntos;
    }

    public void gameOver()
    {
        if (terminado) return;
        terminado = true;
        showText("GAME OVER", getWidth() / 2, getHeight() / 2 - 24);
        showText("Puntaje " + puntaje + "     Bajas " + bajas, getWidth() / 2, getHeight() / 2 + 6);
        showText("Pulsa R para reiniciar", getWidth() / 2, getHeight() / 2 + 34);
    }

    private void limpiarCartel()
    {
        showText(null, getWidth() / 2, getHeight() / 2 - 24);
        showText(null, getWidth() / 2, getHeight() / 2 + 6);
        showText(null, getWidth() / 2, getHeight() / 2 + 34);
    }

    public int getPuntaje() { return puntaje; }
    public int getBajas()   { return bajas; }
}
