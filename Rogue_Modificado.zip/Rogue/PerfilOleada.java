/**
 * PerfilOleada: objeto de valor con TODOS los parametros ya calculados de
 * una oleada. GestorOleadas lo consulta en vez de repartir formulas sueltas.
 *
 * Politica de dificultad (secciones 6, 18 y 23 de la guia), luego reescalada
 * por la VarianteOleada:
 *
 *   Total       Noleada = min(5 + 3w, 80)          * multCantidad   (re-limitado a <= 80)
 *   Simultaneos Nsim    = min(6 + 2w, 35)                            (tope duro, sin multiplicar)
 *   Vida        HP(w)   = 20 + 4w                   * multVida
 *   Velocidad         v = min(1 + w/4, 4)           * multVelocidad
 *   Dano              d = min(4 + w, 15)            * multDanio
 *   Aparicion   I(w)    = max(10, (50 - 3w)         * multIntervalo)
 */
public class PerfilOleada
{
    public final int numero;
    public final VarianteOleada variante;

    public final int totalEnemigos;
    public final int maxSimultaneos;
    public final int vidaBase;
    public final double velocidadBase;
    public final int danioBase;
    public final int intervaloSpawn;

    public PerfilOleada(int numero)
    {
        this.numero = numero;
        this.variante = (numero <= 1) ? VarianteOleada.ESTANDAR : VarianteOleada.aleatoria();

        int w = numero;

        int total = (int) Math.round(Math.min(5 + 3 * w, Config.MAX_TOTAL_POR_OLEADA)
                                     * variante.multCantidad);
        this.totalEnemigos = clamp(total, 6, Config.MAX_TOTAL_POR_OLEADA);

        // El tope simultaneo NO se multiplica: protege la tension memoria/rendimiento.
        this.maxSimultaneos = Math.min(6 + 2 * w, Config.MAX_ENEMIGOS_SIMULTANEOS);

        this.vidaBase = Math.max(10, (int) Math.round((20 + 4 * w) * variante.multVida));
        this.velocidadBase = Math.min(1.0 + w / 4.0, 4.0) * variante.multVelocidad;
        this.danioBase = Math.max(2, (int) Math.round(Math.min(4 + w, 15) * variante.multDanio));
        this.intervaloSpawn = Math.max(10, (int) Math.round((50 - 3 * w) * variante.multIntervalo));
    }

    private static int clamp(int v, int min, int max)
    {
        return Math.max(min, Math.min(max, v));
    }
}
