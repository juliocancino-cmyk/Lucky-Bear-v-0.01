import greenfoot.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 * FabricaImagenes: genera cada figura UNA sola vez y la sirve desde un cache.
 *
 * Driver / concern: Memory usage + Resource lifecycle.
 *   crear una vez  ->  reutilizar muchas veces
 * Ningun actor construye su GreenfootImage en act(). Los sprites de un mismo
 * tipo (p. ej. 35 naves alien, o todos los asteroides medianos) comparten el
 * mismo objeto imagen. El fondo estrellado tambien se genera una unica vez.
 */
public final class FabricaImagenes
{
    private FabricaImagenes() { }

    private static final Map<String, GreenfootImage> CACHE = new HashMap<>();
    private static final GreenfootImage[] EXPLOSION = crearExplosion();

    static
    {
        guardar("jugador",        naveJugador(36));
        guardar("enemigo",        naveAlien(new Color(226, 78, 78),  new Color(120, 28, 28),  30));
        guardar("rapido",         naveAlien(new Color(245, 170, 60), new Color(150, 92, 16),  22));
        guardar("pesado",         naveAlien(new Color(150, 44, 44),  new Color(70, 14, 14),   46));
        guardar("tirador",        naveAlien(new Color(92, 172, 222), new Color(28, 78, 118),  28));
        guardar("elite",          naveElite(new Color(170, 100, 225), new Color(86, 40, 132), 36));
        guardar("bala",           laser(new Color(120, 245, 255), 16, 4));
        guardar("disparoEnemigo", laser(new Color(255, 96, 205), 12, 6));
        guardar("fogonazo",       fogonazo());
        guardar("asteroide3",     asteroide(27));
        guardar("asteroide2",     asteroide(17));
        guardar("asteroide1",     asteroide(10));
    }

    /** Cuadros de la explosion (compartidos, creados una sola vez). */
    public static GreenfootImage[] explosion()
    {
        return EXPLOSION;
    }

    /** Devuelve una imagen cacheada. Nunca crea nada nuevo. */
    public static GreenfootImage obtener(String clave)
    {
        return CACHE.get(clave);
    }

    /** Fondo estrellado: se genera una vez por tamano y se reutiliza. */
    public static GreenfootImage fondo(int ancho, int alto)
    {
        String clave = "fondo_" + ancho + "x" + alto;
        GreenfootImage previo = CACHE.get(clave);
        if (previo != null) return previo;

        GreenfootImage img = new GreenfootImage(ancho, alto);
        img.setColor(new Color(8, 9, 16));
        img.fill();

        img.setColor(new Color(22, 26, 48));
        img.fillOval(-120, alto - 280, 520, 520);
        img.setColor(new Color(30, 20, 44));
        img.fillOval(ancho - 320, -160, 460, 460);

        Random r = new Random(11);   // semilla fija -> estrellas estables
        for (int i = 0; i < 280; i++)
        {
            int x = r.nextInt(ancho);
            int y = r.nextInt(alto);
            int b = 120 + r.nextInt(135);
            img.setColor(new Color(b, b, b));
            int s = (r.nextInt(12) == 0) ? 2 : 1;
            img.fillOval(x, y, s, s);
        }
        img.setColor(new Color(0, 0, 0, 90));
        img.drawRect(1, 1, ancho - 3, alto - 3);
        return guardar(clave, img);
    }

    private static GreenfootImage guardar(String clave, GreenfootImage img)
    {
        CACHE.put(clave, img);
        return img;
    }

    /** Nave del jugador: cuneiforme apuntando a la derecha (rotacion 0). */
    private static GreenfootImage naveJugador(int s)
    {
        GreenfootImage img = new GreenfootImage(s, s);
        int[] xs = { s - 2, 5, 12, 5 };
        int[] ys = { s / 2, 4, s / 2, s - 4 };

        img.setColor(new Color(255, 170, 70));                 // llama de motor
        img.fillPolygon(new int[] { 6, 13, 6 },
                        new int[] { s / 2 - 5, s / 2, s / 2 + 5 }, 3);
        img.setColor(new Color(26, 92, 84));                   // casco (borde)
        img.fillPolygon(new int[] { s - 1, 3, 11, 3 },
                        new int[] { s / 2, 2, s / 2, s - 2 }, 4);
        img.setColor(new Color(96, 226, 206));                 // casco
        img.fillPolygon(xs, ys, 4);
        img.setColor(new Color(210, 250, 255));                // cabina
        img.fillOval(s / 2 - 3, s / 2 - 3, 6, 6);
        return img;
    }

    /** Nave alien: silueta radial (no necesita rotar). */
    private static GreenfootImage naveAlien(Color relleno, Color borde, int t)
    {
        GreenfootImage img = new GreenfootImage(t + 4, t + 4);
        int u = Math.max(2, t / 8);
        int c = (t + 4) / 2;

        img.setColor(borde);
        img.fillRect(c - t / 2, c, u, u * 2);
        img.fillRect(c - u / 2, c, u, u * 2);
        img.fillRect(c + t / 2 - u, c, u, u * 2);

        img.setColor(borde);
        img.fillOval(c - t / 2, c - t / 2, t, t - u);
        img.setColor(relleno);
        img.fillOval(c - t / 2 + 3, c - t / 2 + 3, t - 6, t - u - 6);

        img.setColor(new Color(20, 20, 26));
        img.fillOval(c - u - 1, c - u, u, u + 1);
        img.fillOval(c + 1, c - u, u, u + 1);
        return img;
    }

    /** Nave elite: como la alien pero con "cuernos" y nucleo brillante. */
    private static GreenfootImage naveElite(Color relleno, Color borde, int t)
    {
        GreenfootImage img = naveAlien(relleno, borde, t);
        int c = img.getWidth() / 2;
        img.setColor(borde);
        img.fillPolygon(new int[] { 0, c - 3, 6 },  new int[] { 2, c - 2, c }, 3);
        img.fillPolygon(new int[] { img.getWidth(), c + 3, img.getWidth() - 6 },
                        new int[] { 2, c - 2, c }, 3);
        img.setColor(new Color(240, 220, 255));
        img.fillOval(c - 3, c - 3, 6, 6);
        return img;
    }

    private static GreenfootImage laser(Color color, int largo, int alto)
    {
        int w = largo + 8;
        int h = alto + 8;
        GreenfootImage img = new GreenfootImage(w, h);
        img.setColor(new Color(color.getRed(), color.getGreen(), color.getBlue(), 80));
        img.fillOval(0, 0, w, h);
        img.setColor(color);
        img.fillRect(4, 4, largo, alto);
        img.setColor(new Color(255, 255, 255, 220));
        img.fillRect(4, 4 + alto / 2 - 1, largo - 2, 2);
        return img;
    }

    private static GreenfootImage fogonazo()
    {
        GreenfootImage img = new GreenfootImage(22, 22);
        img.setColor(new Color(150, 230, 255, 150));
        img.fillOval(0, 0, 22, 22);
        img.setColor(new Color(240, 250, 255, 230));
        img.fillOval(6, 6, 10, 10);
        return img;
    }

    /** Secuencia de cuadros de una explosion: anillo naranja que crece y se apaga. */
    private static GreenfootImage[] crearExplosion()
    {
        int n = 6;
        GreenfootImage[] f = new GreenfootImage[n];
        for (int i = 0; i < n; i++)
        {
            int s = 18 + i * 13;
            int a = Math.max(25, 230 - i * 40);
            GreenfootImage img = new GreenfootImage(s + 4, s + 4);
            img.setColor(new Color(255, 150, 70, Math.max(18, a - 60)));
            img.fillOval(0, 0, s + 3, s + 3);
            img.setColor(new Color(255, 205, 110, a));
            img.fillOval(2, 2, s, s);
            if (i < 3)
            {
                img.setColor(new Color(255, 255, 220, a));
                img.fillOval(s / 3, s / 3, s / 3, s / 3);
            }
            f[i] = img;
        }
        return f;
    }

    /** Roca irregular. Semilla fija por radio -> una figura por tamano. */
    private static GreenfootImage asteroide(int radio)
    {
        int s = radio * 2 + 8;
        GreenfootImage img = new GreenfootImage(s, s);
        int n = 11;
        int[] xs = new int[n];
        int[] ys = new int[n];
        Random r = new Random(radio * 97L);
        for (int i = 0; i < n; i++)
        {
            double a = i * 2 * Math.PI / n;
            double rad = radio * (0.70 + r.nextDouble() * 0.36);
            xs[i] = (int) Math.round(s / 2.0 + Math.cos(a) * rad);
            ys[i] = (int) Math.round(s / 2.0 + Math.sin(a) * rad);
        }
        img.setColor(new Color(122, 118, 112));
        img.fillPolygon(xs, ys, n);
        img.setColor(new Color(92, 88, 84));
        img.drawPolygon(xs, ys, n);
        img.setColor(new Color(70, 67, 64));
        img.fillOval(s / 2 - radio / 3, s / 2 - radio / 4, Math.max(3, radio / 3), Math.max(3, radio / 4));
        img.fillOval(s / 2 + radio / 6, s / 2 + radio / 8, Math.max(2, radio / 4), Math.max(2, radio / 5));
        return img;
    }
}
