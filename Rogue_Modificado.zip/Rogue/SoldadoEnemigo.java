import greenfoot.*;

/**
 * SoldadoEnemigo: nave alien de ASALTO (kamikaze).
 *
 * Driver / concern: Separacion de responsabilidades + Game balance + Memory.
 * - Persigue al jugador con separacion de vecinos (no se apilan al acercarse).
 * - Al TOCAR al jugador NO se queda pegada: explota, quita un % del casco
 *   maximo y desaparece. Asi un enjambre ya no "funde" al jugador estando
 *   amontonado encima; ademas los i-frames del jugador dan un respiro.
 * - La nave NO sabe en que oleada esta: eso es de GestorOleadas.
 *
 * Subclases hostigadoras (EnemigoTirador / EnemigoElite) reescriben avanzar()
 * para mantener distancia y usan conductaExtra() para disparar.
 */
public class SoldadoEnemigo extends Soldado
{
    protected final Jugador objetivo;
    private final double pctExplosion;   // fraccion de la vida MAXIMA del jugador
    private final int recompensa;

    public SoldadoEnemigo(Jugador objetivo, int vida, double velocidad, double pctExplosion)
    {
        this(objetivo, vida, velocidad, pctExplosion, "enemigo");
    }

    protected SoldadoEnemigo(Jugador objetivo, int vida, double velocidad,
                             double pctExplosion, String sprite)
    {
        super(sprite, Math.max(6, vida), Math.max(0.6, velocidad), true);
        this.objetivo = objetivo;
        this.pctExplosion = Math.max(0.01, pctExplosion);
        this.recompensa = 12 + (int) Math.round(this.pctExplosion * 100);
    }

    public void act()
    {
        actualizarDestello();
        if (objetivo == null || !objetivo.estaVivo()) return;

        avanzar();
        conductaExtra();

        if (isTouching(Jugador.class)) explotar();
    }

    /** Gancho para hostigadores: disparar. Por defecto no hace nada. */
    protected void conductaExtra() { }

    /** Movimiento por defecto: perseguir de frente. */
    protected void avanzar()
    {
        double[] dir = direccionAObjetivo();
        aplicarMovimiento(dir[0], dir[1]);
    }

    /** Anade separacion de vecinos al vector deseado y desplaza a 'velocidad'. */
    protected void aplicarMovimiento(double vx, double vy)
    {
        double sepX = 0, sepY = 0;
        for (Object o : getObjectsInRange(30, SoldadoEnemigo.class))
        {
            Actor v = (Actor) o;
            double ex = getX() - v.getX();
            double ey = getY() - v.getY();
            double ed = Math.hypot(ex, ey);
            if (ed > 0.01 && ed < 30) { sepX += ex / ed; sepY += ey / ed; }
        }

        double mx = vx + sepX * 0.65;
        double my = vy + sepY * 0.65;
        double mn = Math.hypot(mx, my);
        if (mn > 0.01) { mx /= mn; my /= mn; }

        mover(mx * velocidad, my * velocidad);
        limitarAlMundo(8);
    }

    protected double distanciaObjetivo()
    {
        return Math.hypot(objetivo.getX() - getX(), objetivo.getY() - getY());
    }

    protected double[] direccionAObjetivo()
    {
        double dx = objetivo.getX() - getX();
        double dy = objetivo.getY() - getY();
        double d = Math.hypot(dx, dy);
        if (d < 0.001) return new double[] { 0, 0 };
        return new double[] { dx / d, dy / d };
    }

    private void explotar()
    {
        World mundo = getWorld();
        if (mundo == null) return;

        mundo.addObject(new Explosion(), getX(), getY());
        objetivo.recibirDanioPorcentaje(pctExplosion);
        if (mundo instanceof JuegoWorld) ((JuegoWorld) mundo).registrarBaja(recompensa);
        mundo.removeObject(this);
    }

    @Override
    protected void morir()   // destruida por laser
    {
        World mundo = getWorld();
        if (mundo instanceof JuegoWorld) ((JuegoWorld) mundo).registrarBaja(recompensa);
        super.morir();
    }
}
