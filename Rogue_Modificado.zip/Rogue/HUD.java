import greenfoot.*;

/**
 * HUD: panel de estado para inspeccionar el juego en ejecucion.
 *
 * Driver / concern: Observability + Performance.
 * Muestra oleada y variante, conteos frente a sus presupuestos (Ne/35, Nb/60,
 * asteroides/16), picos historicos de actores, casco del jugador, puntaje y
 * bajas. Se reconstruye cada Config.INTERVALO_REFRESCO_HUD frames: crear una
 * imagen de texto por frame seria trabajo desperdiciado.
 */
public class HUD extends Actor
{
    private final JuegoWorld mundo;
    private final Jugador jugador;
    private final GestorOleadas gestor;

    private int contador = 0;
    private int picoEnemigos = 0;
    private int picoBalas = 0;
    private int picoAsteroides = 0;

    public HUD(JuegoWorld mundo, Jugador jugador, GestorOleadas gestor)
    {
        this.mundo = mundo;
        this.jugador = jugador;
        this.gestor = gestor;
        reconstruir();
    }

    public void act()
    {
        if (++contador >= Config.INTERVALO_REFRESCO_HUD)
        {
            contador = 0;
            reconstruir();
        }
    }

    private void reconstruir()
    {
        int enemigos = mundo.getObjects(SoldadoEnemigo.class).size();
        int balas = mundo.getObjects(Bala.class).size();
        int disparos = mundo.getObjects(DisparoEnemigo.class).size();
        int asteroides = mundo.getObjects(Asteroide.class).size();
        picoEnemigos = Math.max(picoEnemigos, enemigos);
        picoBalas = Math.max(picoBalas, balas);
        picoAsteroides = Math.max(picoAsteroides, asteroides);

        int w = 560, h = 76;
        GreenfootImage img = new GreenfootImage(w, h);
        img.setColor(new Color(0, 0, 0, 150));
        img.fillRect(0, 0, w, h);
        img.setColor(new Color(255, 255, 255, 40));
        img.drawRect(0, 0, w - 1, h - 1);

        img.setFont(new Font("SansSerif", true, false, 14));
        img.setColor(Color.WHITE);
        String estado = gestor.enPausa() ? "aproximandose..." : ("total " + gestor.totalOleada());
        img.drawString("OLEADA " + gestor.numeroOleada() + "  -  " + gestor.nombreVariante()
                       + "  (" + estado + ")", 10, 18);

        img.setFont(new Font("SansSerif", false, false, 13));
        img.drawString("Aliens " + enemigos + "/" + gestor.maxSimultaneos()
                       + " (pico " + picoEnemigos + ")     "
                       + "Laser " + balas + "/" + Config.MAX_PROYECTILES_JUGADOR
                       + " (pico " + picoBalas + ")     Disp.alien " + disparos, 10, 38);

        img.drawString("Asteroides " + asteroides + "/" + Config.MAX_ASTEROIDES
                       + " (pico " + picoAsteroides + ")     "
                       + "Puntaje " + mundo.getPuntaje() + "     Bajas " + mundo.getBajas(), 10, 57);

        // Barra de casco del jugador
        int bx = 372, by = 60, bw = 178, bh = 12;
        double pct = Math.max(0.0, jugador.getPorcentajeVida());
        img.setColor(new Color(45, 45, 52));
        img.fillRect(bx, by, bw, bh);
        img.setColor(pct > 0.3 ? new Color(90, 200, 100) : new Color(220, 80, 70));
        img.fillRect(bx, by, (int) Math.round(bw * pct), bh);
        img.setColor(Color.WHITE);
        img.drawRect(bx, by, bw, bh);
        img.setFont(new Font("SansSerif", true, false, 11));
        img.drawString("CASCO " + jugador.getVida(), bx + 6, by + 10);

        setImage(img);
        setLocation(w / 2 + 8, h / 2 + 8);
    }
}
