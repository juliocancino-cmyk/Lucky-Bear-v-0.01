import greenfoot.*;

/**
 * Asteroide: peligro ambiental. Deriva en linea recta, cruza los bordes
 * (wrap) y gira sobre si mismo. Dana al jugador por contacto segun su tamano
 * y puede recibir laser: al destruirse un asteroide grande o mediano se
 * fragmenta en dos mas pequenos.
 *
 * Driver / concern: Memory usage + Resource lifecycle.
 * La fragmentacion SOLO ocurre si hay cupo dentro de Config.MAX_ASTEROIDES:
 * el presupuesto de memoria manda sobre el efecto visual. Sin ese limite,
 * disparar a las rocas multiplicaria los actores sin control.
 */
public class Asteroide extends Entidad
{
    private final int nivel;        // 3 grande, 2 mediano, 1 chico
    private final double vx;
    private final double vy;
    private final int giro;
    private int vida;
    private int angulo;

    public Asteroide(int nivel, double vx, double vy)
    {
        this.nivel = Math.max(1, Math.min(3, nivel));
        this.vx = vx;
        this.vy = vy;
        this.vida = this.nivel * 14;
        this.giro = Greenfoot.getRandomNumber(5) - 2;
        setImage(FabricaImagenes.obtener("asteroide" + this.nivel));
    }

    public int getDanioContacto()
    {
        switch (nivel)
        {
            case 3:  return Config.DANIO_ASTEROIDE_GRANDE;
            case 2:  return Config.DANIO_ASTEROIDE_MEDIANO;
            default: return Config.DANIO_ASTEROIDE_CHICO;
        }
    }

    public void act()
    {
        mover(vx, vy);
        envolver();
        angulo = (angulo + giro + 360) % 360;
        setRotation(angulo);

        Jugador jugador = (Jugador) getOneIntersectingObject(Jugador.class);
        if (jugador != null) jugador.recibirDanio(getDanioContacto());
    }

    /** Llamado por Bala al impactar. */
    public void recibirDanio(int cantidad)
    {
        vida -= cantidad;
        if (vida <= 0) fragmentar();
    }

    private void envolver()
    {
        World m = getWorld();
        if (m == null) return;
        int an = m.getWidth();
        int al = m.getHeight();
        if (px < -22) px = an + 22;
        if (px > an + 22) px = -22;
        if (py < -22) py = al + 22;
        if (py > al + 22) py = -22;
        setLocation((int) Math.round(px), (int) Math.round(py));
    }

    private void fragmentar()
    {
        World m = getWorld();
        if (m == null) return;

        if (m instanceof JuegoWorld) ((JuegoWorld) m).registrarBaja(4 + nivel * 3);

        int x = getX();
        int y = getY();
        m.removeObject(this);

        if (nivel <= 1) return;

        int vivos = m.getObjects(Asteroide.class).size();
        if (vivos + 2 > Config.MAX_ASTEROIDES) return;   // el presupuesto manda

        for (int i = 0; i < 2; i++)
        {
            double ang = Math.random() * Math.PI * 2;
            double vel = 1.1 + Math.random() * 1.4;
            m.addObject(new Asteroide(nivel - 1, Math.cos(ang) * vel, Math.sin(ang) * vel), x, y);
        }
    }
}
