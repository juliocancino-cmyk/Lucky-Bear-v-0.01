import greenfoot.*;

/**
 * Explosion: efecto visual de vida muy corta (Resource lifecycle).
 * Solo anima; el dano al jugador lo aplica quien explota, de forma
 * deterministica. Los cuadros son imagenes COMPARTIDAS creadas una sola vez
 * en FabricaImagenes, asi que muchas explosiones no cuestan memoria extra.
 */
public class Explosion extends Actor
{
    private final GreenfootImage[] cuadros = FabricaImagenes.explosion();
    private int t = 0;

    public Explosion()
    {
        setImage(cuadros[0]);
    }

    public void act()
    {
        t++;
        int i = t / 2;
        if (i >= cuadros.length)
        {
            getWorld().removeObject(this);
            return;
        }
        setImage(cuadros[i]);
    }
}
