import greenfoot.*;

/**
 * Entidad: base comun de todo lo que se mueve (soldados y proyectiles).
 *
 * Driver / concern: Modularity + Maintainability.
 * Extrae el trabajo repetido de la guia -- posicion, desplazamiento,
 * limites del mundo, distancias -- a un solo lugar. Mantiene una posicion
 * en coma flotante para que las trayectorias diagonales no "tiemblen"
 * al redondear a pixeles enteros en cada frame.
 */
public abstract class Entidad extends Actor
{
    protected double px;
    protected double py;

    @Override
    protected void addedToWorld(World mundo)
    {
        px = getX();
        py = getY();
    }

    /** Desplaza sumando un vector (vx, vy) a la posicion continua. */
    protected void mover(double vx, double vy)
    {
        px += vx;
        py += vy;
        setLocation((int) Math.round(px), (int) Math.round(py));
    }

    /** Mantiene la entidad dentro del mundo dejando un margen. */
    protected void limitarAlMundo(int margen)
    {
        World m = getWorld();
        if (m == null) return;
        px = Math.max(margen, Math.min(m.getWidth() - margen, px));
        py = Math.max(margen, Math.min(m.getHeight() - margen, py));
        setLocation((int) Math.round(px), (int) Math.round(py));
    }

    protected boolean tocandoBorde(int margen)
    {
        World m = getWorld();
        if (m == null) return true;
        return getX() <= margen || getY() <= margen
            || getX() >= m.getWidth() - margen
            || getY() >= m.getHeight() - margen;
    }

    protected double distanciaA(Actor otro)
    {
        return Math.hypot(otro.getX() - getX(), otro.getY() - getY());
    }
}
