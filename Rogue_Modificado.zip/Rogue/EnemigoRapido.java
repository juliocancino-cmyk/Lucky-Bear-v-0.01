import greenfoot.*;

/**
 * EnemigoRapido: interceptor alien de asalto. Poco casco, mucha velocidad.
 * Explosion de contacto BAJA (Config.PCT_EXPLOSION_RAPIDO): presiona por
 * saturacion, no por pegada. Barato en recursos.
 */
public class EnemigoRapido extends SoldadoEnemigo
{
    public EnemigoRapido(Jugador objetivo, int vidaBase, double velocidadBase)
    {
        super(objetivo,
              Math.max(12, (int) Math.round(vidaBase * 0.55)),
              velocidadBase * 1.8 + 0.6,
              Config.PCT_EXPLOSION_RAPIDO,
              "rapido");
    }
}
