/**
 * Config: parametros de ajuste del juego en un unico punto.
 *
 * Driver / concern: Maintainability + Game balance.
 * Toda decision numerica de balance vive aqui, no dispersa como "numeros
 * magicos" dentro de cada clase.
 *
 * Ambientacion: nave de combate contra naves alien y asteroides.
 * En el codigo se conserva la nomenclatura de la guia (Soldado / SoldadoEnemigo
 * / Bala) para poder rastrear la rubrica; visualmente son naves y laseres.
 */
public final class Config
{
    private Config() { }

    // ---- Mundo ----
    public static final int ANCHO_MUNDO = 960;
    public static final int ALTO_MUNDO  = 640;

    // ---- Presupuestos de recursos (tension memoria <-> rendimiento) ----
    /** Ne: naves alien vivas a la vez. Tope duro, independiente de la oleada. */
    public static final int MAX_ENEMIGOS_SIMULTANEOS = 35;
    /** Nb: laseres del jugador vivos a la vez. */
    public static final int MAX_PROYECTILES_JUGADOR  = 60;
    /** Laseres alien vivos a la vez. */
    public static final int MAX_PROYECTILES_ENEMIGOS = 50;
    /** Enemigos totales que puede pedir una oleada. */
    public static final int MAX_TOTAL_POR_OLEADA     = 80;
    /** Asteroides vivos a la vez: los fragmentos NO pueden exceder este tope. */
    public static final int MAX_ASTEROIDES           = 16;

    // ---- Jugador ----
    public static final int VIDA_JUGADOR       = 120;
    public static final int VEL_JUGADOR        = 4;
    public static final int COOLDOWN_DISPARO   = 7;
    public static final int IFRAMES_TRAS_GOLPE = 42;   // respiro tras explosion o disparo recibido
    public static final int COOLDOWN_DASH      = 95;
    public static final int DURACION_DASH      = 8;
    public static final int VEL_DASH           = 12;

    // ---- Proyectiles ----
    public static final int VEL_BALA              = 9;
    public static final int TTL_BALA              = 68;
    public static final int DANIO_BALA            = 12;
    public static final int VEL_DISPARO_ENEMIGO   = 5;
    public static final int TTL_DISPARO_ENEMIGO   = 120;
    public static final int DANIO_DISPARO_ENEMIGO = 8;

    // ---- Naves de ASALTO: al tocarte EXPLOTAN y quitan un % del casco maximo ----
    public static final double PCT_EXPLOSION_NORMAL  = 0.12;
    public static final double PCT_EXPLOSION_RAPIDO  = 0.07;
    public static final double PCT_EXPLOSION_PESADO  = 0.28;
    // ---- Naves HOSTIGADORAS: mantienen distancia y disparan; si las acorralas, explosion menor ----
    public static final double PCT_EXPLOSION_TIRADOR = 0.10;
    public static final double PCT_EXPLOSION_ELITE   = 0.15;

    // Distancia que intentan mantener los hostigadores y cadencia de tiro (frames)
    public static final int RANGO_TIRADOR       = 235;
    public static final int CADENCIA_TIRO_TIRADOR = 66;
    public static final int RANGO_ELITE         = 190;
    public static final int CADENCIA_TIRO_ELITE = 46;

    // ---- Dano por CONTACTO segun tamano de asteroide ----
    public static final int DANIO_ASTEROIDE_GRANDE  = 22;
    public static final int DANIO_ASTEROIDE_MEDIANO = 13;
    public static final int DANIO_ASTEROIDE_CHICO   = 6;

    // ---- HUD ----
    public static final int INTERVALO_REFRESCO_HUD = 12;

    // ---- Oleadas ----
    public static final int PAUSA_ENTRE_OLEADAS = 110;
    public static final int SPAWN_INICIAL       = 18;
}
