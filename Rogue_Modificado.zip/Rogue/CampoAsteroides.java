import greenfoot.*;

/**
 * CampoAsteroides: gestiona la poblacion de asteroides de forma INDEPENDIENTE
 * de las oleadas de naves alien.
 *
 * Driver / concern: Separacion de responsabilidades + Scalability.
 * Igual que GestorOleadas con los enemigos, este componente es el unico que
 * decide cuantos asteroides hay. Mantiene un objetivo bajo que crece poco con
 * la oleada y jamas supera Config.MAX_ASTEROIDES (contando los fragmentos).
 * No es un Actor: es logica pura invocada desde JuegoWorld.act().
 */
public class CampoAsteroides
{
    private final JuegoWorld mundo;
    private final GestorOleadas oleadas;
    private int enfriamiento;

    public CampoAsteroides(JuegoWorld mundo, GestorOleadas oleadas)
    {
        this.mundo = mundo;
        this.oleadas = oleadas;
        this.enfriamiento = 120;
    }

    public void actualizar()
    {
        int vivos = mundo.getObjects(Asteroide.class).size();
        int objetivo = Math.min(3 + oleadas.numeroOleada(), Config.MAX_ASTEROIDES - 4);

        if (vivos >= objetivo)
        {
            enfriamiento = 60;
            return;
        }
        if (--enfriamiento > 0) return;

        enfriamiento = 75;
        generar();
    }

    private void generar()
    {
        int an = mundo.getWidth();
        int al = mundo.getHeight();
        int x, y;

        if (Greenfoot.getRandomNumber(2) == 0)
        {
            x = (Greenfoot.getRandomNumber(2) == 0) ? -12 : an + 12;
            y = Greenfoot.getRandomNumber(al);
        }
        else
        {
            x = Greenfoot.getRandomNumber(an);
            y = (Greenfoot.getRandomNumber(2) == 0) ? -12 : al + 12;
        }

        double ang = Math.atan2(al / 2.0 - y, an / 2.0 - x) + (Math.random() - 0.5) * 1.3;
        double vel = 0.8 + Math.random() * 1.4;
        int nivel = (Greenfoot.getRandomNumber(4) == 0) ? 2 : 3;

        mundo.addObject(new Asteroide(nivel, Math.cos(ang) * vel, Math.sin(ang) * vel), x, y);
    }
}
