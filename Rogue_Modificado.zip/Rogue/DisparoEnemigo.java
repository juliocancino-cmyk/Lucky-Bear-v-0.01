import greenfoot.*;

/**
 * DisparoEnemigo: proyectil de la EnemigoElite. Tiene su propio presupuesto
 * (Config.MAX_PROYECTILES_ENEMIGOS) y vida util para no descontrolar recursos.
 */
public class DisparoEnemigo extends Proyectil
{
    public DisparoEnemigo(double dirX, double dirY)
    {
        super("disparoEnemigo", dirX, dirY,
              Config.VEL_DISPARO_ENEMIGO, Config.TTL_DISPARO_ENEMIGO, Config.DANIO_DISPARO_ENEMIGO);
    }

    @Override
    protected boolean impactar()
    {
        Jugador jugador = (Jugador) getOneIntersectingObject(Jugador.class);
        if (jugador != null)
        {
            jugador.recibirDanio(danio);
            return true;
        }
        return false;
    }
}
