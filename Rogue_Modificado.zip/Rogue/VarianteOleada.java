import greenfoot.*;

/**
 * VarianteOleada: sabor rogue-like de cada oleada (seccion 25 de la guia).
 *
 * Driver / concern: Game balance + rejugabilidad.
 * Cada variante reescala varios parametros a la vez (cantidad, vida, velocidad,
 * dano, ritmo de aparicion). NUNCA toca el tope de enemigos simultaneos:
 * ese limite (Ne <= 35) lo impone Config y es intocable.
 *
 *   variabilidad  ->  rejugabilidad     sin aumentar el maximo de actores
 */
public enum VarianteOleada
{
    ESTANDAR  ("Estandar",   1.00, 1.00, 1.00, 1.00, 1.00),
    ENJAMBRE  ("Enjambre",   1.70, 0.65, 1.15, 0.65, 0.80),
    FORTALEZA ("Fortaleza",  0.55, 2.10, 0.80, 1.35, 1.15),
    ASEDIO    ("Asedio",     1.05, 0.95, 1.05, 1.00, 0.50),
    VANGUARDIA("Vanguardia", 0.80, 1.25, 1.20, 1.15, 0.95);

    public final String nombre;
    public final double multCantidad;
    public final double multVida;
    public final double multVelocidad;
    public final double multDanio;
    public final double multIntervalo;

    VarianteOleada(String nombre, double cantidad, double vida,
                   double velocidad, double danio, double intervalo)
    {
        this.nombre = nombre;
        this.multCantidad = cantidad;
        this.multVida = vida;
        this.multVelocidad = velocidad;
        this.multDanio = danio;
        this.multIntervalo = intervalo;
    }

    public static VarianteOleada aleatoria()
    {
        VarianteOleada[] v = values();
        return v[Greenfoot.getRandomNumber(v.length)];
    }
}
