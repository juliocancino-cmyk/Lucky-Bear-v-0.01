import greenfoot.*;

/**
 * Bala: laser del jugador. Cuenta para el presupuesto Nb <= 60
 * (el control del tope lo hace Jugador antes de crearla).
 * Impacta naves alien y tambien rompe asteroides.
 */
public class Bala extends Proyectil
{
    public Bala(double dirX, double dirY)
    {
        super("bala", dirX, dirY, Config.VEL_BALA, Config.TTL_BALA, Config.DANIO_BALA);
    }

    @Override
    protected boolean impactar()
    {
        SoldadoEnemigo nave =
            (SoldadoEnemigo) getOneIntersectingObject(SoldadoEnemigo.class);
        if (nave != null)
        {
            nave.recibirDanio(danio);
            return true;
        }

        Asteroide roca = (Asteroide) getOneIntersectingObject(Asteroide.class);
        if (roca != null)
        {
            roca.recibirDanio(danio);
            return true;
        }
        return false;
    }
}
