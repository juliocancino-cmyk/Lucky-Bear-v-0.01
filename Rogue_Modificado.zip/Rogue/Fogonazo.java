import greenfoot.*;

/**
 * Fogonazo: destello de disparo. Actor de vida muy corta con imagen
 * compartida; se autoelimina a los pocos frames (Resource lifecycle).
 */
public class Fogonazo extends Actor
{
    private int restante = 4;

    public Fogonazo()
    {
        setImage(FabricaImagenes.obtener("fogonazo"));
    }

    public void act()
    {
        if (--restante <= 0) getWorld().removeObject(this);
    }
}
