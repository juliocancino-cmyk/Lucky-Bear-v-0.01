import greenfoot.*;

/**
 * Jugador: entrada, movimiento omnidireccional, apuntado y disparo.
 *
 * Driver / concern: Responsiveness + Memory usage.
 * - La entrada se procesa integra en cada act(), aislada de la logica de oleadas.
 * - Movimiento en 8 direcciones (vector normalizado) + esquive (Shift) con
 *   fotogramas de invulnerabilidad; tras recibir dano tambien hay i-frames.
 * - El disparo respeta el presupuesto Nb <= Config.MAX_PROYECTILES_JUGADOR y
 *   un cooldown, de modo que jamas se crea una bala por frame.
 * - Apunta al raton; si no hay raton, usa la ultima direccion de avance.
 */
public class Jugador extends Soldado
{
    private double miraX = 1;
    private double miraY = 0;

    private int cooldownDisparo = 0;
    private int iframes = 0;
    private int cooldownDash = 0;
    private int dash = 0;

    public Jugador()
    {
        super("jugador", Config.VIDA_JUGADOR, Config.VEL_JUGADOR, false);
        // Copia privada del sprite: permite parpadear (transparencia) sin
        // afectar a ningun otro actor que comparta la imagen original.
        setImage(new GreenfootImage(getImage()));
    }

    public void act()
    {
        apuntar();
        desplazar();
        disparar();

        if (cooldownDisparo > 0) cooldownDisparo--;
        if (cooldownDash > 0) cooldownDash--;
        if (iframes > 0) iframes--;

        getImage().setTransparency(iframes > 0 && (iframes / 3) % 2 == 0 ? 110 : 255);
    }

    private void apuntar()
    {
        MouseInfo m = Greenfoot.getMouseInfo();
        if (m != null)
        {
            double dx = m.getX() - getX();
            double dy = m.getY() - getY();
            if (dx != 0 || dy != 0) { miraX = dx; miraY = dy; }
        }
        setRotation((int) Math.toDegrees(Math.atan2(miraY, miraX)));
    }

    private void desplazar()
    {
        double ix = 0, iy = 0;
        if (Greenfoot.isKeyDown("a")) ix -= 1;
        if (Greenfoot.isKeyDown("d")) ix += 1;
        if (Greenfoot.isKeyDown("w")) iy -= 1;
        if (Greenfoot.isKeyDown("s")) iy += 1;

        boolean moviendose = (ix != 0 || iy != 0);

        boolean pideDash = Greenfoot.isKeyDown("shift") || Greenfoot.isKeyDown("control");
        if (pideDash && cooldownDash == 0 && moviendose)
        {
            dash = Config.DURACION_DASH;
            cooldownDash = Config.COOLDOWN_DASH;
            iframes = Math.max(iframes, Config.DURACION_DASH + 5);
        }

        double vel = (dash > 0) ? Config.VEL_DASH : velocidad;
        if (dash > 0) dash--;

        if (moviendose)
        {
            double n = Math.hypot(ix, iy);
            mover(ix / n * vel, iy / n * vel);
            limitarAlMundo(16);
            if (Greenfoot.getMouseInfo() == null) { miraX = ix; miraY = iy; }
        }
    }

    private void disparar()
    {
        boolean pideDisparo = Greenfoot.isKeyDown("space") || Greenfoot.mousePressed(null);
        if (!pideDisparo || cooldownDisparo != 0) return;

        cooldownDisparo = Config.COOLDOWN_DISPARO;
        if (getWorld().getObjects(Bala.class).size() >= Config.MAX_PROYECTILES_JUGADOR) return;

        double n = Math.hypot(miraX, miraY);
        if (n == 0) n = 1;
        double dx = miraX / n, dy = miraY / n;
        int bocaX = getX() + (int) Math.round(dx * 20);
        int bocaY = getY() + (int) Math.round(dy * 20);

        getWorld().addObject(new Bala(dx, dy), bocaX, bocaY);
        getWorld().addObject(new Fogonazo(), bocaX, bocaY);
    }

    @Override
    public void recibirDanio(int cantidad)
    {
        if (iframes > 0 || dash > 0) return;
        super.recibirDanio(cantidad);
        if (estaVivo()) iframes = Config.IFRAMES_TRAS_GOLPE;
    }

    /** Dano proporcional al casco maximo (usado por las explosiones kamikaze). */
    public void recibirDanioPorcentaje(double fraccion)
    {
        recibirDanio((int) Math.max(1, Math.round(vidaMaxima * fraccion)));
    }

    @Override
    protected void morir()
    {
        World mundo = getWorld();
        if (mundo instanceof JuegoWorld) ((JuegoWorld) mundo).gameOver();
        if (mundo != null) mundo.removeObject(this);
    }
}
