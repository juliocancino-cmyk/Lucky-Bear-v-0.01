import greenfoot.*;

/**
 * EnemigoElite: fragata alien. Un hostigador reforzado: mas casco, algo mas
 * rapida, se acerca mas y dispara con mayor cadencia. Aparece en oleadas altas.
 *
 * Responde a la pregunta de analisis 9 de la guia ("que cambiaria si los
 * enemigos tambien dispararan?"): el laser alien tiene su propio presupuesto
 * y vida util, igual que el del jugador, para no romper la tension
 * memoria/rendimiento.
 */
public class EnemigoElite extends EnemigoTirador
{
    public EnemigoElite(Jugador objetivo, int vidaBase, double velocidadBase)
    {
        super(objetivo,
              (int) Math.round(vidaBase * 1.7) + 30,
              velocidadBase * 1.05,
              Config.PCT_EXPLOSION_ELITE,
              "elite",
              Config.RANGO_ELITE,
              Config.CADENCIA_TIRO_ELITE);
    }
}
