import greenfoot.*;

/**
 * EnemigoTirador: nave alien HOSTIGADORA. No embiste: intenta mantenerse a
 * cierta distancia (rango) y dispara laser al jugador con una cadencia propia.
 *
 * Driver / concern: Game balance + variedad de amenazas.
 * Reescribe avanzar() para acercarse / alejarse / orbitar segun la distancia,
 * y usa conductaExtra() para disparar respetando el presupuesto de laseres
 * alien (Config.MAX_PROYECTILES_ENEMIGOS). Si el jugador la acorrala, la clase
 * base la hace explotar igual (Config.PCT_EXPLOSION_TIRADOR).
 */
public class EnemigoTirador extends SoldadoEnemigo
{
    private final int rango;
    private final int cadenciaTiro;
    private int recarga;

    public EnemigoTirador(Jugador objetivo, int vidaBase, double velocidadBase)
    {
        this(objetivo,
             (int) Math.round(vidaBase * 0.85),
             velocidadBase,
             Config.PCT_EXPLOSION_TIRADOR,
             "tirador",
             Config.RANGO_TIRADOR,
             Config.CADENCIA_TIRO_TIRADOR);
    }

    protected EnemigoTirador(Jugador objetivo, int vida, double velocidad, double pctExplosion,
                             String sprite, int rango, int cadenciaTiro)
    {
        super(objetivo, vida, velocidad, pctExplosion, sprite);
        this.rango = rango;
        this.cadenciaTiro = Math.max(12, cadenciaTiro);
        this.recarga = 25 + Greenfoot.getRandomNumber(this.cadenciaTiro);
    }

    @Override
    protected void avanzar()
    {
        double d = distanciaObjetivo();
        double[] dir = direccionAObjetivo();
        double vx, vy;

        if (d > rango + 45)        { vx = dir[0];            vy = dir[1]; }          // acercarse
        else if (d < rango - 45)   { vx = -dir[0];           vy = -dir[1]; }         // alejarse
        else                       { vx = -dir[1] * 0.85;    vy = dir[0] * 0.85; }   // orbitar

        aplicarMovimiento(vx, vy);
    }

    @Override
    protected void conductaExtra()
    {
        if (recarga > 0) { recarga--; return; }

        boolean hayCupo = getWorld().getObjects(DisparoEnemigo.class).size()
                        < Config.MAX_PROYECTILES_ENEMIGOS;
        if (hayCupo && distanciaObjetivo() < rango + 130)
        {
            double[] dir = direccionAObjetivo();
            getWorld().addObject(new DisparoEnemigo(dir[0], dir[1]), getX(), getY());
            recarga = cadenciaTiro;
        }
    }
}
