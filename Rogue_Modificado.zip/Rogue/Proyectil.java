import greenfoot.*;

/**
 * Proyectil: base de las balas del jugador y de los disparos enemigos.
 *
 * Driver / concern: Resource lifecycle + Memory usage.
 * Ciclo de vida explicito:  crear -> avanzar -> (impacto | vida util | borde) -> destruir.
 * Ningun proyectil permanece vivo indefinidamente.
 *
 * Nota de diseno (seccion 30 de la guia): a esta escala (Nb <= 60) NO se usa
 * object pooling; crear y destruir es suficientemente barato. El pool solo se
 * justificaria si el conteo de proyectiles creciera un orden de magnitud.
 */
public abstract class Proyectil extends Entidad
{
    private final double vx;
    private final double vy;
    protected final int danio;
    private int vidaUtil;

    protected Proyectil(String claveSprite, double dirX, double dirY,
                        double velocidad, int vidaUtil, int danio)
    {
        double n = Math.hypot(dirX, dirY);
        if (n == 0) n = 1;
        this.vx = dirX / n * velocidad;
        this.vy = dirY / n * velocidad;
        this.vidaUtil = vidaUtil;
        this.danio = danio;
        setImage(FabricaImagenes.obtener(claveSprite));
        setRotation((int) Math.toDegrees(Math.atan2(this.vy, this.vx)));
    }

    public void act()
    {
        mover(vx, vy);
        if (impactar())
        {
            getWorld().removeObject(this);
            return;
        }
        if (--vidaUtil <= 0 || tocandoBorde(2))
        {
            getWorld().removeObject(this);
        }
    }

    /** Devuelve true si el proyectil choco con su objetivo (y ya aplico el dano). */
    protected abstract boolean impactar();
}
