import greenfoot.*;

/**
 * Soldado: comportamiento comun de jugador y enemigos.
 *
 * Driver / concern: Modularity + Maintainability.
 * Centraliza vida/vida maxima, velocidad y el ciclo "recibir dano -> morir".
 * Los enemigos dibujan encima de su sprite una barra de vida y un destello
 * de impacto; esa imagen propia solo se rehace cuando cambia el estado
 * (recibe dano o termina el destello), nunca en cada frame.
 */
public abstract class Soldado extends Entidad
{
    protected int vida;
    protected final int vidaMaxima;
    protected double velocidad;

    private final GreenfootImage sprite;   // compartido (FabricaImagenes)
    private final boolean dibujarBarra;
    private int destelloImpacto = 0;

    protected Soldado(String claveSprite, int vida, double velocidad, boolean dibujarBarra)
    {
        this.sprite = FabricaImagenes.obtener(claveSprite);
        this.vida = vida;
        this.vidaMaxima = vida;
        this.velocidad = velocidad;
        this.dibujarBarra = dibujarBarra;

        if (dibujarBarra)
        {
            setImage(new GreenfootImage(sprite.getWidth(), sprite.getHeight() + 6));
            redibujar();
        }
        else
        {
            setImage(sprite);
        }
    }

    public void recibirDanio(int cantidad)
    {
        if (cantidad <= 0 || !estaVivo()) return;
        vida = Math.max(0, vida - cantidad);
        destelloImpacto = 5;
        if (dibujarBarra) redibujar();
        if (vida == 0) morir();
    }

    /** Las subclases enemigas lo llaman al inicio de act() para apagar el destello. */
    protected void actualizarDestello()
    {
        if (destelloImpacto > 0)
        {
            destelloImpacto--;
            if (destelloImpacto == 0 && dibujarBarra) redibujar();
        }
    }

    private void redibujar()
    {
        GreenfootImage img = getImage();
        img.clear();
        img.drawImage(sprite, 0, 6);
        if (destelloImpacto > 0)
        {
            img.setColor(new Color(255, 255, 255, 150));
            img.fillOval(0, 6, sprite.getWidth(), sprite.getHeight());
        }
        int w = img.getWidth();
        img.setColor(new Color(0, 0, 0, 170));
        img.fillRect(0, 0, w, 4);
        img.setColor(colorSegunVida());
        img.fillRect(0, 0, (int) Math.round(w * getPorcentajeVida()), 4);
    }

    private Color colorSegunVida()
    {
        double p = getPorcentajeVida();
        if (p > 0.5)  return new Color(96, 200, 96);
        if (p > 0.25) return new Color(230, 200, 70);
        return new Color(222, 82, 70);
    }

    public double getPorcentajeVida()
    {
        return vidaMaxima == 0 ? 0.0 : (double) vida / vidaMaxima;
    }

    public boolean estaVivo()
    {
        return vida > 0 && getWorld() != null;
    }

    public int getVida()
    {
        return vida;
    }

    protected void morir()
    {
        World mundo = getWorld();
        if (mundo != null) mundo.removeObject(this);
    }
}
