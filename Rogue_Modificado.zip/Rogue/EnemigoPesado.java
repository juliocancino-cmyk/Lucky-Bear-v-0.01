import greenfoot.*;

/**
 * EnemigoPesado: acorazado-bomba alien. Casco enorme, muy lento.
 * Explosion de contacto DEMOLEDORA (Config.PCT_EXPLOSION_PESADO): sube la
 * dificultad por resistencia y pegada, no por cantidad de actores.
 */
public class EnemigoPesado extends SoldadoEnemigo
{
    public EnemigoPesado(Jugador objetivo, int vidaBase, double velocidadBase)
    {
        super(objetivo,
              (int) Math.round(vidaBase * 2.4) + 30,
              Math.max(0.7, velocidadBase * 0.55),
              Config.PCT_EXPLOSION_PESADO,
              "pesado");
    }
}
