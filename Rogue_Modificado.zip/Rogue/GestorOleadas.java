import greenfoot.*;

/**
 * GestorOleadas: unica autoridad sobre CUANTOS enemigos existen y de que tipo.
 *
 * Driver / concern: Scalability + Game balance + Memory usage.
 * - Separa "total de la oleada" de "activos a la vez": una oleada de 80 se
 *   sirve en tandas que nunca superan Nsim (<= 35).
 * - La dificultad sube por varios parametros (cantidad, vida, velocidad,
 *   dano, ritmo) y por COMPOSICION de tipos de enemigo, no solo por numero.
 * - No es un Actor: es logica pura invocada desde JuegoWorld.act().
 */
public class GestorOleadas
{
    private final JuegoWorld mundo;
    private final Jugador jugador;

    private PerfilOleada perfil;
    private int generados;
    private int contadorSpawn;
    private int pausa;
    private boolean enPausa;

    public GestorOleadas(JuegoWorld mundo, Jugador jugador)
    {
        this.mundo = mundo;
        this.jugador = jugador;
        iniciarOleada(1);
    }

    public void actualizar()
    {
        if (!jugador.estaVivo()) return;

        int activos = mundo.getObjects(SoldadoEnemigo.class).size();

        if (enPausa)
        {
            if (--pausa <= 0) iniciarOleada(perfil.numero + 1);
            return;
        }

        if (generados < perfil.totalEnemigos)
        {
            contadorSpawn--;
            if (contadorSpawn <= 0 && activos < perfil.maxSimultaneos)
            {
                int[] p = puntoEnBorde();
                mundo.addObject(fabricarEnemigo(), p[0], p[1]);
                generados++;
                contadorSpawn = perfil.intervaloSpawn;
            }
        }
        else if (activos == 0)
        {
            enPausa = true;
            pausa = Config.PAUSA_ENTRE_OLEADAS;
        }
    }

    private void iniciarOleada(int numero)
    {
        perfil = new PerfilOleada(numero);
        generados = 0;
        contadorSpawn = Config.SPAWN_INICIAL;
        enPausa = false;
    }

    /** Composicion de amenazas: mezcla de kamikazes y hostigadores segun oleada y variante. */
    private SoldadoEnemigo fabricarEnemigo()
    {
        int w = perfil.numero;
        int v = perfil.vidaBase;
        double s = perfil.velocidadBase;

        int probElite   = (w >= 4) ? Math.min(4 + w, 18) : 0;   // hostigador reforzado
        int probTirador = (w >= 2) ? Math.min(14 + w * 2, 36) : 0; // hostigador basico
        int probPesado  = (w >= 2) ? Math.min(12 + w, 28) : 0;  // kamikaze demoledor
        int probRapido  = Math.min(18 + w, 40);                 // kamikaze rapido

        switch (perfil.variante)
        {
            case VANGUARDIA: probElite += 12; probTirador += 8; break;
            case FORTALEZA:  probPesado += 16; break;
            case ENJAMBRE:   probRapido += 16; probTirador -= 6; break;
            case ASEDIO:     probTirador += 10; break;
            default: break;
        }
        probTirador = Math.max(0, probTirador);

        int r = Greenfoot.getRandomNumber(100);
        int acum = probElite;
        if (r < acum)                       return new EnemigoElite(jugador, v, s);
        if (r < (acum += probTirador))      return new EnemigoTirador(jugador, v, s);
        if (r < (acum += probPesado))       return new EnemigoPesado(jugador, v, s);
        if (r < (acum += probRapido))       return new EnemigoRapido(jugador, v, s);
        return new SoldadoEnemigo(jugador, Math.max(6, v), Math.max(0.6, s), Config.PCT_EXPLOSION_NORMAL);
    }

    private int[] puntoEnBorde()
    {
        int an = mundo.getWidth();
        int al = mundo.getHeight();
        switch (Greenfoot.getRandomNumber(4))
        {
            case 0:  return new int[] { 12, Greenfoot.getRandomNumber(al) };
            case 1:  return new int[] { an - 12, Greenfoot.getRandomNumber(al) };
            case 2:  return new int[] { Greenfoot.getRandomNumber(an), 12 };
            default: return new int[] { Greenfoot.getRandomNumber(an), al - 12 };
        }
    }

    // ---- Observabilidad: consultas para el HUD ----
    public int numeroOleada()      { return perfil.numero; }
    public String nombreVariante() { return perfil.variante.nombre; }
    public int maxSimultaneos()    { return perfil.maxSimultaneos; }
    public int totalOleada()       { return perfil.totalEnemigos; }
    public int generados()         { return generados; }
    public boolean enPausa()       { return enPausa; }
}
