import greenfoot.*;

/**
 * Auto del jugador. Se dibuja siempre a la misma profundidad (Z_JUGADOR)
 * y lo unico que cambia es su posicion lateral segun el carril.
 *
 * IZQ / DER  cambiar de carril
 * SPACE      dispara SIEMPRE, pero gasta munición y tiene cadencia
 * X          bazuca contra un auto de adelante (o contra el jefe)
 * SHIFT      nitro, mantenido; gasta la misma barra que la ulti
 *
 * Rozar un rival da puntos. Chocarlo saca vida Y frena en seco.
 */
public class PlayerCar extends Objeto3D
{
    public static final double DIST_CHOQUE = 350;
    public static final double DIST_ROCE   = 540;

    public static final int BALAS_MAX     = 10;
    private static final int CADENCIA     = 9;    // frames entre disparos
    private static final int REGENERACION = 55;   // frames por bala repuesta
    private static final int RECARGA      = 130;  // frames si te quedas sin balas

    private int carril = 1;
    private int energia = 100;
    private double ulti = 0;

    private int balas = BALAS_MAX;
    private int cooldownDisparo = 0;
    private int timerRegen = 0;
    private int recargando = 0;

    private int invulnerable = 0;
    private boolean nitroActivo = false;

    private Pilotos pilotos = new Pilotos();
    private CarType tipo;

    private boolean izqPrev, derPrev, espPrev, xPrev;

    public PlayerCar()
    {
        tipo = GameData.auto();
        inicializar(Sprites.autoTrasero(tipo.cuerpo, tipo.detalle), 470, 352);
        x = Camara.centroCarril(carril);
        altura = 0;
        z = Camara.Z_JUGADOR;
    }

    public void act()
    {
        RaceWorld w = (RaceWorld) getWorld();
        if (w == null) return;

        if (w.getEstado() != 2 && !w.congelado()) {
            leerTeclas(w);
            moverLateral();
            revisarRivales(w);
            gestionarMunicion();

            if (cooldownDisparo > 0) cooldownDisparo--;
            if (invulnerable > 0) invulnerable--;
            pilotos.act();
        }

        redibujar();
        proyectar();

        getImage().setTransparency(
            (invulnerable > 0 && invulnerable % 8 < 4) ? 120 : 255);
    }

    private void redibujar()
    {
        GreenfootImage img = Sprites.autoTrasero(tipo.cuerpo, tipo.detalle);
        pilotos.dibujar(img);
        setBase(img);
    }

    private void leerTeclas(RaceWorld w)
    {
        boolean izq   = Greenfoot.isKeyDown("left")  || Greenfoot.isKeyDown("a");
        boolean der   = Greenfoot.isKeyDown("right") || Greenfoot.isKeyDown("d");
        boolean esp   = Greenfoot.isKeyDown("space");
        boolean equis = Greenfoot.isKeyDown("x");

        if (izq && !izqPrev && carril > 0) carril--;
        if (der && !derPrev && carril < Camara.CARRILES - 1) carril++;
        if (esp && !espPrev) disparar(w);
        if (equis && !xPrev) usarUlti(w);

        double gasto = (tipo.habilidad == CarType.NITRO) ? 0.55 : 1.10;
        nitroActivo = Greenfoot.isKeyDown("shift") && ulti > 0;
        if (nitroActivo) {
            ulti -= gasto;
            if (ulti < 0) ulti = 0;
        }

        izqPrev = izq; derPrev = der; espPrev = esp; xPrev = equis;
    }

    private void moverLateral()
    {
        double destino = Camara.centroCarril(carril);
        double paso = 8 + tipo.manejo * 2.4;
        if (Math.abs(destino - x) <= paso) x = destino;
        else x += (destino > x) ? paso : -paso;
    }

    // ==================================================================
    // MUNICION
    // ==================================================================
    private void gestionarMunicion()
    {
        if (recargando > 0) {
            recargando--;
            if (recargando == 0) balas = BALAS_MAX;
            return;
        }
        if (balas >= BALAS_MAX) return;

        timerRegen++;
        if (timerRegen >= REGENERACION) {
            timerRegen = 0;
            balas++;
        }
    }

    private void disparar(RaceWorld w)
    {
        if (cooldownDisparo > 0 || recargando > 0) return;

        if (balas <= 0) {
            recargando = RECARGA;
            w.addObject(new PopText("RECARGANDO", new Color(255, 200, 90), 22),
                        GameData.ANCHO / 2, 300);
            return;
        }

        balas--;
        cooldownDisparo = CADENCIA;
        pilotos.forzar(Pilotos.DISPARAR, 16);

        // apunta a lo que haya; si no hay nada, dispara igual
        Objeto3D objetivo = w.getJefe() != null ? w.getJefe() : w.heliMasCercano();

        w.addObject(new Bullet(x + 130, 165, z + 130, objetivo), -500, -500);
        if (tipo.habilidad == CarType.DOBLE && balas > 0) {
            balas--;
            w.addObject(new Bullet(x - 130, 165, z + 130, objetivo), -500, -500);
        }

        if (balas <= 0) recargando = RECARGA;
    }

    private void usarUlti(RaceWorld w)
    {
        if (ulti < 100) return;

        Objeto3D objetivo = w.getJefe();
        if (objetivo == null) objetivo = w.autoMasCercano();

        if (objetivo == null) {
            w.addObject(new PopText("SIN OBJETIVO", new Color(200, 200, 210), 20),
                        GameData.ANCHO / 2, 300);
            return;
        }

        ulti = 0;
        pilotos.forzar(Pilotos.BAZUCA, 34);
        w.addObject(new Rocket(x + 130, 175, z + 130, objetivo), -500, -500);
    }

    // ==================================================================
    // ROCES Y CHOQUES
    // ==================================================================
    private void revisarRivales(RaceWorld w)
    {
        for (RivalCar r : w.getObjects(RivalCar.class)) {
            if (Math.abs(r.getZ() - z) > 320) continue;

            double dx = Math.abs(r.getX3D() - x);

            if (dx < DIST_CHOQUE) {
                if (invulnerable == 0) chocar(w, r);
            } else if (dx < DIST_ROCE && !r.roceContado) {
                r.roceContado = true;
                rozar(w, r, dx);
            }
        }
    }

    private void rozar(RaceWorld w, RivalCar r, double dx)
    {
        double cercania = (DIST_ROCE - dx) / (DIST_ROCE - DIST_CHOQUE);
        int puntos = 40 + (int) (cercania * 120);
        w.sumarPuntaje(puntos);

        Color c = cercania > 0.65 ? new Color(255, 220, 80) : new Color(190, 240, 255);
        w.addObject(new PopText("+" + puntos + (cercania > 0.65 ? " ROCE!" : " ROCE"), c, 22),
                    r.getX(), r.getY() - 20);
    }

    private void chocar(RaceWorld w, RivalCar r)
    {
        boolean escudo = (tipo.habilidad == CarType.ESCUDO);

        energia -= escudo ? 11 : 22;
        invulnerable = 60;

        w.frenazo(escudo ? 0.72 : 0.50);
        r.rebotar();

        w.addObject(new PopText("CHOQUE", new Color(255, 90, 90), 30),
                    GameData.ANCHO / 2, 330);
        w.addObject(new Explosion(x, 140, z + 200, 500), -500, -500);

        if (energia <= 0) { energia = 0; w.gameOver(); }
    }

    public void recibirDano(int d)
    {
        if (invulnerable > 0) return;
        energia -= d;
        invulnerable = 55;
        if (energia <= 0) {
            energia = 0;
            RaceWorld w = (RaceWorld) getWorld();
            if (w != null) w.gameOver();
        }
    }

    public void cargarUlti(double c) { ulti = Math.min(100, ulti + c); }

    public double bonusVelocidad()
    {
        if (!nitroActivo) return 0;
        return (tipo.habilidad == CarType.NITRO) ? 130 : 85;
    }

    public boolean nitroEncendido() { return nitroActivo; }
    public int getEnergia()         { return energia; }
    public int getUlti()            { return (int) ulti; }
    public int getCarril()          { return carril; }
    public int getBalas()           { return balas; }
    public boolean estaRecargando() { return recargando > 0; }
    public double progresoRecarga() { return 1.0 - recargando / (double) RECARGA; }
}
