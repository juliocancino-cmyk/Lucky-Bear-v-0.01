import greenfoot.*;

/**
 * Definicion de un auto jugable: estadisticas, habilidad especial
 * y puntaje necesario para desbloquearlo.
 */
public class CarType
{
    public static final int NITRO  = 0;   // acelera con SHIFT
    public static final int ESCUDO = 1;   // recibe la mitad de dano
    public static final int DOBLE  = 2;   // dispara dos balas a la vez

    public String nombre;
    public int velocidad;          // 1..10
    public int manejo;             // 1..10 (que tan rapido cambia de carril)
    public int habilidad;
    public int puntajeDesbloqueo;
    public Color cuerpo;
    public Color detalle;

    public CarType(String nombre, int velocidad, int manejo, int habilidad,
                   int puntajeDesbloqueo, Color cuerpo, Color detalle)
    {
        this.nombre = nombre;
        this.velocidad = velocidad;
        this.manejo = manejo;
        this.habilidad = habilidad;
        this.puntajeDesbloqueo = puntajeDesbloqueo;
        this.cuerpo = cuerpo;
        this.detalle = detalle;
    }

    public boolean desbloqueado()
    {
        return GameData.puntajeTotal >= puntajeDesbloqueo;
    }

    public String nombreHabilidad()
    {
        if (habilidad == NITRO)  return "TURBO";
        if (habilidad == ESCUDO) return "ESCUDO";
        return "DOBLE DISPARO";
    }

    public String descripcionHabilidad()
    {
        if (habilidad == NITRO)  return "El nitro rinde el doble y gasta la mitad";
        if (habilidad == ESCUDO) return "Mitad de dano y de frenazo al chocar";
        return "SPACE dispara dos balas contra los helicopteros";
    }

    public GreenfootImage imagen()
    {
        GreenfootImage img = Sprites.autoTrasero(cuerpo, detalle);
        new Pilotos().dibujar(img);
        return img;
    }

    /** Lista de autos del juego, en orden de desbloqueo. */
    public static CarType[] crearLista()
    {
        return new CarType[] {
            new CarType("CLASICO 84",  4,  7, ESCUDO,     0,     new Color(200, 40, 40),  new Color(240,240,240)),
            new CarType("TURBO GT",    6,  6, NITRO,   3000,     new Color(240,160, 30),  new Color(40, 40, 60)),
            new CarType("DRIFT KING",  7,  9, DOBLE,   8000,     new Color(30, 190, 190), new Color(120, 60, 200)),
            new CarType("PATRULLA X",  8,  6, ESCUDO, 15000,     new Color(40, 60, 200),  new Color(250,250,250)),
            new CarType("PROTOTIPO Z",10,  8, NITRO,  25000,     new Color(120, 20, 160), new Color(0, 255, 180))
        };
    }
}
