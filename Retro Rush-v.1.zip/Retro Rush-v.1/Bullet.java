import greenfoot.*;

/**
 * Bala del copiloto. Viaja hacia adentro de la pantalla (z crece) y se va
 * achicando. Si hay un helicoptero o el jefe a la vista, el copiloto
 * apunta y la bala corrige su rumbo. Si no hay nada, dispara igual:
 * la bala se pierde hacia el horizonte.
 */
public class Bullet extends Objeto3D
{
    private Objeto3D objetivo;
    private double vx, vAltura;
    private double vz = 540;
    private int vida = 90;

    public Bullet(double x, double altura, double z, Objeto3D objetivo)
    {
        this.x = x;
        this.altura = altura;
        this.z = z;
        this.objetivo = objetivo;
        inicializar(Sprites.bala(), 200, 200);
        calcularRumbo();
    }

    private void calcularRumbo()
    {
        if (objetivo == null || objetivo.getWorld() == null) { vx = 0; vAltura = 0; return; }
        double dz = Math.max(400, objetivo.getZ() - z);
        double t = dz / vz;
        vx      = (objetivo.getX3D()   - x)      / t;
        vAltura = (objetivo.getAltura() - altura) / t;
    }

    public void act()
    {
        RaceWorld w = (RaceWorld) getWorld();
        if (w == null) return;
        if (w.congelado()) return;

        if (objetivo != null && objetivo.getWorld() != null) calcularRumbo();

        z += vz;
        x += vx;
        altura += vAltura;
        vida--;

        if (impactar(w)) return;

        if (vida <= 0 || z > 26000) { w.removeObject(this); return; }

        proyectar();
    }

    /** Le pega a lo que tenga cerca, apuntado o no. */
    private boolean impactar(RaceWorld w)
    {
        Boss jefe = w.getJefe();
        if (jefe != null && jefe.getWorld() != null && distanciaA(jefe) < 2200) {
            jefe.recibirDano(1);
            w.removeObject(this);
            return true;
        }

        for (EnemyHeli h : w.getObjects(EnemyHeli.class)) {
            if (distanciaA(h) < 950) {
                h.recibirDano(1);
                w.removeObject(this);
                return true;
            }
        }
        return false;
    }
}
