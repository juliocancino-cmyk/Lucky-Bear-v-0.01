import greenfoot.*;

/**
 * Garage estilo FR Legends: flechas para cambiar de auto, estadisticas,
 * y desbloqueo por puntaje total acumulado.
 */
public class GarageWorld extends World
{
    private int indice = GameData.autoSeleccionado;
    private MenuButton anterior, siguiente, seleccionar, volver;

    public GarageWorld()
    {
        super(GameData.ANCHO, GameData.ALTO, 1);

        anterior    = new MenuButton("<",           "prev",  70, 70);
        siguiente   = new MenuButton(">",           "next",  70, 70);
        seleccionar = new MenuButton("SELECCIONAR", "sel",  280, 60);
        volver      = new MenuButton("VOLVER",      "back", 180, 54);

        addObject(anterior,     70, 330);
        addObject(siguiente,   730, 330);
        addObject(seleccionar, 400, 500);
        addObject(volver,      120, 560);

        dibujar();
    }

    public void act()
    {
        if (anterior.fueClickeado()) {
            indice = (indice - 1 + GameData.autos.length) % GameData.autos.length;
            dibujar();
        } else if (siguiente.fueClickeado()) {
            indice = (indice + 1) % GameData.autos.length;
            dibujar();
        } else if (seleccionar.fueClickeado() && GameData.autos[indice].desbloqueado()) {
            GameData.autoSeleccionado = indice;
            Greenfoot.setWorld(new MenuWorld());
        } else if (volver.fueClickeado()) {
            Greenfoot.setWorld(new MenuWorld());
        }
    }

    private void dibujar()
    {
        CarType c = GameData.autos[indice];
        boolean ok = c.desbloqueado();
        seleccionar.setActivo(ok);
        seleccionar.setTexto(ok ? "SELECCIONAR" : "BLOQUEADO");

        GreenfootImage f = getBackground();
        f.setColor(new Color(38, 40, 48));
        f.fill();

        // piso del garage
        f.setColor(new Color(52, 55, 65));
        f.fillRect(0, 360, GameData.ANCHO, GameData.ALTO - 360);
        f.setColor(new Color(70, 74, 86));
        for (int x = 0; x < GameData.ANCHO; x += 80) f.fillRect(x, 360, 3, GameData.ALTO - 360);

        // titulo
        f.setFont(new Font("Monospaced", true, false, 44));
        f.setColor(new Color(250, 205, 40));
        f.drawString("GARAGE", 40, 70);
        f.setFont(new Font("Monospaced", true, false, 18));
        f.setColor(Color.WHITE);
        f.drawString("PUNTOS TOTALES: " + GameData.puntajeTotal, 40, 100);

        // auto
        GreenfootImage img = c.imagen();
        img.scale(320, 240);
        if (!ok) img.setTransparency(70);
        f.drawImage(img, 170, 190);

        // datos
        f.setFont(new Font("Monospaced", true, false, 30));
        f.setColor(ok ? Color.WHITE : new Color(160, 160, 165));
        f.drawString(c.nombre + "  (" + (indice + 1) + "/" + GameData.autos.length + ")", 250, 150);

        barra(f, 540, 200, "VELOCIDAD", c.velocidad, new Color(230, 90, 70));
        barra(f, 540, 250, "MANEJO",    c.manejo,    new Color(90, 190, 240));

        f.setFont(new Font("Monospaced", true, false, 20));
        f.setColor(new Color(255, 200, 60));
        f.drawString("HABILIDAD: " + c.nombreHabilidad(), 250, 410);
        f.setFont(new Font("Monospaced", false, false, 17));
        f.setColor(Color.WHITE);
        f.drawString(c.descripcionHabilidad(), 250, 436);

        if (!ok) {
            f.setFont(new Font("Monospaced", true, false, 20));
            f.setColor(new Color(255, 110, 110));
            f.drawString("Necesitas " + c.puntajeDesbloqueo + " puntos totales", 250, 466);
        }
    }

    private void barra(GreenfootImage f, int x, int y, String etiqueta, int valor, Color color)
    {
        f.setFont(new Font("Monospaced", true, false, 15));
        f.setColor(Color.WHITE);
        f.drawString(etiqueta, x, y - 6);
        f.setColor(new Color(255, 255, 255, 60));
        f.fillRect(x, y, 200, 16);
        f.setColor(color);
        f.fillRect(x, y, valor * 20, 16);
        f.setColor(Color.BLACK);
        f.drawRect(x, y, 200, 16);
    }
}
