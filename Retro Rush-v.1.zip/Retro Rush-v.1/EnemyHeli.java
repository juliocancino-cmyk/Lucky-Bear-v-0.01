import greenfoot.*;

/**
 * Helicoptero enemigo. Vuela mas alto que la camara, asi que se proyecta
 * POR ENCIMA de la linea del horizonte: ese es el "arriba" al que
 * hay que disparar.
 *
 * El modelo depende del nivel (ver HeliTipo): cada 3 niveles aparece uno
 * mas duro, que aguanta mas balazos y dispara rafagas mas largas.
 */
public class EnemyHeli extends Objeto3D
{
    private HeliTipo tipo;
    private int vida;
    private int timerDisparo;
    private int flash = 0;
    private int rafagaRestante = 0;
    private int timerRafaga = 0;
    private double deriva;
    private double faseAltura;

    public EnemyHeli(HeliTipo tipo)
    {
        this.tipo = tipo;
        this.vida = tipo.vida;
        inicializar(Sprites.helicoptero(tipo), 1500, 750);

        x = -1400 + Greenfoot.getRandomNumber(2800);
        altura = 1700 + Greenfoot.getRandomNumber(700);
        z = 13000 + Greenfoot.getRandomNumber(5000);

        deriva = (Greenfoot.getRandomNumber(2) == 0 ? -1 : 1) * (8 + Greenfoot.getRandomNumber(10));
        faseAltura = Greenfoot.getRandomNumber(100);
        timerDisparo = tipo.cadencia / 2 + Greenfoot.getRandomNumber(60);
    }

    public void act()
    {
        RaceWorld w = (RaceWorld) getWorld();
        if (w == null || w.congelado()) return;

        z -= w.getVelocidad() * tipo.acercamiento;

        x += deriva;
        if (Math.abs(x) > 2400) deriva = -deriva;

        faseAltura += 0.05;
        altura += Math.sin(faseAltura) * 6;

        if (z < 900) { w.removeObject(this); return; }

        disparar(w);
        proyectar();

        if (flash > 0) flash--;
        getImage().setTransparency((flash > 0 && flash % 6 < 3) ? 130 : 255);
    }

    private void disparar(RaceWorld w)
    {
        PlayerCar j = w.getJugador();
        if (j == null) return;

        if (rafagaRestante > 0) {
            timerRafaga--;
            if (timerRafaga <= 0) {
                timerRafaga = 9;
                rafagaRestante--;
                w.addObject(new EnemyBullet(x, altura, z, j, tipo.dano), -500, -500);
            }
            return;
        }

        timerDisparo--;
        if (timerDisparo <= 0) {
            timerDisparo = tipo.cadencia + Greenfoot.getRandomNumber(50);
            rafagaRestante = tipo.rafaga;
            timerRafaga = 1;
        }
    }

    public void recibirDano(int d)
    {
        vida -= d;
        flash = 12;
        if (vida <= 0) destruir();
    }

    public void destruir()
    {
        RaceWorld w = (RaceWorld) getWorld();
        if (w == null) return;
        w.sumarPuntaje(tipo.puntos);
        w.addObject(new Explosion(x, altura, z, 1600), -500, -500);
        w.removeObject(this);
    }
}
