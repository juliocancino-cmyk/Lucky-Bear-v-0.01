import java.io.*;
import java.util.*;

/**
 * Estado global del juego. No es un Actor ni un World: solo guarda datos
 * que sobreviven entre mundos (menu -> carrera -> resultados).
 */
public class GameData
{
    public static final int ANCHO = 800;
    public static final int ALTO  = 600;
    public static final int NIVEL_MAX = 15;

    // ---- autos disponibles ----
    public static CarType[] autos = CarType.crearLista();
    public static int autoSeleccionado = 0;

    // ---- progreso ----
    public static int puntajeTotal   = 0;   // acumulado historico -> desbloquea autos
    public static int puntajeCarrera = 0;   // puntaje de la partida actual
    public static int nivelActual    = 1;
    public static long tiempoInicio  = 0;
    public static long tiempoTotalMs = 0;
    public static boolean completado = false;
    public static int ultimaPenalizacion = 0;

    /** Fraccion del puntaje total que se pierde al ser destruido. */
    public static final double PENALIZACION = 0.25;

    // ---- ranking ----
    public static List<RankEntry> ranking = new ArrayList<RankEntry>();
    private static final String ARCHIVO = "ranking.txt";
    private static boolean cargado = false;

    public static CarType auto()
    {
        return autos[autoSeleccionado];
    }

    public static void nuevaPartida()
    {
        puntajeCarrera = 0;
        nivelActual = 1;
        tiempoTotalMs = 0;
        completado = false;
        tiempoInicio = System.currentTimeMillis();
    }

    public static long tiempoActualMs()
    {
        if (tiempoInicio == 0) return 0;
        return System.currentTimeMillis() - tiempoInicio;
    }

    /**
     * Cierra la partida y guarda el resultado en el ranking.
     * Si ganaste, el puntaje de la carrera se suma al total.
     * Si perdiste, no se suma NADA y encima se descuenta un 25% del total.
     */
    public static void terminarPartida(boolean gano)
    {
        completado = gano;
        tiempoTotalMs = tiempoActualMs();

        if (gano) {
            puntajeTotal += puntajeCarrera;
            ultimaPenalizacion = 0;
        } else {
            ultimaPenalizacion = (int) (puntajeTotal * PENALIZACION);
            puntajeTotal -= ultimaPenalizacion;
            if (puntajeTotal < 0) puntajeTotal = 0;
        }

        RankEntry e = new RankEntry(auto().nombre, puntajeCarrera, tiempoTotalMs, gano);
        ranking.add(e);
        guardarRanking();
    }

    public static String formatoTiempo(long ms)
    {
        long total = ms / 100;          // decimas
        long min = total / 600;
        long seg = (total / 10) % 60;
        long dec = total % 10;
        return String.format("%02d:%02d.%d", min, seg, dec);
    }

    // ------------------------------------------------------------------
    // Persistencia simple en archivo de texto (funciona ejecutando local)
    // ------------------------------------------------------------------
    public static void cargarRanking()
    {
        if (cargado) return;
        cargado = true;
        BufferedReader br = null;
        try {
            File f = new File(ARCHIVO);
            if (!f.exists()) return;
            br = new BufferedReader(new FileReader(f));
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] p = linea.split(";");
                if (p.length >= 4) {
                    ranking.add(new RankEntry(p[0],
                                              Integer.parseInt(p[1]),
                                              Long.parseLong(p[2]),
                                              Boolean.parseBoolean(p[3])));
                }
            }
        } catch (Exception ex) {
            System.out.println("No se pudo leer el ranking: " + ex.getMessage());
        } finally {
            try { if (br != null) br.close(); } catch (Exception ignorada) {}
        }
    }

    public static void guardarRanking()
    {
        PrintWriter pw = null;
        try {
            pw = new PrintWriter(new FileWriter(ARCHIVO));
            for (RankEntry e : ranking) {
                pw.println(e.auto + ";" + e.puntaje + ";" + e.tiempoMs + ";" + e.completado);
            }
        } catch (Exception ex) {
            System.out.println("No se pudo guardar el ranking: " + ex.getMessage());
        } finally {
            if (pw != null) pw.close();
        }
    }

    /** Top por puntaje (mayor primero). */
    public static List<RankEntry> topPuntaje()
    {
        List<RankEntry> l = new ArrayList<RankEntry>(ranking);
        Collections.sort(l, new Comparator<RankEntry>() {
            public int compare(RankEntry a, RankEntry b) { return b.puntaje - a.puntaje; }
        });
        return l;
    }

    /** Top por tiempo (menor primero), solo partidas completadas. */
    public static List<RankEntry> topTiempo()
    {
        List<RankEntry> l = new ArrayList<RankEntry>();
        for (RankEntry e : ranking) if (e.completado) l.add(e);
        Collections.sort(l, new Comparator<RankEntry>() {
            public int compare(RankEntry a, RankEntry b) { return Long.compare(a.tiempoMs, b.tiempoMs); }
        });
        return l;
    }

    /** Top general: puntaje + bonus por rapidez. */
    public static List<RankEntry> topFinal()
    {
        List<RankEntry> l = new ArrayList<RankEntry>(ranking);
        Collections.sort(l, new Comparator<RankEntry>() {
            public int compare(RankEntry a, RankEntry b) { return b.puntajeFinal() - a.puntajeFinal(); }
        });
        return l;
    }
}
