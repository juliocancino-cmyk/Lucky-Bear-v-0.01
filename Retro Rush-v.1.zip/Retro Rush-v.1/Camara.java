import greenfoot.*;

/**
 * Camara pseudo-3D estilo Out Run.
 *
 * El mundo usa 3 coordenadas:
 *   x      = desplazamiento lateral (0 = centro de la ruta)
 *   altura = altura sobre el asfalto (0 = suelo)
 *   z      = profundidad, cuanto mas lejos hacia el horizonte
 *
 * La camara esta en z = 0, a una altura ALTURA, mirando hacia z positivo.
 * La proyeccion es la clasica division por la distancia:
 *
 *   escala   = FOCAL / z
 *   pantallaX = centro + (x - camX) * escala
 *   pantallaY = HORIZONTE + (ALTURA - altura) * escala
 *
 * Un objeto en el suelo (altura 0) queda debajo del horizonte, y uno mas
 * alto que la camara (un helicoptero) queda por encima. Eso es lo que
 * permite la mecanica de disparar hacia arriba.
 */
public class Camara
{
    /** Linea del horizonte en pixeles. */
    public static final int HORIZONTE = 235;

    /**
     * Distancia focal. NO es constante: cuanto mas rapido vamos, mas baja,
     * o sea mas gran angular. Ese cambio de campo de vision es lo que hace
     * que la velocidad se sienta de verdad.
     */
    public static double FOCAL = 280;
    public static final double FOCAL_BASE = 280;

    /** Altura de la camara sobre el asfalto. */
    public static final double ALTURA = 900;

    public static final int    CARRILES     = 4;
    public static final double ANCHO_CARRIL = 600;
    public static final double SEMI_RUTA    = ANCHO_CARRIL * CARRILES / 2.0;

    /** Profundidad fija a la que se dibuja el auto del jugador. */
    public static final double Z_JUGADOR = 820;

    /** Desplazamiento lateral de la camara (sigue al jugador con retraso). */
    public static double camX = 0;

    public static void reset()
    {
        camX = 0;
        FOCAL = FOCAL_BASE;
    }

    /** Ajusta el campo de vision segun la velocidad actual. */
    public static void ajustarPorVelocidad(double velocidad)
    {
        double objetivo = 318 - velocidad * 0.22;
        if (objetivo < 218) objetivo = 218;
        if (objetivo > 295) objetivo = 295;
        FOCAL += (objetivo - FOCAL) * 0.06;
    }

    /** La camara persigue al jugador suavemente: da sensacion de derrape. */
    public static void seguir(double xJugador)
    {
        camX += (xJugador - camX) * 0.10;
    }

    public static double escala(double z)
    {
        if (z < 150) z = 150;
        return FOCAL / z;
    }

    public static int px(double x, double z)
    {
        return (int) Math.round(GameData.ANCHO / 2.0 + (x - camX) * escala(z));
    }

    public static int py(double altura, double z)
    {
        return (int) Math.round(HORIZONTE + (ALTURA - altura) * escala(z));
    }

    /** Centro del carril indicado (0 = el de mas a la izquierda). */
    public static double centroCarril(int c)
    {
        return -SEMI_RUTA + ANCHO_CARRIL * c + ANCHO_CARRIL / 2.0;
    }
}
