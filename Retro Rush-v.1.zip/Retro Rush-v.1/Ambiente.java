import greenfoot.*;

/**
 * Efectos de ambiente animados que se pintan sobre el fondo:
 * nieve, lluvia, ceniza, hojas, arena, estrellas titilando y relampagos.
 * Tambien decide cada cuanto cruza un animal.
 */
public class Ambiente
{
    private static final int N = 110;

    private Palette p;
    private double[] px = new double[N];
    private double[] py = new double[N];
    private double[] vx = new double[N];
    private double[] vy = new double[N];
    private int[]    tam = new int[N];

    private int flash = 0;
    private int timerRayo;
    private int timerFauna;

    public Ambiente(Palette p)
    {
        this.p = p;
        for (int i = 0; i < N; i++) reciclar(i, true);
        timerRayo  = 200 + Greenfoot.getRandomNumber(300);
        timerFauna = 260 + Greenfoot.getRandomNumber(400);
    }

    private void reciclar(int i, boolean enCualquierParte)
    {
        px[i] = Greenfoot.getRandomNumber(GameData.ANCHO);
        py[i] = enCualquierParte ? Greenfoot.getRandomNumber(GameData.ALTO) : -10;

        switch (p.clima) {
            case Palette.NIEVE:
                vx[i] = -0.8 + Greenfoot.getRandomNumber(160) / 100.0;
                vy[i] = 1.0 + Greenfoot.getRandomNumber(180) / 100.0;
                tam[i] = 2 + Greenfoot.getRandomNumber(4);
                break;
            case Palette.LLUVIA:
                vx[i] = -1.6;
                vy[i] = 9 + Greenfoot.getRandomNumber(7);
                tam[i] = 8 + Greenfoot.getRandomNumber(8);
                break;
            case Palette.CENIZA:
                vx[i] = -1.2 + Greenfoot.getRandomNumber(240) / 100.0;
                vy[i] = 0.6 + Greenfoot.getRandomNumber(140) / 100.0;
                tam[i] = 2 + Greenfoot.getRandomNumber(3);
                break;
            case Palette.HOJAS:
                vx[i] = -2.4 + Greenfoot.getRandomNumber(120) / 100.0;
                vy[i] = 1.2 + Greenfoot.getRandomNumber(160) / 100.0;
                tam[i] = 4 + Greenfoot.getRandomNumber(5);
                break;
            case Palette.ARENA:
                vx[i] = -5 - Greenfoot.getRandomNumber(5);
                vy[i] = 0.3 + Greenfoot.getRandomNumber(90) / 100.0;
                tam[i] = 2 + Greenfoot.getRandomNumber(3);
                break;
            case Palette.ESTRELLAS:
                py[i] = Greenfoot.getRandomNumber(Camara.HORIZONTE - 20);
                vx[i] = 0; vy[i] = 0;
                tam[i] = 1 + Greenfoot.getRandomNumber(3);
                break;
            default:
                vx[i] = 0; vy[i] = 0; tam[i] = 0;
        }
    }

    /** Avanza y dibuja. Devuelve true si toca soltar un animal. */
    public boolean actualizar(GreenfootImage f, double velocidad)
    {
        dibujarParticulas(f, velocidad);
        dibujarRelampago(f);

        timerFauna--;
        if (timerFauna <= 0) {
            timerFauna = 320 + Greenfoot.getRandomNumber(420);
            return true;
        }
        return false;
    }

    private void dibujarParticulas(GreenfootImage f, double velocidad)
    {
        if (p.clima == Palette.SECO) return;

        double empuje = 1 + velocidad / 260.0;   // mas rapido = las particulas vuelan

        for (int i = 0; i < N; i++) {
            if (p.clima == Palette.ESTRELLAS) {
                int brillo = 120 + (int) (Math.sin((Greenfoot.getRandomNumber(2) + i) * 0.7
                                                   + System.currentTimeMillis() / 220.0) * 90);
                f.setColor(new Color(255, 255, 255, Math.max(40, Math.min(255, brillo))));
                f.fillRect((int) px[i], (int) py[i], tam[i], tam[i]);
                continue;
            }

            px[i] += vx[i] * empuje;
            py[i] += vy[i] * empuje;

            if (py[i] > GameData.ALTO || px[i] < -20 || px[i] > GameData.ANCHO + 20) {
                reciclar(i, false);
                continue;
            }

            switch (p.clima) {
                case Palette.NIEVE:
                    f.setColor(new Color(255, 255, 255, 210));
                    f.fillOval((int) px[i], (int) py[i], tam[i], tam[i]);
                    break;
                case Palette.LLUVIA:
                    f.setColor(new Color(190, 210, 250, 170));
                    f.fillRect((int) px[i], (int) py[i], 2, tam[i]);
                    break;
                case Palette.CENIZA:
                    f.setColor(new Color(255, 150, 60, 190));
                    f.fillRect((int) px[i], (int) py[i], tam[i], tam[i]);
                    break;
                case Palette.HOJAS:
                    f.setColor(new Color(p.copa.getRed(), p.copa.getGreen(), p.copa.getBlue(), 200));
                    f.fillOval((int) px[i], (int) py[i], tam[i] + 2, tam[i]);
                    break;
                case Palette.ARENA:
                    f.setColor(new Color(230, 205, 150, 130));
                    f.fillRect((int) px[i], (int) py[i], tam[i] + 4, 2);
                    break;
            }
        }
    }

    private void dibujarRelampago(GreenfootImage f)
    {
        if (!p.relampagos) return;

        if (flash > 0) {
            flash--;
            int a = flash > 4 ? 150 : flash * 30;
            f.setColor(new Color(255, 255, 255, a));
            f.fillRect(0, 0, GameData.ANCHO, GameData.ALTO);
            return;
        }

        timerRayo--;
        if (timerRayo <= 0) {
            timerRayo = 240 + Greenfoot.getRandomNumber(420);
            flash = 9;
        }
    }
}
