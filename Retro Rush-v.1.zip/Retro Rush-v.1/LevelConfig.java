/**
 * Dificultad de cada uno de los 15 niveles.
 * Las unidades son de MUNDO (las mismas que usa la camara), no pixeles.
 * Toca estos numeros para balancear el juego.
 */
public class LevelConfig
{
    public int nivel;
    public int distanciaObjetivo;   // cuanto hay que recorrer para pasar
    public double velocidadBase;    // unidades de mundo por frame
    public int framesTrafico;       // cada cuantos frames aparece un rival
    public int framesEnemigo;       // cada cuantos frames aparece un helicoptero
    public HeliTipo heli;           // modelo de helicoptero de este tramo
    public Palette paleta;

    private LevelConfig(int n)
    {
        nivel = n;

        // niveles largos: aprox. el doble que en la version anterior
        distanciaObjetivo = 4800 + n * 500;
        velocidadBase     = 116 + n * 8;
        framesTrafico     = Math.max(16, 74 - n * 3);
        framesEnemigo     = Math.max(70, 250 - n * 11);

        heli   = HeliTipo.paraNivel(n);   // hay helicopteros desde el nivel 1
        paleta = Palette.get(n);
    }

    public static LevelConfig get(int n)
    {
        if (n < 1) n = 1;
        if (n > GameData.NIVEL_MAX) n = GameData.NIVEL_MAX;
        return new LevelConfig(n);
    }
}
