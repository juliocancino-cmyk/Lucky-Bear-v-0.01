import greenfoot.*;

/**
 * Todos los sprites dibujados por codigo, ahora en VISTA TRASERA
 * (los vemos desde atras, como en Out Run).
 */
public class Sprites
{
    /**
     * Auto visto desde atras. Base 200x150; despues la camara lo escala.
     * Las cabezas de los personajes las dibuja aparte la clase Pilotos.
     */
    public static GreenfootImage autoTrasero(Color cuerpo, Color detalle)
    {
        int W = 200, H = 150;
        GreenfootImage img = new GreenfootImage(W, H);

        Color oscuro = mezclar(cuerpo, Color.BLACK, 0.45);

        // sombra en el piso
        img.setColor(new Color(0, 0, 0, 90));
        img.fillOval(8, 128, W - 16, 20);

        // ruedas
        img.setColor(new Color(22, 22, 26));
        img.fillRect(2, 92, 30, 46);
        img.fillRect(W - 32, 92, 30, 46);
        img.setColor(new Color(90, 92, 100));
        img.fillRect(6, 104, 22, 22);
        img.fillRect(W - 28, 104, 22, 22);

        // cabina
        img.setColor(cuerpo);
        img.fillRect(40, 30, W - 80, 50);
        // luneta trasera
        img.setColor(new Color(35, 45, 70));
        img.fillRect(50, 36, W - 100, 34);
        img.setColor(new Color(90, 130, 180, 120));
        img.fillRect(50, 36, W - 100, 12);

        // aleron
        img.setColor(detalle);
        img.fillRect(22, 74, W - 44, 12);
        img.setColor(oscuro);
        img.fillRect(34, 82, 10, 12);
        img.fillRect(W - 44, 82, 10, 12);

        // carroceria trasera
        img.setColor(cuerpo);
        img.fillRect(14, 88, W - 28, 42);
        img.setColor(oscuro);
        img.fillRect(14, 118, W - 28, 14);

        // luces traseras
        img.setColor(new Color(235, 60, 60));
        img.fillRect(24, 96, 46, 16);
        img.fillRect(W - 70, 96, 46, 16);
        img.setColor(new Color(255, 150, 150));
        img.fillRect(28, 99, 38, 5);

        // patente
        img.setColor(new Color(240, 240, 235));
        img.fillRect(82, 108, 36, 16);
        img.setColor(Color.BLACK);
        img.drawRect(82, 108, 36, 16);

        // contorno pixel
        img.setColor(Color.BLACK);
        img.drawRect(14, 88, W - 29, 42);
        img.drawRect(40, 30, W - 81, 50);

        return img;
    }

    /** Auto rival: mismo dibujo, sin pilotos asomados. */
    public static GreenfootImage rival(Color c)
    {
        return autoTrasero(c, mezclar(c, Color.BLACK, 0.5));
    }

    /**
     * Helicoptero visto de frente/abajo. Base 220x110.
     * El aspecto cambia segun el modelo: pods laterales, doble rotor
     * y blindaje se van sumando en los modelos avanzados.
     */
    public static GreenfootImage helicoptero(HeliTipo t)
    {
        int W = 220, H = 110;
        GreenfootImage img = new GreenfootImage(W, H);

        Color oscuro = mezclar(t.cuerpo, Color.BLACK, 0.4);

        // rotor principal (linea larga borrosa)
        img.setColor(new Color(40, 40, 45, 170));
        img.fillRect(0, 16, W, 6);
        img.setColor(new Color(40, 40, 45, 90));
        img.fillRect(0, 12, W, 14);

        if (t.dobleRotor) {                 // segundo rotor en tandem
            img.setColor(new Color(40, 40, 45, 140));
            img.fillRect(10, 4, W - 20, 5);
            img.setColor(new Color(40, 40, 45, 70));
            img.fillRect(10, 1, W - 20, 11);
        }

        // mastil
        img.setColor(oscuro);
        img.fillRect(W / 2 - 5, 22, 10, 14);

        // pods lanzacohetes
        if (t.pods) {
            img.setColor(oscuro);
            img.fillRect(W / 2 - 82, 52, 34, 16);
            img.fillRect(W / 2 + 48, 52, 34, 16);
            img.setColor(new Color(230, 120, 60));
            img.fillRect(W / 2 - 82, 56, 6, 8);
            img.fillRect(W / 2 + 76, 56, 6, 8);
        }

        // fuselaje
        img.setColor(t.cuerpo);
        img.fillOval(W / 2 - 46, 32, 92, 52);
        img.setColor(oscuro);
        img.fillOval(W / 2 - 46, 60, 92, 26);

        // placas de blindaje
        if (t.blindaje) {
            img.setColor(mezclar(t.cuerpo, Color.WHITE, 0.18));
            img.fillRect(W / 2 - 40, 46, 80, 8);
            img.fillRect(W / 2 - 34, 68, 68, 6);
            img.setColor(Color.BLACK);
            img.drawRect(W / 2 - 40, 46, 80, 8);
        }

        // cabina
        img.setColor(t.cabina);
        img.fillOval(W / 2 - 30, 40, 60, 30);
        img.setColor(mezclar(t.cabina, Color.BLACK, 0.45));
        img.fillOval(W / 2 - 26, 44, 52, 12);

        // patines
        img.setColor(new Color(45, 48, 50));
        img.fillRect(W / 2 - 54, 92, 108, 6);
        img.fillRect(W / 2 - 30, 84, 6, 10);
        img.fillRect(W / 2 + 24, 84, 6, 10);

        // luz
        img.setColor(new Color(240, 70, 70));
        img.fillOval(W / 2 - 6, 78, 12, 8);

        return img;
    }

    public static GreenfootImage bala()
    {
        GreenfootImage img = new GreenfootImage(30, 30);
        img.setColor(new Color(255, 170, 40));
        img.fillOval(0, 0, 30, 30);
        img.setColor(new Color(255, 240, 160));
        img.fillOval(6, 6, 18, 18);
        img.setColor(new Color(255, 250, 220));
        img.fillOval(10, 10, 10, 10);
        return img;
    }

    public static GreenfootImage balaEnemiga()
    {
        GreenfootImage img = new GreenfootImage(28, 28);
        img.setColor(new Color(255, 90, 90));
        img.fillOval(0, 0, 28, 28);
        img.setColor(new Color(255, 200, 200));
        img.fillOval(9, 9, 10, 10);
        return img;
    }

    public static GreenfootImage cohete()
    {
        GreenfootImage img = new GreenfootImage(40, 60);
        img.setColor(new Color(255, 190, 60));
        img.fillOval(8, 38, 24, 22);
        img.setColor(new Color(235, 235, 240));
        img.fillRect(12, 6, 16, 36);
        img.setColor(new Color(220, 55, 55));
        img.fillOval(10, 0, 20, 16);
        img.setColor(new Color(90, 92, 100));
        img.fillRect(4, 30, 8, 14);
        img.fillRect(28, 30, 8, 14);
        return img;
    }

    public static GreenfootImage explosion()
    {
        int S = 160;
        GreenfootImage img = new GreenfootImage(S, S);
        img.setColor(new Color(255, 120, 30, 230));
        img.fillOval(0, 0, S, S);
        img.setColor(new Color(255, 200, 70, 235));
        img.fillOval(S / 6, S / 6, S * 2 / 3, S * 2 / 3);
        img.setColor(new Color(255, 250, 220, 240));
        img.fillOval(S / 3, S / 3, S / 3, S / 3);
        return img;
    }

    /** Palmera / arbol lateral. Base 120x220, anclado abajo. */
    public static GreenfootImage arbol(Color copa, Color tronco)
    {
        GreenfootImage img = new GreenfootImage(120, 220);
        img.setColor(tronco);
        img.fillRect(52, 90, 16, 130);
        img.setColor(copa);
        img.fillOval(10, 10, 100, 96);
        img.setColor(mezclar(copa, Color.BLACK, 0.3));
        img.fillOval(24, 56, 72, 44);
        return img;
    }

    /** Cartel de ruta, para variar el paisaje. */
    public static GreenfootImage cartel(Color base)
    {
        GreenfootImage img = new GreenfootImage(120, 180);
        img.setColor(new Color(90, 90, 96));
        img.fillRect(54, 80, 12, 100);
        img.setColor(base);
        img.fillRect(6, 10, 108, 74);
        img.setColor(Color.BLACK);
        img.drawRect(6, 10, 108, 74);
        img.setColor(new Color(255, 255, 255, 200));
        img.fillRect(18, 28, 84, 12);
        img.fillRect(18, 50, 60, 12);
        return img;
    }

    /**
     * Animal que cruza la ruta. Vista lateral, base 220x150.
     * frame 0/1 alterna las patas; ave = true dibuja alas en vez de patas.
     */
    public static GreenfootImage animal(Palette p, int frame, boolean miraIzquierda)
    {
        int W = 220, H = 150;
        GreenfootImage img = new GreenfootImage(W, H);
        Color c = p.faunaCuerpo;
        Color d = p.faunaDetalle;

        if (p.faunaVuela) {
            // cuerpo
            img.setColor(c);
            img.fillOval(80, 62, 74, 30);
            img.fillOval(140, 52, 34, 28);          // cabeza
            img.setColor(d);
            img.fillPolygon(new int[]{170, 196, 172}, new int[]{62, 68, 74}, 3);  // pico
            // alas que baten
            img.setColor(c);
            if (frame == 0) {
                img.fillPolygon(new int[]{92, 40, 130}, new int[]{68, 18, 74}, 3);
                img.fillPolygon(new int[]{92, 46, 130}, new int[]{80, 118, 86}, 3);
            } else {
                img.fillPolygon(new int[]{92, 62, 130}, new int[]{68, 46, 74}, 3);
                img.fillPolygon(new int[]{92, 66, 130}, new int[]{80, 96, 86}, 3);
            }
            img.setColor(d);
            img.fillPolygon(new int[]{80, 34, 82}, new int[]{68, 78, 88}, 3);     // cola
        } else {
            // sombra
            img.setColor(new Color(0, 0, 0, 70));
            img.fillOval(46, 132, 130, 14);
            // patas
            img.setColor(d);
            int a = frame == 0 ? 0 : 12;
            img.fillRect(62 + a, 96, 15, 40);
            img.fillRect(94 - a, 96, 15, 40);
            img.fillRect(134 + a, 96, 15, 40);
            img.fillRect(160 - a, 96, 15, 40);
            // cuerpo
            img.setColor(c);
            img.fillOval(52, 52, 132, 58);
            img.fillOval(150, 34, 52, 46);          // cabeza
            img.setColor(d);
            img.fillOval(158, 24, 18, 18);          // oreja
            img.fillOval(184, 26, 16, 16);
            img.fillRect(28, 60, 34, 12);           // cola
            img.setColor(Color.BLACK);
            img.fillOval(178, 48, 8, 8);            // ojo
        }

        if (miraIzquierda) img.mirrorHorizontally();
        return img;
    }

    /** Nave del jefe final. Base 420x200. */
    public static GreenfootImage jefe(int fase)
    {
        int W = 420, H = 200;
        GreenfootImage img = new GreenfootImage(W, H);

        Color casco = fase >= 3 ? new Color(120, 30, 40)
                    : fase == 2 ? new Color(80, 60, 70)
                                : new Color(62, 66, 74);

        // rotores dobles
        img.setColor(new Color(35, 35, 40, 160));
        img.fillRect(10, 22, 180, 7);
        img.fillRect(230, 22, 180, 7);
        img.setColor(new Color(35, 35, 40, 80));
        img.fillRect(10, 16, 180, 19);
        img.fillRect(230, 16, 180, 19);

        // casco principal
        img.setColor(casco);
        img.fillOval(70, 46, 280, 96);
        img.setColor(Sprites.mezclar(casco, Color.BLACK, 0.35));
        img.fillOval(70, 100, 280, 48);
        img.fillRect(150, 30, 120, 26);

        // cabina blindada
        img.setColor(new Color(255, 90, 90));
        img.fillOval(168, 62, 84, 38);
        img.setColor(new Color(120, 20, 30));
        img.fillOval(176, 68, 68, 14);

        // torretas
        img.setColor(new Color(40, 42, 48));
        for (int i = 0; i < 3; i++) {
            int off = 96 + i * 44;
            img.fillRect(210 - off - 16, 108, 34, 14);
            img.fillRect(210 + off - 18, 108, 34, 14);
        }

        // luces de fase
        img.setColor(fase >= 3 ? new Color(255, 200, 60) : new Color(120, 220, 255));
        for (int i = 0; i < 6; i++) img.fillOval(96 + i * 44, 132, 12, 10);

        // patines
        img.setColor(new Color(45, 48, 52));
        img.fillRect(96, 158, 228, 9);
        img.fillRect(140, 146, 9, 14);
        img.fillRect(272, 146, 9, 14);

        return img;
    }

    /** Mezcla dos colores; util para sombras y brillos. */
    public static Color mezclar(Color a, Color b, double f)
    {
        int r = (int) (a.getRed()   * (1 - f) + b.getRed()   * f);
        int g = (int) (a.getGreen() * (1 - f) + b.getGreen() * f);
        int z = (int) (a.getBlue()  * (1 - f) + b.getBlue()  * f);
        return new Color(r, g, z);
    }
}
