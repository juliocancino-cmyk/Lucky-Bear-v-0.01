import greenfoot.*;

/** Creditos y explicacion de controles. */
public class CreditsWorld extends World
{
    private MenuButton volver;

    public CreditsWorld()
    {
        super(GameData.ANCHO, GameData.ALTO, 1);
        volver = new MenuButton("VOLVER", "back", 180, 54);
        addObject(volver, 120, 560);
        dibujar();
    }

    public void act()
    {
        if (volver.fueClickeado()) Greenfoot.setWorld(new MenuWorld());
    }

    private void dibujar()
    {
        GreenfootImage f = getBackground();
        f.setColor(new Color(24, 26, 38));
        f.fill();

        f.setFont(new Font("Monospaced", true, false, 42));
        f.setColor(new Color(250, 205, 40));
        f.drawString("CONTROLES", 40, 70);

        f.setFont(new Font("Monospaced", true, false, 18));
        f.setColor(Color.WHITE);
        String[] lineas = {
            "IZQ / DER  ->  cambiar de carril",
            "SPACE      ->  disparar (10 balas, se reponen solas)",
            "X          ->  bazuca a un auto, o al jefe final",
            "SHIFT      ->  nitro, mantenido (misma barra que la bazuca)",
            "P o ESC    ->  pausa",
            "",
            "Rozar un auto sin tocarlo  ->  40 a 160 pts, mas cuanto mas al filo",
            "Chocarlo                   ->  vida y velocidad por el piso",
            "Rebasar +150   Helicoptero +300 a +950   Jefe final +12000",
            "",
            "Si te destruyen: perdes el 25% del puntaje total y volves al nivel 1."
        };
        int y = 140;
        for (String l : lineas) { f.drawString(l, 40, y); y += 34; }

        f.setFont(new Font("Monospaced", false, false, 16));
        f.setColor(new Color(180, 185, 200));
        f.drawString("RETRO RUSH - proyecto Greenfoot", 50, 520);
    }
}
