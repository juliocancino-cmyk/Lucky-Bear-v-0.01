import greenfoot.*;

/**
 * Pantalla de derrota. Perder duele: se pierde el 25% del puntaje total
 * acumulado y la carrera vuelve a empezar desde el nivel 1.
 */
public class DefeatWorld extends World
{
    private MenuButton reintentar, alMenu;
    private int nivelCaido;
    private int penalizacion;
    private int puntajeCarrera;

    public DefeatWorld()
    {
        super(GameData.ANCHO, GameData.ALTO, 1);

        nivelCaido     = Math.min(GameData.nivelActual, GameData.NIVEL_MAX);
        penalizacion   = GameData.ultimaPenalizacion;
        puntajeCarrera = GameData.puntajeCarrera;

        reintentar = new MenuButton("DESDE EL NIVEL 1", "retry", 320, 60);
        alMenu     = new MenuButton("MENU",             "menu", 200, 56);

        addObject(reintentar, 400, 452);
        addObject(alMenu,     400, 522);

        dibujar();
    }

    public void act()
    {
        if (reintentar.fueClickeado()) {
            GameData.nuevaPartida();
            Greenfoot.setWorld(new RaceWorld());
        } else if (alMenu.fueClickeado()) {
            Greenfoot.setWorld(new MenuWorld());
        }
    }

    private void dibujar()
    {
        GreenfootImage f = getBackground();
        f.setColor(new Color(26, 12, 14));
        f.fill();

        // franjas rojas de fondo
        f.setColor(new Color(60, 18, 22));
        for (int y = 0; y < GameData.ALTO; y += 26) f.fillRect(0, y, GameData.ANCHO, 12);

        f.setFont(new Font("Monospaced", true, false, 66));
        f.setColor(new Color(0, 0, 0, 160));
        f.drawString("DESTRUIDO", 154, 116);
        f.setColor(new Color(238, 70, 70));
        f.drawString("DESTRUIDO", 150, 112);

        f.setFont(new Font("Monospaced", true, false, 24));
        f.setColor(Color.WHITE);
        f.drawString("Caiste en el nivel " + nivelCaido + " de " + GameData.NIVEL_MAX, 150, 176);
        f.drawString("Puntaje de la carrera: " + puntajeCarrera + "  (perdido)", 150, 212);

        f.setColor(new Color(255, 140, 140));
        f.drawString("PENALIZACION: -" + penalizacion + " puntos totales", 150, 262);
        f.setColor(Color.WHITE);
        f.drawString("Te quedan " + GameData.puntajeTotal + " puntos totales", 150, 296);

        f.setFont(new Font("Monospaced", false, false, 17));
        f.setColor(new Color(210, 190, 190));
        f.drawString("Si bajaste del umbral de un auto, se vuelve a bloquear.", 150, 344);
        f.drawString("La proxima carrera arranca otra vez desde el nivel 1.", 150, 368);
    }
}
