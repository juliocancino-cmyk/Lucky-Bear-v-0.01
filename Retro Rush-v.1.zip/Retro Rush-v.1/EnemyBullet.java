import greenfoot.*;

/**
 * Disparo del helicoptero. Viaja hacia la camara (z baja) y baja de altura
 * hasta la posicion del jugador.
 */
public class EnemyBullet extends Objeto3D
{
    private double vx, vAltura;
    private double vz = -380;
    private int vida = 140;
    private int dano;

    public EnemyBullet(double x, double altura, double z, PlayerCar destino, int dano)
    {
        this.dano = dano;
        this.x = x;
        this.altura = altura;
        this.z = z;
        inicializar(Sprites.balaEnemiga(), 190, 190);

        double t = Math.max(12, (z - Camara.Z_JUGADOR) / -vz);
        vx      = (destino.getX3D() - x) / t;
        vAltura = (150 - altura) / t;
    }

    public void act()
    {
        RaceWorld w = (RaceWorld) getWorld();
        if (w == null || w.congelado()) return;

        z += vz;
        x += vx;
        altura += vAltura;
        vida--;

        PlayerCar j = w.getJugador();
        if (j != null && Math.abs(z - Camara.Z_JUGADOR) < 320
                      && Math.abs(x - j.getX3D()) < 300
                      && altura < 500) {
            j.recibirDano(dano);
            w.addObject(new Explosion(x, 150, z, 600), -500, -500);
            w.removeObject(this);
            return;
        }

        if (vida <= 0 || z < 250) { w.removeObject(this); return; }

        proyectar();
    }
}
