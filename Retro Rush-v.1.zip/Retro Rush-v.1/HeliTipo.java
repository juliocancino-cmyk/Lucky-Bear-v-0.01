import greenfoot.*;

/**
 * Modelos de helicoptero. Cada 3 niveles aparece uno nuevo, mas duro,
 * que aguanta mas balazos y dispara rafagas mas largas.
 *
 * Ademas de las estadisticas, guarda los rasgos VISUALES que usa
 * Sprites.helicoptero() para que cada modelo se vea distinto:
 * pods lanzacohetes, placas de blindaje y rotor doble en tandem.
 */
public class HeliTipo
{
    // --- estadisticas de combate ---
    public String nombre;
    public int vida;
    public int dano;
    public int cadencia;        // frames entre rafagas
    public int rafaga;          // disparos por rafaga
    public int puntos;
    public double acercamiento; // que tan rapido se te viene encima

    // --- aspecto ---
    public Color cuerpo;
    public Color cabina;
    public Color vidrio;        // alias de cabina, por compatibilidad
    public int canones;
    public boolean pods;
    public boolean blindaje;
    public boolean dobleRotor;

    public HeliTipo(String nombre, int vida, int dano, int cadencia, int rafaga,
                    int puntos, double acercamiento,
                    Color cuerpo, Color cabina,
                    int canones, boolean pods, boolean blindaje, boolean dobleRotor)
    {
        this.nombre = nombre;
        this.vida = vida;
        this.dano = dano;
        this.cadencia = cadencia;
        this.rafaga = rafaga;
        this.puntos = puntos;
        this.acercamiento = acercamiento;

        this.cuerpo = cuerpo;
        this.cabina = cabina;
        this.vidrio = cabina;
        this.canones = canones;
        this.pods = pods;
        this.blindaje = blindaje;
        this.dobleRotor = dobleRotor;
    }

    /** Que modelo toca segun el nivel. */
    public static HeliTipo paraNivel(int n)
    {
        if (n <= 3)  return new HeliTipo("EXPLORADOR", 1, 10, 110, 1, 300, 0.45,
                                         new Color(96, 118, 92), new Color(140, 220, 245),
                                         0, false, false, false);

        if (n <= 6)  return new HeliTipo("CAZA",       2, 13,  92, 1, 420, 0.55,
                                         new Color(70, 86, 110), new Color(150, 230, 250),
                                         1, true, false, false);

        if (n <= 9)  return new HeliTipo("ARTILLERO",  3, 15,  76, 2, 560, 0.62,
                                         new Color(112, 92, 60), new Color(255, 200, 120),
                                         2, true, true, false);

        if (n <= 12) return new HeliTipo("ACORAZADO",  5, 17,  64, 2, 720, 0.70,
                                         new Color(76, 76, 84), new Color(200, 220, 240),
                                         2, true, true, true);

        return              new HeliTipo("SEGADOR",    7, 21,  52, 3, 950, 0.80,
                                         new Color(58, 30, 46), new Color(255, 110, 140),
                                         3, true, true, true);
    }
}


