import greenfoot.*;

/**
 * Explosion en el mundo 3D: crece, hace dano en area una sola vez
 * y se desvanece.
 */
public class Explosion extends Objeto3D
{
    private double radio;
    private int frame = 0;
    private boolean daniado = false;

    public Explosion(double x, double altura, double z, double radio)
    {
        this.x = x;
        this.altura = altura;
        this.z = z;
        this.radio = radio;
        inicializar(Sprites.explosion(), radio, radio);
    }

    public void act()
    {
        RaceWorld w = (RaceWorld) getWorld();
        if (w == null || w.congelado()) return;

        frame++;

        if (!daniado) {
            daniado = true;
            for (RivalCar r : w.getObjects(RivalCar.class)) {
                if (distanciaA(r) < radio * 1.3) r.destruir();
            }
        }

        // crece y se apaga
        anchoMundo = radio * (0.5 + frame * 0.22);
        altoMundo  = anchoMundo;
        proyectar();
        getImage().setTransparency(Math.max(0, 255 - frame * 17));

        if (frame > 15) w.removeObject(this);
    }
}
