import greenfoot.*;

/**
 * Animaciones de los dos personajes que van dentro del auto.
 *
 * Funciona como una maquina de estados: cada cierto tiempo elige una
 * animacion al azar (arreglarse el pelo, besarse, pelearse, discutir,
 * tirar cosas por la ventana, saludar, dormirse) y la reproduce.
 * Disparar o usar la bazuca fuerzan una animacion que tiene prioridad.
 *
 * Todo se dibuja sobre la imagen base del auto, de 200x150.
 */
public class Pilotos
{
    public static final int QUIETO    = 0;
    public static final int PELO      = 1;
    public static final int BESO      = 2;
    public static final int PELEA     = 3;
    public static final int DISCUSION = 4;
    public static final int TIRAR     = 5;
    public static final int SALUDAR   = 6;
    public static final int DORMIR    = 7;
    public static final int DISPARAR  = 8;
    public static final int BAZUCA    = 9;

    // posiciones base de las cabezas dentro del sprite del auto
    private static final int PX = 78, PY = 38;    // piloto
    private static final int CX = 124, CY = 34;   // copiloto

    private static final Color PIEL_A = new Color(228, 186, 146);
    private static final Color PIEL_B = new Color(244, 206, 172);
    private static final Color PELO_A = new Color(58, 42, 30);
    private static final Color PELO_B = new Color(234, 200, 72);

    private int estado = QUIETO;
    private int t = 0;
    private int duracion = 220;
    private int forzado = 0;

    public void act()
    {
        t++;
        if (forzado > 0) {
            forzado--;
            if (forzado == 0) elegirNuevo();
            return;
        }
        if (t >= duracion) elegirNuevo();
    }

    /** Interrumpe la animacion actual (disparo, bazuca). */
    public void forzar(int nuevo, int frames)
    {
        estado = nuevo;
        t = 0;
        duracion = frames;
        forzado = frames;
    }

    private void elegirNuevo()
    {
        int r = Greenfoot.getRandomNumber(100);
        if      (r < 34) { estado = QUIETO;    duracion = 180 + Greenfoot.getRandomNumber(220); }
        else if (r < 44) { estado = PELO;      duracion = 260; }
        else if (r < 53) { estado = BESO;      duracion = 300; }
        else if (r < 64) { estado = PELEA;     duracion = 250; }
        else if (r < 75) { estado = DISCUSION; duracion = 280; }
        else if (r < 86) { estado = TIRAR;     duracion = 270; }
        else if (r < 94) { estado = SALUDAR;   duracion = 240; }
        else             { estado = DORMIR;    duracion = 340; }
        t = 0;
    }

    public int getEstado() { return estado; }

    // ==================================================================
    // DIBUJO
    // ==================================================================
    public void dibujar(GreenfootImage img)
    {
        double f = duracion > 0 ? Math.min(1.0, (double) t / duracion) : 0;
        int bob = (int) (Math.sin(t * 0.14) * 2);

        int dpx = 0, dpy = 0, dcx = 0, dcy = 0;

        switch (estado) {
            case BESO: {
                double a = f < 0.35 ? f / 0.35 : (f > 0.75 ? (1 - f) / 0.25 : 1);
                a = Math.max(0, Math.min(1, a));
                dpx = (int) (16 * a);  dpy = (int) (-3 * a);
                dcx = (int) (-16 * a); dcy = (int) (3 * a);
                break;
            }
            case PELEA: {
                int s = (int) (Math.sin(t * 0.22) * 9);
                dpx = s;  dcx = -s;
                dpy = (int) (Math.cos(t * 0.36) * 2);
                dcy = (int) (Math.sin(t * 0.36) * 2);
                break;
            }
            case DISCUSION: {
                dpx = -7; dcx = 7;
                dpy = (int) (Math.sin(t * 0.32) * 2);
                dcy = (int) (Math.sin(t * 0.24 + 1) * 2);
                break;
            }
            case PELO: {
                dcy = (int) (Math.sin(t * 0.11) * 2);
                break;
            }
            case DORMIR: {
                dcy = 5; dcx = -3;
                break;
            }
            case DISPARAR: {
                dcx = 5; dcy = -3;
                break;
            }
            case BAZUCA: {
                dcx = 2; dcy = -8;
                break;
            }
        }

        // brazos / objetos que van DETRAS de las cabezas
        if (estado == BAZUCA) dibujarBazuca(img);

        cabeza(img, PX + dpx, PY + dpy + bob, PELO_A, PIEL_A, false);
        cabeza(img, CX + dcx, CY + dcy + bob, PELO_B, PIEL_B, estado == PELO);

        // efectos que van ENCIMA
        switch (estado) {
            case BESO:      corazones(img, f);              break;
            case PELEA:     chispas(img);                   break;
            case DISCUSION: signos(img);                    break;
            case PELO:      brazoPelo(img, bob);            break;
            case TIRAR:     tirarBasura(img);               break;
            case SALUDAR:   brazoSaludo(img);               break;
            case DORMIR:    zetas(img);                     break;
            case DISPARAR:  pistola(img);                   break;
        }
    }

    private void cabeza(GreenfootImage img, int cx, int cy, Color pelo, Color piel, boolean melena)
    {
        int r = 22;
        img.setColor(pelo);
        img.fillOval(cx - r / 2 - 3, cy - r / 2 - 6, r + 6, r + 6);
        if (melena) {
            img.fillOval(cx - r / 2 - 7, cy - 2, 10, 16);
            img.fillOval(cx + r / 2 - 2, cy - 2, 10, 16);
        }
        img.setColor(piel);
        img.fillOval(cx - r / 2, cy - r / 2, r, r);
        img.setColor(new Color(0, 0, 0, 60));
        img.drawOval(cx - r / 2, cy - r / 2, r, r);
    }

    private void corazones(GreenfootImage img, double f)
    {
        for (int i = 0; i < 3; i++) {
            int fase = (t + i * 44) % 132;
            int hy = 26 - fase / 5;
            int hx = 100 + (i - 1) * 14 + (int) (Math.sin(fase * 0.07) * 4);
            int alpha = Math.max(0, 220 - fase);
            img.setColor(new Color(235, 60, 100, alpha));
            img.fillOval(hx, hy, 8, 8);
            img.fillOval(hx + 5, hy, 8, 8);
            img.fillRect(hx + 1, hy + 4, 11, 7);
        }
    }

    private void chispas(GreenfootImage img)
    {
        if ((t / 12) % 2 != 0) return;
        int cx = 102, cy = 26;
        img.setColor(new Color(255, 235, 80));
        int[] xs = { cx, cx + 6, cx + 16, cx + 8, cx + 11, cx, cx - 11, cx - 8, cx - 16, cx - 6 };
        int[] ys = { cy - 14, cy - 5, cy - 4, cy + 3, cy + 13, cy + 7, cy + 13, cy + 3, cy - 4, cy - 5 };
        img.fillPolygon(xs, ys, 10);
    }

    private void signos(GreenfootImage img)
    {
        img.setFont(new Font("Monospaced", true, false, 26));
        boolean turno = (t / 48) % 2 == 0;
        img.setColor(new Color(255, 90, 90));
        img.drawString(turno ? "!" : " ", 66, 22);
        img.setColor(new Color(120, 200, 255));
        img.drawString(turno ? " " : "?", 132, 18);
    }

    private void brazoPelo(GreenfootImage img, int bob)
    {
        img.setColor(new Color(244, 206, 172));
        img.fillRect(136, 26 + bob, 7, 18);
        img.fillRect(136, 22 + bob, 14, 7);
    }

    private void brazoSaludo(GreenfootImage img)
    {
        int sway = (int) (Math.sin(t * 0.2) * 6);
        img.setColor(new Color(244, 206, 172));
        img.fillRect(140, 20, 7, 20);
        img.fillOval(138 + sway, 10, 12, 12);
    }

    private void tirarBasura(GreenfootImage img)
    {
        // brazo hacia afuera
        img.setColor(new Color(244, 206, 172));
        img.fillRect(140, 34, 18, 7);

        // la lata sale volando hacia atras y se achica
        if (t > 70) {
            int k = t - 70;
            int bx = 158 + k * 2;
            int by = 36 + (int) (k * k * 0.014);
            int tam = Math.max(2, 11 - k / 11);
            if (bx < 200 && by < 150) {
                img.setColor(new Color(180, 185, 195));
                img.fillRect(bx, by, tam, tam + 3);
                img.setColor(new Color(90, 95, 105));
                img.fillRect(bx, by, tam, 2);
            }
        }
    }

    private void zetas(GreenfootImage img)
    {
        img.setFont(new Font("Monospaced", true, false, 20));
        for (int i = 0; i < 3; i++) {
            int fase = (t + i * 46) % 150;
            int alpha = Math.max(0, 210 - fase);
            img.setColor(new Color(255, 255, 255, alpha));
            img.drawString("z", 138 + i * 5, 30 - fase / 7);
        }
    }

    private void pistola(GreenfootImage img)
    {
        img.setColor(new Color(244, 206, 172));
        img.fillRect(138, 30, 16, 7);
        img.setColor(new Color(45, 48, 55));
        img.fillRect(150, 26, 18, 8);
        if (t < 6) {
            img.setColor(new Color(255, 220, 120, 220));
            img.fillOval(162, 20, 22, 20);
        }
    }

    private void dibujarBazuca(GreenfootImage img)
    {
        img.setColor(new Color(58, 62, 58));
        img.fillRect(112, 20, 74, 13);
        img.setColor(new Color(38, 42, 38));
        img.fillRect(176, 17, 12, 19);
        img.setColor(new Color(244, 206, 172));
        img.fillRect(130, 30, 10, 10);
        if (t < 8) {
            img.setColor(new Color(255, 200, 90, 210));
            img.fillOval(182, 12, 26, 26);
            img.setColor(new Color(140, 140, 150, 150));
            img.fillOval(90, 16, 26, 22);
        }
    }
}
