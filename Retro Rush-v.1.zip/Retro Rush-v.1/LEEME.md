# RETRO RUSH — carreras arcade pseudo-3D en Greenfoot

Juego de carreras estilo Out Run con cámara detrás del auto, 15 niveles,
jefe final, garage con autos desbloqueables y ranking persistente.
No necesita imágenes externas: todos los sprites se dibujan por código.

## Montarlo en Greenfoot

1. Crea un escenario vacío (**Scenario → New...**).
2. Copia los 30 `.java` junto a `project.greenfoot`.
3. Cierra y vuelve a abrir el escenario, y pulsa **Compile All**.
4. Clic derecho en **MenuWorld → `new MenuWorld()`**, y luego **Run**.
5. Borra la clase `MyWorld` que Greenfoot crea por defecto.

## Controles

| Tecla | Acción |
|---|---|
| ← → | cambiar de carril (4 carriles) |
| SPACE | disparar — 10 balas, cadencia de 9 frames, se reponen solas |
| X | bazuca contra un auto de adelante, o contra el jefe final |
| SHIFT | nitro, se mantiene apretado |
| P o ESC | pausa |

NITRO y BAZUCA comparten la misma barra. Es la decisión táctica del juego:
gastarla en velocidad para hacer tiempo, o guardarla para reventar el auto
que te tapa el carril.

## Munición

10 balas. Cada disparo gasta una y hay 9 frames de espera entre tiros.
Se repone una bala cada 55 frames. Si te quedas en cero entra una recarga
completa de 130 frames en la que no puedes disparar nada.

## Helicópteros

Hay desde el nivel 1 y cambian de modelo cada 3 niveles. El nombre del
modelo actual sale arriba a la derecha del HUD.

| Niveles | Modelo | Vida | Daño | Ráfaga | Puntos |
|---|---|---|---|---|---|
| 1-3 | EXPLORADOR | 1 | 10 | 1 | 300 |
| 4-6 | CAZA | 2 | 13 | 1 | 420 |
| 7-9 | ARTILLERO | 3 | 15 | 2 | 560 |
| 10-12 | ACORAZADO | 5 | 17 | 2 | 720 |
| 13-15 | SEGADOR | 7 | 21 | 3 | 950 |

Los cañones laterales del sprite se dibujan solos según el poder del modelo.

## Jefe final

Al terminar la distancia del nivel 15 no ganas: aparece el jefe y hay que
derribarlo. 130 de vida, 3 fases. Cada fase se mueve más rápido, dispara
ráfagas más largas y manda escoltas más seguido. Las balas hacen 1 de daño
y la bazuca 14, así que conviene guardar la barra para él.

## Fondos animados

Cada nivel tiene su clima: nieve, lluvia, ceniza, hojas, arena o estrellas
titilando. Tormenta e Infierno además tienen relámpagos que iluminan toda
la pantalla. Cada 320-740 frames cruza un animal por la ruta, distinto
según la ambientación (gaviota en la playa, oso en el bosque, camello en
el desierto, cóndor en el cañón). Es decorativo, no choca.

## Cómo se puntúa

| Acción | Puntos |
|---|---|
| Rozar un auto sin tocarlo | 40 a 160, más cuanto más al filo |
| Rebasar un rival | 150 |
| Derribar un helicóptero | 300 a 950 según el modelo |
| Reventar un auto con la bazuca | 300 |
| Completar un nivel | 1000 + 250 × nivel |
| Derribar al jefe final | 12000 |

Chocar cuesta 22 de energía y **la mitad de la velocidad**. Recuperarla
tarda varios segundos, así que un choque cuesta mucho más tiempo que vida.

## Derrota

Si la energía llega a cero: pierdes todo el puntaje de la carrera, se te
descuenta el **25% del puntaje total acumulado** y vuelves al nivel 1.
Si eso te baja del umbral de un auto, el auto se vuelve a bloquear.

## Estructura

```
Camara       proyección pseudo-3D (x lateral, altura, z profundidad)
Objeto3D     clase padre de todo lo que vive en la ruta
Sprites      dibujos por código
Pilotos      animaciones idle de los dos personajes del auto
Ambiente     clima animado, relámpagos y aparición de fauna
GameData     estado global, ranking en archivo
CarType      autos jugables      HeliTipo     modelos de helicóptero
LevelConfig  dificultad de los 15 niveles
Palette      color, clima y fauna de cada nivel
RankEntry    fila del ranking

RaceWorld    el juego: ruta, velocidad, spawns, pausa, niveles, jefe
PlayerCar    tu auto      RivalCar   tráfico     EnemyHeli  enemigo aéreo
Boss         jefe final   Fauna      animal decorativo
Bullet / EnemyBullet / Rocket / Explosion / PopText
HudOverlay   interfaz y panel de pausa

MenuWorld  GarageWorld  RankingWorld  ResultWorld  DefeatWorld  CreditsWorld
MenuButton
```

## Dónde tocar primero

- **Duración de los niveles:** `distanciaObjetivo` en `LevelConfig.java`.
- **Sensación de velocidad:** `Camara.ajustarPorVelocidad()` y el `ritmo`
  de `RaceWorld.acelerar()`.
- **Munición:** las constantes `BALAS_MAX`, `CADENCIA`, `REGENERACION` y
  `RECARGA` arriba de `PlayerCar.java`.
- **Helicópteros:** `HeliTipo.paraNivel()`.
- **Jefe:** `Boss.VIDA_MAX` y el método `atacar()`.
- **Clima y animales:** `Palette.get()` y `Ambiente.java`.
- **Animaciones de los personajes:** `Pilotos.elegirNuevo()` para las
  probabilidades y duraciones, `dibujar()` para el dibujo.
- **Roce vs choque:** `DIST_ROCE` y `DIST_CHOQUE` en `PlayerCar`.
- **Castigo por perder:** `GameData.PENALIZACION`.

## Notas

- El ranking se guarda en `ranking.txt` en la carpeta del escenario.
- Si el render de la ruta te va lento, sube `int paso = 2` a `4` en
  `RaceWorld.dibujarRuta()`. Lo segundo más caro es `Ambiente`: baja la
  constante `N` de 110 a 60.
