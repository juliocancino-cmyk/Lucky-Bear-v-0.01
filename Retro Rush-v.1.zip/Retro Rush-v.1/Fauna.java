import greenfoot.*;

/**
 * Animal que cruza la ruta de golpe. Es solo decorativo: no choca ni
 * hace dano, pero rompe la monotonia del fondo. Cada ambientacion
 * tiene el suyo (oso en el bosque, camello en el desierto, etc).
 */
public class Fauna extends Objeto3D
{
    private double vx;
    private int frame = 0;
    private int contadorFrame = 0;
    private Palette paleta;

    public Fauna(Palette p, double z)
    {
        this.paleta = p;
        this.z = z;
        this.altura = p.faunaVuela ? 900 + Greenfoot.getRandomNumber(600) : 0;

        boolean desdeIzquierda = Greenfoot.getRandomNumber(2) == 0;
        double borde = Camara.SEMI_RUTA + 1400;
        this.x = desdeIzquierda ? -borde : borde;
        this.vx = (desdeIzquierda ? 1 : -1) * (18 + Greenfoot.getRandomNumber(14));

        inicializar(Sprites.animal(paleta, 0, vx < 0), 1000, 700);
    }

    public void act()
    {
        RaceWorld w = (RaceWorld) getWorld();
        if (w == null) return;
        if (w.congelado()) return;

        z -= w.getVelocidad() * 0.9;
        x += vx;

        // animacion de las patas
        contadorFrame++;
        if (contadorFrame >= 7) {
            contadorFrame = 0;
            frame = (frame + 1) % 2;
            setBase(Sprites.animal(paleta, frame, vx < 0));
        }

        double borde = Camara.SEMI_RUTA + 1700;
        if (z < 500 || Math.abs(x) > borde) { w.removeObject(this); return; }

        proyectar();
    }
}
