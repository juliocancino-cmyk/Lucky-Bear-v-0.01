import greenfoot.*;

/**
 * Jefe final: aparece al terminar el nivel 15. Es una nave artillada que
 * no se puede rebasar: hay que derribarla.
 *
 * Tiene 3 fases. Cuanto menos vida le queda, mas rapido se mueve, mas
 * seguido dispara y mas escoltas manda.
 */
public class Boss extends Objeto3D
{
    public static final int VIDA_MAX = 130;

    private int vida = VIDA_MAX;
    private int fase = 1;
    private double dirX = 1;
    private double faseAltura = 0;
    private int timerDisparo = 70;
    private int timerEscolta = 260;
    private int rafagaRestante = 0;
    private int timerRafaga = 0;
    private int flash = 0;
    private int entrada = 150;

    public Boss()
    {
        inicializar(Sprites.jefe(1), 5200, 2480);
        x = 0;
        altura = 2200;
        z = 26000;
    }

    public void act()
    {
        RaceWorld w = (RaceWorld) getWorld();
        if (w == null || w.congelado()) return;

        // entrada: se acerca desde el fondo hasta su posicion de combate
        if (entrada > 0) {
            entrada--;
            z += (7200 - z) * 0.02;
        }

        actualizarFase();

        double vel = 10 + fase * 7;
        x += dirX * vel;
        if (Math.abs(x) > 2500) dirX = -dirX;

        faseAltura += 0.03;
        altura = 2200 + Math.sin(faseAltura) * 220;
        z += Math.cos(faseAltura * 0.7) * 26;

        atacar(w);
        proyectar();

        if (flash > 0) flash--;
        getImage().setTransparency((flash > 0 && flash % 6 < 3) ? 150 : 255);
    }

    private void actualizarFase()
    {
        int nueva = vida > VIDA_MAX * 0.66 ? 1 : (vida > VIDA_MAX * 0.33 ? 2 : 3);
        if (nueva != fase) {
            fase = nueva;
            setBase(Sprites.jefe(fase));
        }
    }

    private void atacar(RaceWorld w)
    {
        PlayerCar j = w.getJugador();
        if (j == null || entrada > 60) return;

        if (rafagaRestante > 0) {
            timerRafaga--;
            if (timerRafaga <= 0) {
                timerRafaga = 7;
                rafagaRestante--;
                double desvio = (Greenfoot.getRandomNumber(1200) - 600);
                w.addObject(new EnemyBullet(x + desvio, altura, z, j, 12 + fase * 3), -500, -500);
            }
            return;
        }

        timerDisparo--;
        if (timerDisparo <= 0) {
            timerDisparo = Math.max(34, 100 - fase * 20) + Greenfoot.getRandomNumber(30);
            rafagaRestante = 2 + fase;
            timerRafaga = 1;
        }

        timerEscolta--;
        if (timerEscolta <= 0) {
            timerEscolta = Math.max(150, 300 - fase * 50);
            w.addObject(new EnemyHeli(HeliTipo.paraNivel(GameData.NIVEL_MAX)), -500, -500);
        }
    }

    public void recibirDano(int d)
    {
        vida -= d;
        flash = 10;

        RaceWorld w = (RaceWorld) getWorld();
        if (w == null) return;

        if (vida <= 0) {
            vida = 0;
            w.sumarPuntaje(12000);
            for (int i = 0; i < 6; i++) {
                w.addObject(new Explosion(x + Greenfoot.getRandomNumber(2400) - 1200,
                                          altura + Greenfoot.getRandomNumber(900) - 450,
                                          z, 2600), -500, -500);
            }
            w.jefeDerrotado();
            w.removeObject(this);
        }
    }

    public int getVida()    { return vida; }
    public int getVidaMax() { return VIDA_MAX; }
    public int getFase()    { return fase; }
}
