import greenfoot.*;

/**
 * Auto rival.
 *
 * - Si es mas lento, aparece chico en el horizonte, crece y lo rebasamos.
 * - Si es mas rapido, aparece grande por detras, nos pasa y se aleja
 *   achicandose hacia el horizonte.
 */
public class RivalCar extends Objeto3D
{
    private int carril;
    private double factor;         // velocidad respecto a la nuestra
    private boolean contado = false;
    /** Ya se contabilizo el roce con este auto. */
    public boolean roceContado = false;

    private static final Color[] COLORES = {
        new Color(230, 220, 60), new Color(60, 200, 90), new Color(220, 90, 40),
        new Color(230, 230, 235), new Color(60, 90, 210), new Color(150, 60, 190)
    };

    public RivalCar(int carril, LevelConfig cfg, boolean nosRebasa)
    {
        this.carril = carril;
        Color c = COLORES[Greenfoot.getRandomNumber(COLORES.length)];
        inicializar(Sprites.rival(c), 400, 300);

        x = Camara.centroCarril(carril);
        altura = 0;

        if (nosRebasa) {
            factor = 1.10 + Greenfoot.getRandomNumber(25) / 100.0;
            z = 300;                               // aparece pegado atras
        } else {
            factor = 0.50 + Greenfoot.getRandomNumber(40) / 100.0;
            if (cfg.nivel >= 5) factor += 0.08;
            z = 15000 + Greenfoot.getRandomNumber(4000);
        }
    }

    public void act()
    {
        RaceWorld w = (RaceWorld) getWorld();
        if (w == null || w.congelado()) return;

        double v = w.getVelocidad();
        z += v * factor - v;          // negativo = lo alcanzamos

        if (!contado && z < Camara.Z_JUGADOR) {
            contado = true;
            if (factor < 1) w.sumarPuntaje(150);   // lo rebasamos nosotros
        }

        if (z < 200 || z > 30000) { w.removeObject(this); return; }

        proyectar();
    }

    /** Al chocar el rival tambien se descontrola y se frena. */
    public void rebotar()
    {
        factor = Math.max(0.30, factor - 0.30);
        z += 220;
        roceContado = true;          // un choque no cuenta ademas como roce
    }

    /** Lo destruye la explosion de la ulti. */
    public void destruir()
    {
        RaceWorld w = (RaceWorld) getWorld();
        if (w == null) return;
        w.sumarPuntaje(300);
        w.addObject(new Explosion(x, 120, z, 900), -500, -500);
        w.removeObject(this);
    }

    public int getCarril() { return carril; }
}
