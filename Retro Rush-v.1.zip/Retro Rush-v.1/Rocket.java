import greenfoot.*;

/**
 * Cohete de la bazuca (ulti). Persigue en 3D a un AUTO de adelante y
 * explota en area, llevandose puestos a los que esten al lado.
 * Contra helicopteros no sirve (para eso estan las balas), pero SI se
 * puede usar contra el jefe final, donde hace 14 de dano de golpe.
 */
public class Rocket extends Objeto3D
{
    private Objeto3D objetivo;
    private double velocidad = 620;
    private int vida = 120;

    public Rocket(double x, double altura, double z, Objeto3D objetivo)
    {
        this.x = x;
        this.altura = altura;
        this.z = z;
        this.objetivo = objetivo;
        inicializar(Sprites.cohete(), 260, 390);
    }

    public void act()
    {
        RaceWorld w = (RaceWorld) getWorld();
        if (w == null || w.congelado()) return;

        vida--;

        if (objetivo == null || objetivo.getWorld() == null) {
            z += velocidad;
        } else {
            double dx = objetivo.getX3D()   - x;
            double da = objetivo.getAltura() - altura;
            double dz = objetivo.getZ()      - z;
            double d  = Math.max(1, Math.sqrt(dx * dx + da * da + dz * dz));

            x      += dx / d * velocidad;
            altura += da / d * velocidad;
            z      += dz / d * velocidad;

            if (d < velocidad * 1.2) { estallar(w); return; }
        }

        if (vida <= 0 || z > 26000) { estallar(w); return; }

        proyectar();
    }

    private void estallar(RaceWorld w)
    {
        if (objetivo instanceof Boss && objetivo.getWorld() != null) {
            ((Boss) objetivo).recibirDano(14);
        }
        w.addObject(new Explosion(x, altura, z, 2600), -500, -500);
        w.removeObject(this);
    }
}
