import greenfoot.*;

/**
 * Capa transparente encima de todo: puntaje, tiempo, velocimetro,
 * energia, barra de NITRO/ULTI, municion, vida del jefe, mensajes
 * y el panel de pausa.
 */
public class HudOverlay extends Actor
{
    private GreenfootImage img;

    public HudOverlay()
    {
        img = new GreenfootImage(GameData.ANCHO, GameData.ALTO);
        setImage(img);
    }

    public void actualizar(RaceWorld w)
    {
        img.clear();
        LevelConfig cfg = w.getConfig();
        PlayerCar j = w.getJugador();

        img.setColor(new Color(0, 0, 0, 140));
        img.fillRect(0, 0, GameData.ANCHO, 44);

        img.setFont(new Font("Monospaced", true, false, 19));
        img.setColor(Color.WHITE);
        img.drawString("NIVEL " + cfg.nivel + "/" + GameData.NIVEL_MAX
                       + "  " + cfg.paleta.nombre, 12, 28);
        img.drawString("PTS " + GameData.puntajeCarrera, 300, 28);
        img.drawString("T " + GameData.formatoTiempo(GameData.tiempoActualMs()), 470, 28);
        img.setColor(new Color(255, 190, 90));
        img.drawString(cfg.heli.nombre, 620, 28);

        double p = Math.min(1.0, w.getDistancia() / cfg.distanciaObjetivo);
        img.setColor(new Color(255, 255, 255, 70));
        img.fillRect(12, 50, GameData.ANCHO - 24, 8);
        img.setColor(new Color(90, 230, 130));
        img.fillRect(12, 50, (int) ((GameData.ANCHO - 24) * p), 8);

        if (w.getJefe() != null) barraJefe(w.getJefe());

        dibujarVelocimetro(w);

        if (j != null) {
            barra(12, GameData.ALTO - 80, 210, 18, j.getEnergia() / 100.0,
                  colorEnergia(j.getEnergia()), "ENERGIA " + j.getEnergia());

            String etiqueta;
            Color colorUlti;
            if (j.nitroEncendido())      { etiqueta = "NITRO!!";        colorUlti = new Color(120, 220, 255); }
            else if (j.getUlti() >= 100) { etiqueta = "BAZUCA LISTA X"; colorUlti = new Color(255, 120, 60); }
            else                         { etiqueta = "NITRO / ULTI";   colorUlti = new Color(255, 190, 40); }
            barra(12, GameData.ALTO - 56, 210, 18, j.getUlti() / 100.0, colorUlti, etiqueta);

            dibujarMunicion(j);
        }

        img.setFont(new Font("Monospaced", false, false, 13));
        img.setColor(new Color(255, 255, 255, 190));
        img.drawString("<- ->  carril    SPACE  disparar    X  bazuca    SHIFT  nitro    P  pausa",
                       250, GameData.ALTO - 8);

        if (w.isPausa()) {
            panelPausa();
        } else if (w.getIntroTimer() > 0) {
            mensajeCentral("NIVEL " + cfg.nivel, cfg.paleta.nombre);
        } else if (w.getEstado() == 3 && w.getJefe() != null) {
            if (w.getJefe().getVida() > Boss.VIDA_MAX * 0.95) mensajeCentral("JEFE FINAL", "DERRIBALO");
        } else if (w.getEstado() == 1) {
            boolean ultimo = GameData.nivelActual >= GameData.NIVEL_MAX;
            mensajeCentral(ultimo ? "JEFE DERRIBADO" : "NIVEL SUPERADO",
                           ultimo ? "+12000 PTS" : "+ " + (1000 + cfg.nivel * 250) + " PTS");
        } else if (w.getEstado() == 2) {
            mensajeCentral("DESTRUIDO", "PUNTAJE " + GameData.puntajeCarrera);
        }
    }

    /** Balas disponibles, como cartuchos. */
    private void dibujarMunicion(PlayerCar j)
    {
        int x = 12, y = GameData.ALTO - 32;

        img.setFont(new Font("Monospaced", true, false, 13));
        img.setColor(Color.WHITE);
        img.drawString(j.estaRecargando() ? "RECARGANDO" : "BALAS", x, y + 13);

        if (j.estaRecargando()) {
            img.setColor(new Color(255, 255, 255, 60));
            img.fillRect(x + 106, y + 2, 104, 12);
            img.setColor(new Color(255, 190, 60));
            img.fillRect(x + 106, y + 2, (int) (104 * j.progresoRecarga()), 12);
            return;
        }

        for (int i = 0; i < PlayerCar.BALAS_MAX; i++) {
            boolean tiene = i < j.getBalas();
            img.setColor(tiene ? new Color(255, 225, 120) : new Color(255, 255, 255, 45));
            img.fillRect(x + 66 + i * 14, y + 2, 9, 13);
        }
    }

    private void barraJefe(Boss b)
    {
        int an = 520, x = (GameData.ANCHO - an) / 2, y = 68;

        img.setFont(new Font("Monospaced", true, false, 18));
        img.setColor(new Color(255, 120, 120));
        img.drawString("JEFE  -  FASE " + b.getFase(), x, y - 6);

        img.setColor(new Color(0, 0, 0, 170));
        img.fillRect(x - 3, y, an + 6, 20);
        img.setColor(new Color(255, 255, 255, 60));
        img.fillRect(x, y + 3, an, 14);
        img.setColor(b.getFase() >= 3 ? new Color(255, 200, 60) : new Color(230, 60, 60));
        img.fillRect(x, y + 3, (int) (an * b.getVida() / (double) b.getVidaMax()), 14);
    }

    private void dibujarVelocimetro(RaceWorld w)
    {
        int kmh = (int) (w.getVelocidad() * 1.35);
        double p = Math.min(1.0, w.getVelocidad() / (w.velocidadObjetivo() + 40));

        int x = GameData.ANCHO - 216, y = GameData.ALTO - 68;

        img.setColor(new Color(0, 0, 0, 150));
        img.fillRect(x - 4, y - 4, 208, 56);

        img.setFont(new Font("Monospaced", true, false, 32));
        img.setColor(p > 0.85 ? new Color(140, 255, 180) : Color.WHITE);
        img.drawString(kmh + " km/h", x + 6, y + 28);

        img.setColor(new Color(255, 255, 255, 60));
        img.fillRect(x, y + 36, 200, 10);
        img.setColor(new Color(255, 120 + (int) (p * 100), 60));
        img.fillRect(x, y + 36, (int) (200 * p), 10);
    }

    private void panelPausa()
    {
        img.setColor(new Color(0, 0, 0, 190));
        img.fillRect(0, 0, GameData.ANCHO, GameData.ALTO);

        img.setColor(new Color(250, 205, 40));
        img.setFont(new Font("Monospaced", true, false, 56));
        img.drawString("PAUSA", centrado("PAUSA", 56), 210);

        img.setFont(new Font("Monospaced", false, false, 17));
        img.setColor(new Color(210, 210, 220));
        img.drawString("P o ESC para volver a la carrera", centrado("P o ESC para volver a la carrera", 17), 246);
        img.drawString("Reiniciar el nivel no borra tu puntaje de la carrera",
                       centrado("Reiniciar el nivel no borra tu puntaje de la carrera", 17), 510);
    }

    private Color colorEnergia(int e)
    {
        if (e > 60) return new Color(90, 220, 110);
        if (e > 30) return new Color(240, 190, 60);
        return new Color(235, 70, 70);
    }

    private void barra(int x, int y, int an, int al, double p, Color color, String texto)
    {
        img.setColor(new Color(0, 0, 0, 150));
        img.fillRect(x - 2, y - 2, an + 4, al + 4);
        img.setColor(new Color(255, 255, 255, 60));
        img.fillRect(x, y, an, al);
        img.setColor(color);
        img.fillRect(x, y, (int) (an * Math.max(0, Math.min(1, p))), al);
        img.setColor(Color.WHITE);
        img.setFont(new Font("Monospaced", true, false, 13));
        img.drawString(texto, x + 6, y + 14);
    }

    private void mensajeCentral(String titulo, String sub)
    {
        img.setColor(new Color(0, 0, 0, 160));
        img.fillRect(0, 230, GameData.ANCHO, 130);
        img.setColor(Color.WHITE);
        img.setFont(new Font("Monospaced", true, false, 52));
        img.drawString(titulo, centrado(titulo, 52), 296);
        img.setFont(new Font("Monospaced", true, false, 24));
        img.drawString(sub, centrado(sub, 24), 336);
    }

    private int centrado(String s, int tam)
    {
        return GameData.ANCHO / 2 - (int) (s.length() * tam * 0.30);
    }
}
