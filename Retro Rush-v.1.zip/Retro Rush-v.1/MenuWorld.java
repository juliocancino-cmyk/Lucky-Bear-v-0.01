import greenfoot.*;

/**
 * Menu principal. Este es el mundo con el que arranca el juego:
 * click derecho sobre MenuWorld -> new MenuWorld().
 */
public class MenuWorld extends World
{
    private MenuButton jugar, garage, ranking, creditos;

    public MenuWorld()
    {
        super(GameData.ANCHO, GameData.ALTO, 1);
        GameData.cargarRanking();

        jugar    = new MenuButton("JUGAR",    "jugar",    260, 62);
        garage   = new MenuButton("GARAGE",   "garage",   260, 62);
        ranking  = new MenuButton("RANKING",  "ranking",  260, 62);
        creditos = new MenuButton("CREDITOS", "creditos", 260, 62);

        addObject(jugar,    170, 330);
        addObject(garage,   170, 402);
        addObject(ranking,  170, 474);
        addObject(creditos, 170, 546);

        dibujarFondo();
    }

    public void act()
    {
        if (jugar.fueClickeado()) {
            GameData.nuevaPartida();
            Greenfoot.setWorld(new RaceWorld());
        } else if (garage.fueClickeado()) {
            Greenfoot.setWorld(new GarageWorld());
        } else if (ranking.fueClickeado()) {
            Greenfoot.setWorld(new RankingWorld());
        } else if (creditos.fueClickeado()) {
            Greenfoot.setWorld(new CreditsWorld());
        }

        // atajo de teclado
        String t = Greenfoot.getKey();
        if ("enter".equals(t)) {
            GameData.nuevaPartida();
            Greenfoot.setWorld(new RaceWorld());
        }
    }

    private void dibujarFondo()
    {
        GreenfootImage f = getBackground();
        Palette p = Palette.get(3);   // atardecer para el menu

        f.setColor(p.cieloAlto);
        f.fillRect(0, 0, GameData.ANCHO, 200);
        f.setColor(p.cieloBajo);
        f.fillRect(0, 200, GameData.ANCHO, 120);
        f.setColor(p.suelo);
        f.fillRect(0, 320, GameData.ANCHO, GameData.ALTO - 320);

        // sol retro
        f.setColor(new Color(255, 210, 80));
        f.fillOval(560, 90, 170, 170);
        f.setColor(p.cieloBajo);
        for (int y = 180; y < 260; y += 16) f.fillRect(540, y, 220, 6);

        // auto seleccionado en el centro
        GreenfootImage auto = GameData.auto().imagen();
        auto.scale(300, 225);
        f.drawImage(auto, 440, 300);

        // titulo
        f.setFont(new Font("Monospaced", true, false, 62));
        f.setColor(new Color(0, 0, 0, 160));
        f.drawString("RETRO RUSH", 66, 128);
        f.setColor(new Color(250, 205, 40));
        f.drawString("RETRO RUSH", 62, 124);

        f.setFont(new Font("Monospaced", true, false, 20));
        f.setColor(Color.WHITE);
        f.drawString("Un juego de carreras arcade - 10 niveles", 64, 160);

        f.setFont(new Font("Monospaced", true, false, 18));
        f.drawString("AUTO: " + GameData.auto().nombre
                     + "   |   PUNTOS TOTALES: " + GameData.puntajeTotal, 64, 250);
    }
}
