import greenfoot.*;

/**
 * Texto flotante de feedback ("+80 ROCE", "CHOQUE"). Sube y se desvanece.
 */
public class PopText extends Actor
{
    private int vida;
    private final int total;

    public PopText(String texto, Color color, int tam)
    {
        this.total = 42;
        this.vida = total;

        GreenfootImage img = new GreenfootImage(texto, tam, color, new Color(0, 0, 0, 0));
        setImage(img);
    }

    public void act()
    {
        World mundo = getWorld();
        if (mundo instanceof RaceWorld && ((RaceWorld) mundo).congelado()) return;

        vida--;
        setLocation(getX(), getY() - 2);
        getImage().setTransparency(Math.max(0, 255 * vida / total));
        if (vida <= 0) getWorld().removeObject(this);
    }
}
