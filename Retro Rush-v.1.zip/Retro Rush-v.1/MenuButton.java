import greenfoot.*;

/**
 * Boton de menu estilo FR Legends: caja amarilla con borde negro.
 */
public class MenuButton extends Actor
{
    public String accion;
    private String texto;
    private int ancho, alto;
    private boolean activo = true;
    private boolean hover = false;

    public MenuButton(String texto, String accion, int ancho, int alto)
    {
        this.texto = texto;
        this.accion = accion;
        this.ancho = ancho;
        this.alto = alto;
        redibujar();
    }

    public void setActivo(boolean a)
    {
        activo = a;
        redibujar();
    }

    public void setTexto(String t)
    {
        texto = t;
        redibujar();
    }

    public void act()
    {
        MouseInfo m = Greenfoot.getMouseInfo();
        boolean nuevoHover = false;
        if (m != null) {
            nuevoHover = Math.abs(m.getX() - getX()) < ancho / 2
                      && Math.abs(m.getY() - getY()) < alto / 2;
        }
        if (nuevoHover != hover) {
            hover = nuevoHover;
            redibujar();
        }
    }

    public boolean fueClickeado()
    {
        return activo && Greenfoot.mouseClicked(this);
    }

    private void redibujar()
    {
        GreenfootImage img = new GreenfootImage(ancho, alto);

        Color fondo;
        if (!activo)      fondo = new Color(120, 120, 125);
        else if (hover)   fondo = new Color(255, 235, 100);
        else              fondo = new Color(250, 205, 40);

        img.setColor(new Color(0, 0, 0, 120));
        img.fillRect(4, 6, ancho - 4, alto - 6);
        img.setColor(fondo);
        img.fillRect(0, 0, ancho - 6, alto - 8);
        img.setColor(Color.BLACK);
        img.drawRect(0, 0, ancho - 7, alto - 9);
        img.drawRect(1, 1, ancho - 9, alto - 11);

        img.setFont(new Font("Monospaced", true, false, alto / 2));
        img.setColor(activo ? Color.BLACK : new Color(70, 70, 70));
        img.drawString(texto, 16, alto / 2 + alto / 7);

        setImage(img);
    }
}
