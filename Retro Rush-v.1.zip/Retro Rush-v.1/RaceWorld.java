import greenfoot.*;

/**
 * Mundo de la carrera con camara pseudo-3D.
 *
 * La ruta se dibuja fila por fila: para cada linea de pixeles se calcula
 * a que profundidad z corresponde y se pinta el asfalto de ese ancho.
 *
 * Estados: 0 corriendo, 1 nivel superado, 2 destruido, 3 pelea del jefe.
 */
public class RaceWorld extends World
{
    private LevelConfig cfg;
    private PlayerCar jugador;
    private HudOverlay hud;
    private Ambiente ambiente;
    private Boss jefe;

    private double scrollZ = 0;
    private double distancia = 0;
    private double velocidad = 0;

    private int timerTrafico = 60;
    private int timerEnemigo = 90;

    private int estado = 0;
    private int contador = 0;
    private int introTimer = 110;

    private boolean pausa = false;
    private MenuButton btnSeguir, btnReiniciar, btnSalir;

    private GreenfootImage imgArbol, imgCartel;

    public RaceWorld()
    {
        super(GameData.ANCHO, GameData.ALTO, 1);

        cfg = LevelConfig.get(GameData.nivelActual);
        Camara.reset();

        setPaintOrder(HudOverlay.class, MenuButton.class, PopText.class, Explosion.class,
                      Rocket.class, Bullet.class, EnemyBullet.class, PlayerCar.class,
                      RivalCar.class, Fauna.class, Boss.class, EnemyHeli.class);

        ambiente  = new Ambiente(cfg.paleta);
        imgArbol  = Sprites.arbol(cfg.paleta.copa, cfg.paleta.tronco);
        imgCartel = Sprites.cartel(cfg.paleta.linea);

        jugador = new PlayerCar();
        addObject(jugador, GameData.ANCHO / 2, 500);

        hud = new HudOverlay();
        addObject(hud, GameData.ANCHO / 2, GameData.ALTO / 2);

        velocidad = cfg.velocidadBase * 0.55;
        dibujarEscenario();
    }

    public void act()
    {
        revisarPausa();

        if (pausa) { dibujarEscenario(); hud.actualizar(this); return; }

        if (introTimer > 0) {
            introTimer--;
            dibujarEscenario();
            hud.actualizar(this);
            return;
        }

        if (estado == 0 || estado == 3) {
            acelerar();
            scrollZ += velocidad;
            Camara.seguir(jugador.getX3D());
            Camara.ajustarPorVelocidad(velocidad);
            generarTrafico();
            generarEnemigos();

            if (estado == 0) {
                distancia += velocidad / 100.0;
                if (distancia >= cfg.distanciaObjetivo) finDeNivel();
            }
        } else {
            contador--;
            if (contador <= 0) avanzar();
        }

        dibujarEscenario();
        hud.actualizar(this);
    }

    // ==================================================================
    // PAUSA
    // ==================================================================
    private void revisarPausa()
    {
        String t = Greenfoot.getKey();
        if ("p".equals(t) || "escape".equals(t)) {
            if (pausa) quitarPausa(); else ponerPausa();
        }

        if (!pausa) return;

        if (btnSeguir.fueClickeado()) {
            quitarPausa();
        } else if (btnReiniciar.fueClickeado()) {
            Greenfoot.setWorld(new RaceWorld());
        } else if (btnSalir.fueClickeado()) {
            Greenfoot.setWorld(new MenuWorld());
        }
    }

    private void ponerPausa()
    {
        if (estado == 2 || pausa) return;
        pausa = true;

        btnSeguir    = new MenuButton("SEGUIR",          "seguir",  300, 58);
        btnReiniciar = new MenuButton("REINICIAR NIVEL", "reinic",  300, 58);
        btnSalir     = new MenuButton("SALIR AL MENU",   "salir",   300, 58);

        addObject(btnSeguir,    400, 300);
        addObject(btnReiniciar, 400, 368);
        addObject(btnSalir,     400, 436);
    }

    private void quitarPausa()
    {
        pausa = false;
        if (btnSeguir    != null) removeObject(btnSeguir);
        if (btnReiniciar != null) removeObject(btnReiniciar);
        if (btnSalir     != null) removeObject(btnSalir);
        btnSeguir = btnReiniciar = btnSalir = null;
    }

    /** Todo lo que se mueve consulta esto para quedarse quieto. */
    public boolean congelado()
    {
        return pausa || introTimer > 0 || estado == 1 || estado == 2;
    }

    public boolean isPausa() { return pausa; }

    // ==================================================================
    // VELOCIDAD
    // ==================================================================
    private void acelerar()
    {
        double objetivo = velocidadObjetivo();
        double ritmo = (velocidad < objetivo) ? 0.018 : 0.09;
        velocidad += (objetivo - velocidad) * ritmo;
    }

    public double velocidadObjetivo()
    {
        double v = cfg.velocidadBase + GameData.auto().velocidad * 8;
        if (jugador != null) v += jugador.bonusVelocidad();
        return v;
    }

    public void frenazo(double factor)
    {
        velocidad *= factor;
        double minimo = cfg.velocidadBase * 0.35;
        if (velocidad < minimo) velocidad = minimo;
    }

    // ==================================================================
    // DIBUJO
    // ==================================================================
    private void dibujarEscenario()
    {
        GreenfootImage f = getBackground();
        Palette p = cfg.paleta;

        dibujarCielo(f, p);
        dibujarRuta(f, p);
        dibujarPaisaje(f, p);
        dibujarLineasDeVelocidad(f);

        if (!congelado() && ambiente.actualizar(f, velocidad)) soltarFauna();
        else if (congelado()) ambiente.actualizar(f, 0);
    }

    private void soltarFauna()
    {
        if (getObjects(Fauna.class).size() > 0) return;
        addObject(new Fauna(cfg.paleta, 9000 + Greenfoot.getRandomNumber(4000)), -500, -500);
    }

    private void dibujarCielo(GreenfootImage f, Palette p)
    {
        int H = Camara.HORIZONTE;

        int bandas = 8;
        for (int i = 0; i < bandas; i++) {
            double t = i / (double) (bandas - 1);
            f.setColor(Sprites.mezclar(p.cieloAlto, p.cieloBajo, t));
            f.fillRect(0, i * H / bandas, GameData.ANCHO, H / bandas + 1);
        }

        int solX = 560 - (int) (Camara.camX * 0.02);
        f.setColor(Sprites.mezclar(p.linea, p.cieloBajo, 0.15));
        f.fillOval(solX, H - 175, 165, 165);
        f.setColor(p.cieloBajo);
        for (int y = H - 95; y < H; y += 14) f.fillRect(solX - 10, y, 190, 6);

        f.setColor(Sprites.mezclar(p.suelo, p.cieloBajo, 0.45));
        int desfase = (int) (Camara.camX * 0.04) % 160;
        for (int i = -1; i < 7; i++) {
            int bx = i * 160 - desfase;
            int alto = 34 + ((i * 37) % 5) * 12;
            f.fillRect(bx, H - alto, 120, alto);
        }
    }

    private void dibujarRuta(GreenfootImage f, Palette p)
    {
        Color pastoA = p.suelo;
        Color pastoB = Sprites.mezclar(p.suelo, Color.BLACK, 0.18);
        Color rutaA  = p.ruta;
        Color rutaB  = Sprites.mezclar(p.ruta, Color.WHITE, 0.10);

        int paso = 2;
        for (int sy = Camara.HORIZONTE + paso; sy < GameData.ALTO; sy += paso) {

            double z = Camara.ALTURA * Camara.FOCAL / (sy - Camara.HORIZONTE);
            double e = Camara.FOCAL / z;
            double zt = z + scrollZ;

            boolean franja  = ((int) (zt / 2600)) % 2 == 0;
            boolean franja2 = ((int) (zt / 1300)) % 2 == 0;

            f.setColor(franja ? pastoA : pastoB);
            f.fillRect(0, sy, GameData.ANCHO, paso);

            double cx   = GameData.ANCHO / 2.0 - Camara.camX * e;
            double semi = Camara.SEMI_RUTA * e;
            f.setColor(franja ? rutaA : rutaB);
            f.fillRect((int) (cx - semi), sy, (int) (semi * 2), paso);

            int anchoB = Math.max(1, (int) (semi * 0.09));
            f.setColor(franja ? p.bordeRuta : Color.WHITE);
            f.fillRect((int) (cx - semi), sy, anchoB, paso);
            f.fillRect((int) (cx + semi) - anchoB, sy, anchoB, paso);

            if (franja2) {
                int anchoL = Math.max(1, (int) (36 * e));
                f.setColor(p.linea);
                for (int c = 1; c < Camara.CARRILES; c++) {
                    double lx = cx + (-Camara.SEMI_RUTA + c * Camara.ANCHO_CARRIL) * e;
                    f.fillRect((int) lx - anchoL / 2, sy, anchoL, paso);
                }
            }
        }
    }

    private void dibujarPaisaje(GreenfootImage f, Palette p)
    {
        double periodo = 2200;
        double lateral = Camara.SEMI_RUTA + 750;

        for (int i = 8; i >= 1; i--) {
            double z = i * periodo - (scrollZ % periodo);
            if (z < 400) continue;

            boolean derecha = (i % 2 == 0);
            double x = derecha ? lateral : -lateral;

            if (i % 4 == 3) dibujarEnSuelo(f, imgCartel, x, z, 700, 1050);
            else            dibujarEnSuelo(f, imgArbol,  x, z, 800, 1450);
        }
    }

    private void dibujarLineasDeVelocidad(GreenfootImage f)
    {
        double base = cfg.velocidadBase + GameData.auto().velocidad * 8;
        double exceso = (velocidad - base * 0.9) / 140.0;
        if (exceso <= 0.05) return;

        int alpha = (int) Math.min(150, exceso * 190);
        int cx = (int) (GameData.ANCHO / 2.0 - Camara.camX * Camara.escala(Camara.Z_JUGADOR));
        int cy = Camara.HORIZONTE;

        f.setColor(new Color(255, 255, 255, alpha));
        for (int i = 0; i < 16; i++) {
            double ang = i * (Math.PI * 2 / 16) + (scrollZ % 360) * 0.0004;
            double r1 = 260 + ((i * 53) % 90);
            double r2 = r1 + 60 + exceso * 90;
            f.drawLine(cx + (int) (Math.cos(ang) * r1), cy + (int) (Math.sin(ang) * r1 * 0.55),
                       cx + (int) (Math.cos(ang) * r2), cy + (int) (Math.sin(ang) * r2 * 0.55));
        }
    }

    private void dibujarEnSuelo(GreenfootImage f, GreenfootImage sp,
                                double x, double z, double anchoMundo, double altoMundo)
    {
        double e = Camara.FOCAL / z;
        int w = (int) (anchoMundo * e);
        int h = (int) (altoMundo * e);
        if (w < 3 || h < 3) return;

        GreenfootImage copia = new GreenfootImage(sp);
        copia.scale(w, h);
        f.drawImage(copia, Camara.px(x, z) - w / 2, Camara.py(0, z) - h);
    }

    // ==================================================================
    // SPAWNS
    // ==================================================================
    private void generarTrafico()
    {
        timerTrafico--;
        if (timerTrafico > 0) return;
        timerTrafico = cfg.framesTrafico + Greenfoot.getRandomNumber(cfg.framesTrafico);

        int carril = Greenfoot.getRandomNumber(Camara.CARRILES);
        boolean nosRebasa = Greenfoot.getRandomNumber(100) < 25;

        for (RivalCar r : getObjects(RivalCar.class)) {
            if (r.getCarril() != carril) continue;
            if (nosRebasa && r.getZ() < 2500) return;
            if (!nosRebasa && r.getZ() > 13000) return;
        }

        addObject(new RivalCar(carril, cfg, nosRebasa), -500, -500);
    }

    private void generarEnemigos()
    {
        if (estado == 3) return;      // durante el jefe los manda el jefe
        timerEnemigo--;
        if (timerEnemigo > 0) return;
        timerEnemigo = cfg.framesEnemigo + Greenfoot.getRandomNumber(90);

        addObject(new EnemyHeli(cfg.heli), -500, -500);
    }

    // ==================================================================
    // NIVELES Y JEFE
    // ==================================================================
    private void finDeNivel()
    {
        if (GameData.nivelActual >= GameData.NIVEL_MAX) {
            iniciarJefe();
            return;
        }
        estado = 1;
        contador = 130;
        sumarPuntaje(1000 + GameData.nivelActual * 250);
    }

    private void iniciarJefe()
    {
        estado = 3;
        jefe = new Boss();
        addObject(jefe, -500, -500);
    }

    public void jefeDerrotado()
    {
        jefe = null;
        estado = 1;
        contador = 180;
    }

    public void gameOver()
    {
        estado = 2;
        contador = 130;
    }

    private void avanzar()
    {
        if (estado == 2) {
            GameData.terminarPartida(false);
            Greenfoot.setWorld(new DefeatWorld());
            return;
        }
        if (GameData.nivelActual >= GameData.NIVEL_MAX) {
            GameData.terminarPartida(true);
            Greenfoot.setWorld(new ResultWorld());
            return;
        }
        GameData.nivelActual++;
        Greenfoot.setWorld(new RaceWorld());
    }

    // ==================================================================
    // UTILIDADES
    // ==================================================================
    public void sumarPuntaje(int p)
    {
        GameData.puntajeCarrera += p;
        if (jugador != null) jugador.cargarUlti(p / 45.0);
    }

    public EnemyHeli heliMasCercano()
    {
        EnemyHeli mejor = null;
        double mejorZ = Double.MAX_VALUE;
        for (EnemyHeli h : getObjects(EnemyHeli.class)) {
            if (h.getZ() < Camara.Z_JUGADOR) continue;
            if (h.getZ() < mejorZ) { mejorZ = h.getZ(); mejor = h; }
        }
        return mejor;
    }

    public RivalCar autoMasCercano()
    {
        RivalCar mejor = null;
        double mejorZ = Double.MAX_VALUE;
        for (RivalCar r : getObjects(RivalCar.class)) {
            if (r.getZ() < Camara.Z_JUGADOR + 500) continue;
            if (r.getZ() > 14000) continue;
            if (r.getZ() < mejorZ) { mejorZ = r.getZ(); mejor = r; }
        }
        return mejor;
    }

    public Boss getJefe()            { return jefe; }
    public LevelConfig getConfig()   { return cfg; }
    public PlayerCar   getJugador()  { return jugador; }
    public double getVelocidad()     { return velocidad; }
    public double getDistancia()     { return distancia; }
    public int    getEstado()        { return estado; }
    public int    getIntroTimer()    { return introTimer; }
}
