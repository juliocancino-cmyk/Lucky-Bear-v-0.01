import greenfoot.*;

/**
 * Catalogo de las 130 formas de morir. Cada entrada define QUE plantilla de
 * animacion usa (tmpl), con que prop/color/parametro (prop, p1), si
 * interviene la mafia, y un nombre.
 *
 * Las plantillas viven en PlayerCar (metodos mXxx). PlayerCar elige una
 * Muerte al azar (o sesgada por la causa) y la reproduce.
 */
public class Muerte
{
    // plantillas de animacion
    public static final int T_ORILLA=0, T_LLORA=1, T_PROP=2, T_VUELCO=3, T_INCENDIO=4,
        T_DETONA=5, T_CAIDA=6, T_DESINTEGRA=7, T_HUNDE=8, T_PORTAL=9, T_CAE=10,
        T_CRIATURA=11, T_MAQUINA=12, T_RAYO=13, T_GIRA=14, T_ABANDONO=15, T_APLASTA=16,
        T_MOTOR=17, T_MAFIA_BOX=18, T_MAFIA_KIDNAP=19, T_MAFIA_DRIVEBY=20, T_CLIMA=21,
        T_CHISTE=22, T_EXPLOTA=23;

    public final String nombre;
    public final int tmpl, prop, p1;
    public final boolean mafia;
    /** null = COMUN (sale en cualquier nivel). Si no, solo en esos biomas (nombres de Palette). */
    public final String[] biomas;

    private Muerte(String nombre, int tmpl, int prop, int p1, boolean mafia, String[] biomas)
    {
        this.nombre = nombre; this.tmpl = tmpl; this.prop = prop; this.p1 = p1;
        this.mafia = mafia; this.biomas = biomas;
    }

    /** COMUN: puede salir en todos los niveles. */
    private static Muerte m(String n, int t, int p, int p1, boolean mf) { return new Muerte(n, t, p, p1, mf, null); }
    /** EXCLUSIVA: solo sale en los biomas indicados (deben ser coherentes con el escenario). */
    private static Muerte mb(String n, int t, int p, int p1, boolean mf, String... biomas)
    {
        return new Muerte(n, t, p, p1, mf, biomas);
    }

    public boolean comun() { return biomas == null; }

    public boolean encajaBioma(String bioma)
    {
        if (biomas == null) return true;
        if (bioma == null)  return false;
        for (String b : biomas) if (b.equals(bioma)) return true;
        return false;
    }

    // ==================================================================
    public static final Muerte[] CATALOGO = {
        // --- salidas tranquilas / se orillan ---
        m("ORILLADO",            T_ORILLA,   0, 0, false),
        m("SE QUEDO SIN NAFTA",  T_CHISTE,   0, 0, false),
        m("MOTOR FUNDIDO",       T_ORILLA,   0, 1, false),
        m("LLANTA REVENTADA",    T_ORILLA,   0, 2, false),
        m("CAJA ROTA",           T_ORILLA,   0, 3, false),
        m("SE AHOGO EL MOTOR",   T_ORILLA,   0, 4, false),
        m("DESPERFECTO",         T_LLORA,    0, 0, false),
        m("LO DEJARON A PIE",    T_ABANDONO, 0, 0, false),
        m("RENUNCIARON",         T_ABANDONO, 0, 1, false),
        m("SE BAJARON A DISCUTIR",T_ABANDONO, 0, 2, false),

        // --- descarrila contra un prop del costado (12 props) ---
        m("CONTRA UN ARBOL",     T_PROP,  0, 0, false),
        m("CONTRA UNA FAROLA",   T_PROP,  1, 0, false),
        m("CONTRA UNA ROCA",     T_PROP,  2, 0, false),
        m("CONTRA UN CARTEL",    T_PROP,  3, 0, false),
        m("CONTRA UNA CERCA",    T_PROP,  4, 0, false),
        m("CONTRA UN HIDRANTE",  T_PROP,  5, 0, false),
        m("CONTRA UN BANCO",     T_PROP,  6, 0, false),
        m("CONTRA UN BUZON",     T_PROP,  7, 0, false),
        mb("CONTRA UN CACTUS",   T_PROP,  8, 0, false, "DESIERTO", "CANON", "SALAR"),
        m("CONTRA UN CONTENEDOR",T_PROP,  9, 0, false),
        m("CONTRA UN SEMAFORO",  T_PROP, 10, 0, false),
        m("CONTRA UN MONOLITO",  T_PROP, 11, 0, false),
        m("CONTRA EL GUARDARRAIL",T_PROP, 4, 0, false),
        m("CONTRA UN POSTE",     T_PROP,  1, 0, false),
        m("CONTRA UNA PARED",    T_PROP, 11, 0, false),

        // --- vuelco ---
        m("VUELCO",              T_VUELCO, 0, 2, false),
        m("VUELCO DOBLE",        T_VUELCO, 0, 4, false),
        m("VUELCO TRIPLE",       T_VUELCO, 0, 6, false),
        m("SE DIO VUELTA",       T_VUELCO, 0, 1, false),
        m("VOLO POR EL AIRE",    T_VUELCO, 0, 5, false),
        m("TONEL LATERAL",       T_VUELCO, 1, 3, false),

        // --- gira / trompo ---
        m("TROMPO",              T_GIRA,  0, 0, false),
        m("TROMPO SIN FIN",      T_GIRA,  0, 1, false),
        m("PERDIO EL CONTROL",   T_GIRA,  0, 0, false),
        m("DERRAPE FATAL",       T_GIRA,  0, 1, false),
        m("SE LE FUE DE ATRAS",  T_GIRA,  0, 0, false),

        // --- incendio ---
        m("SE PRENDIO FUEGO",    T_INCENDIO, 0, 0, false),
        m("FUGA DE NAFTA",       T_INCENDIO, 0, 1, false),
        m("CORTOCIRCUITO",       T_INCENDIO, 0, 0, false),
        m("EL TURBO EXPLOTO",    T_INCENDIO, 0, 2, false),
        m("RECALENTO Y ARDIO",   T_INCENDIO, 0, 1, false),
        m("BOLA DE FUEGO",       T_INCENDIO, 0, 2, false),

        // --- detona / explota ---
        m("EXPLOTO",             T_DETONA, 0, 8, false),
        m("VOLO EN PEDAZOS",     T_EXPLOTA,0, 0, false),
        m("DETONACION",          T_DETONA, 0, 6, false),
        m("EL TANQUE REVENTO",   T_EXPLOTA,0, 0, false),
        m("EXPLOSION EN CADENA", T_DETONA, 0, 10, false),
        m("KABOOM",              T_EXPLOTA,0, 0, false),
        m("SE DESINTEGRO EN FUEGO",T_DETONA,0, 7, false),

        // --- cae del cielo (12 objetos) ---
        m("METEORITO",           T_CAE,  0, 0, false),
        m("LE CAYO UN PIANO",    T_CAE,  1, 0, true),
        m("LE CAYO UNA CAJA FUERTE",T_CAE,2, 0, true),
        m("LE CAYO UN YUNQUE",   T_CAE,  3, 0, false),
        m("LE CAYO UNA HELADERA", T_CAE, 4, 0, false),
        m("LE CAYO UN TELEVISOR", T_CAE, 5, 0, false),
        m("SATELITE EN REENTRADA",T_CAE, 6, 0, false),
        m("SE LE CAYO UN AVION ENCIMA",T_CAE,7, 0, false),
        m("BOLA DE DEMOLICION",  T_CAE,  8, 0, true),
        m("LE CAYO UN ANCLA",    T_CAE,  9, 0, false),
        mb("ROCA DEL ACANTILADO",T_CAE, 10, 0, false, "CANON", "DESIERTO", "SALAR"),
        m("LLUVIA DE CHATARRA",  T_CAE, 11, 0, false),
        m("SEGUNDO METEORITO",   T_CAE,  0, 0, false),
        m("GRANIZO DE HIERRO",   T_CAE,  3, 0, false),

        // --- aplastado desde arriba (5 aplastadores) ---
        m("APLASTADO POR UN CAMION",T_APLASTA,0, 0, true),
        m("PRENSADO",            T_APLASTA, 1, 0, false),
        m("PISADO",              T_APLASTA, 2, 0, false),
        m("SE LE CAYO UN EDIFICIO",T_APLASTA,3, 0, true),
        m("ROCA RODANTE",        T_APLASTA, 4, 0, false),
        m("APLASTADO EN UN TUNEL",T_APLASTA, 3, 0, false),
        m("BAJO UN PUENTE QUE CEDIO",T_APLASTA,1, 0, false),

        // --- criatura (8) ---
        m("PISADO POR UNA BESTIA",T_CRIATURA,0, 0, false),
        mb("UN KRAKEN LO AGARRO",T_CRIATURA,1, 0, false, "PLAYA", "PANTANO"),
        mb("UN DINOSAURIO LO COMIO",T_CRIATURA,2, 0, false, "SELVA", "BOSQUE", "RUINAS"),
        m("UN GUSANO GIGANTE",   T_CRIATURA,3, 0, false),
        mb("UN PULPO LO ENVOLVIO",T_CRIATURA,4, 0, false, "PLAYA", "PANTANO"),
        m("UN GOLEM LO APLASTO", T_CRIATURA,5, 0, false),
        m("UN TORO EMBISTIO",    T_CRIATURA,6, 0, false),
        m("ALGO EN LA OSCURIDAD",T_CRIATURA,7, 0, false),
        m("UNA SERPIENTE COLOSAL",T_CRIATURA,3, 0, false),
        m("EL PERRO DEL INFIERNO",T_CRIATURA,7, 0, false),

        // --- maquina baja del cielo (6) ---
        m("ABDUCIDO POR UN OVNI",T_MAQUINA, 0, 1, false),
        m("LO ENGANCHO UN HELICOPTERO",T_MAQUINA,1, 1, true),
        m("SE LO LLEVO UNA GRUA",T_MAQUINA, 2, 1, true),
        m("UN DIRIGIBLE LO IZO", T_MAQUINA, 3, 1, false),
        m("UN DRON GIGANTE",     T_MAQUINA, 4, 0, false),
        m("UN BRAZO ROBOTICO",   T_MAQUINA, 5, 1, false),
        m("SEGUNDA ABDUCCION",   T_MAQUINA, 0, 1, false),
        m("LA NAVE NODRIZA",     T_MAQUINA, 0, 1, false),

        // --- rayo / laser / francotirador ---
        m("LO PARTIO UN RAYO",   T_RAYO, 0, 0, false),
        m("LASER ORBITAL",       T_RAYO, 1, 0, false),
        m("PULSO EM",            T_RAYO, 2, 0, false),
        m("FRANCOTIRADOR",       T_RAYO, 3, 0, true),
        m("DESCARGA TESLA",      T_RAYO, 0, 0, false),
        m("RAYO DE PLASMA",      T_RAYO, 1, 0, false),
        m("TORMENTA ELECTRICA",  T_RAYO, 0, 0, false),

        // --- se cae (barranco / puente / muelle / pozo) ---
        m("SE CAYO AL BARRANCO", T_CAIDA, 0, 0, false),
        m("SE CAYO DE UN PUENTE",T_CAIDA, 1, 0, false),
        mb("SE CAYO DE UN MUELLE",T_CAIDA, 2, 0, false, "PLAYA", "PANTANO"),
        m("SE CAYO EN UN POZO",  T_CAIDA, 3, 0, false),
        mb("SE CAYO A UN LAGO",  T_CHISTE, 3, 0, false, "PLAYA", "PANTANO", "BOSQUE", "SELVA"),
        mb("SE CAYO POR UN ACANTILADO",T_CAIDA,0, 0, false, "CANON", "PLAYA"),
        m("SE SALIO EN UNA CURVA",T_CAIDA, 0, 0, false),

        // --- se lo traga algo (asfalto / arena / pantano / nieve / lava) ---
        m("SE LO TRAGO EL ASFALTO",T_HUNDE, 0, 0, false),
        mb("ARENAS MOVEDIZAS",   T_HUNDE, 1, 0, false, "DESIERTO", "CANON", "SALAR"),
        mb("SE HUNDIO EN EL PANTANO",T_HUNDE,2, 0, false, "PANTANO", "SELVA"),
        mb("SE HUNDIO EN LA NIEVE",T_HUNDE, 3, 0, false, "NIEVE", "CRISTAL", "AURORA"),
        mb("SE HUNDIO EN LAVA",  T_HUNDE, 4, 0, false, "VOLCAN", "INFIERNO", "LA TORRE"),
        m("UN SOCAVON",          T_HUNDE, 0, 0, false),
        mb("SE LO COMIO EL BARRO",T_HUNDE, 2, 0, false, "PANTANO", "SELVA", "TORMENTA"),

        // --- portal / vortice ---
        m("LO ABSORBIO UN PORTAL",T_PORTAL, 0, 0, false),
        m("VORTICE",             T_PORTAL, 1, 0, false),
        m("AGUJERO DE GUSANO",   T_PORTAL, 2, 0, false),
        m("GRIETA EN EL ESPACIO",T_PORTAL, 3, 0, false),
        m("SE LO LLEVO OTRA DIMENSION",T_PORTAL,4, 0, false),

        // --- desintegra ---
        m("SE HIZO POLVO",       T_DESINTEGRA, 0, 0, false),
        m("SE DESVANECIO",       T_DESINTEGRA, 1, 0, false),
        m("SE CONVIRTIO EN LUZ", T_DESINTEGRA, 2, 0, false),
        m("SE OXIDO EN SEGUNDOS",T_DESINTEGRA, 3, 0, false),
        m("SE EVAPORO",          T_DESINTEGRA, 0, 0, false),

        // --- clima extremo ---
        m("SE LO LLEVO UN TORNADO",T_CLIMA, 0, 0, false),
        mb("UNA OLA GIGANTE",    T_CLIMA, 1, 0, false, "PLAYA"),
        mb("TORMENTA DE ARENA",  T_CLIMA, 2, 0, false, "DESIERTO", "CANON", "SALAR"),
        m("GRANIZADA MORTAL",    T_CLIMA, 3, 0, false),
        mb("SEPULTADO POR UN ALUD",T_CLIMA, 4, 0, false, "NIEVE", "CRISTAL", "AURORA"),
        mb("VENTISCA BLANCA",    T_CLIMA, 5, 0, false, "NIEVE", "CRISTAL", "AURORA"),

        // --- la mafia ---
        m("SECUESTRARON A LA COPILOTO",T_MAFIA_KIDNAP,0, 0, true),
        m("LOS ENCERRARON",      T_MAFIA_BOX, 0, 0, true),
        m("MANIOBRA PIT",        T_MAFIA_BOX, 1, 0, true),
        m("LO SACARON DE LA RUTA",T_MAFIA_BOX,2, 0, true),
        m("TIROTEO DESDE UNA CAMIONETA",T_MAFIA_DRIVEBY,0, 0, true),
        m("EMBOSCADA",           T_MAFIA_DRIVEBY, 1, 0, true),
        m("LES PONCHARON LAS RUEDAS",T_MAFIA_DRIVEBY,2, 0, true),
        m("LOS CHOCARON A PROPOSITO",T_MAFIA_BOX,0, 0, true),
        m("LOS ESPERABAN",       T_MAFIA_DRIVEBY, 0, 0, true),
        m("SECUESTRO EXPRESS",   T_MAFIA_KIDNAP, 0, 0, true),
        m("AJUSTE DE CUENTAS",   T_MAFIA_DRIVEBY, 1, 0, true),
        m("LOS ACORRALARON",     T_MAFIA_BOX, 1, 0, true),

        // --- el motor vuela ---
        m("SE LE SALIO EL MOTOR",T_MOTOR, 0, 0, false),
        m("VOLO LA TRANSMISION", T_MOTOR, 0, 0, false),

        // --- chistes / absurdos ---
        m("PISO UNA CASCARA DE BANANA",T_CHISTE, 1, 0, false),
        m("UNA VACA EN LA RUTA", T_CHISTE, 2, 0, false),
        m("SE EQUIVOCO DE SALIDA",T_CHISTE, 4, 0, false),
        m("SE DURMIO AL VOLANTE",T_CHISTE, 5, 0, false),
        m("SE QUEDO MIRANDO EL CELULAR",T_CHISTE, 6, 0, false),
        m("FRENO PARA UNA FOTO", T_CHISTE, 7, 0, false),
        m("LO DISTRAJO EL COPILOTO",T_CHISTE, 8, 0, false),
        m("SE LE CRUZO UN PATO", T_CHISTE, 2, 0, false),
        m("SE LE PINCHO Y NO TENIA AUXILIO",T_CHISTE, 0, 0, false),
        m("GIRO EQUIVOCADO",     T_CHISTE, 4, 0, false),
        m("LO SALUDO UN ALIEN Y SE DISTRAJO",T_CHISTE, 9, 0, false),
        m("SE LE CAYO EL MATE",  T_CHISTE, 6, 0, false),

        // ==============================================================
        // EXCLUSIVAS DE UN TIPO DE NIVEL - coherentes con el escenario
        // (el jugador se quejo de morir "en la nieve" con pasto de playa)
        // ==============================================================
        mb("SE ESTRELLO CONTRA UNA PALMERA",T_PROP,  0, 0, false, "PLAYA"),
        mb("LO REVOLCO EL OLEAJE",          T_CLIMA, 1, 0, false, "PLAYA"),
        mb("ATROPELLO A UN BANISTA Y VOLCO",T_VUELCO,0, 2, false, "PLAYA"),
        mb("SE EMPANTANO EN LA ARENA MOJADA",T_HUNDE, 1, 0, false, "PLAYA"),
        mb("SE ENTERRO EN UNA DUNA",        T_HUNDE, 1, 0, false, "DESIERTO", "SALAR"),
        mb("ESPEJISMO: FRENO CONTRA LA NADA",T_CHISTE,4, 0, false, "DESIERTO", "SALAR"),
        mb("LO EMBISTIO UN CAMELLO",        T_CRIATURA,6,0, false, "DESIERTO"),
        mb("SE LO LLEVO UNA AVALANCHA",     T_CLIMA, 4, 0, false, "NIEVE", "AURORA"),
        mb("PATINO EN UNA PLACA DE HIELO",  T_GIRA,  0, 1, false, "NIEVE", "CRISTAL", "AURORA"),
        mb("CAYO EN UNA GRIETA GLACIAR",    T_HUNDE, 3, 0, false, "CRISTAL", "AURORA"),
        mb("SE CONGELO EL MOTOR",           T_ORILLA,0, 1, false, "NIEVE", "CRISTAL", "AURORA"),
        mb("GEISER DE LAVA",                T_DETONA,0, 8, false, "VOLCAN", "INFIERNO"),
        mb("UN RIO DE LAVA EN LA CURVA",    T_HUNDE, 4, 0, false, "VOLCAN", "INFIERNO", "LA TORRE"),
        mb("LE CAYO UNA BOMBA VOLCANICA",   T_CAE,   0, 0, false, "VOLCAN", "INFIERNO"),
        mb("SE LO TRAGO LA VEGETACION",     T_CRIATURA,3,0, false, "SELVA"),
        mb("PISO UNA TRAMPA DE LAS RUINAS", T_APLASTA,3, 0, false, "RUINAS"),
        mb("SE LO COMIO UN COCODRILO",      T_CRIATURA,0,0, false, "PANTANO"),
        mb("CHOCO DE FRENTE EN CONTRAMANO", T_MAFIA_BOX,2,0, false, "NOCHE", "AUTOPISTA", "NEON"),
        mb("SALTO MAL LA BARRERA DEL PUENTE",T_CAIDA, 1, 0, false, "NOCHE", "AUTOPISTA"),
        mb("SIN GRAVEDAD, SE FUE FLOTANDO", T_MAQUINA,0, 1, false, "ORBITA"),
        mb("LO GOLPEO BASURA ORBITAL",      T_CAE,   6, 0, false, "ORBITA"),
        mb("LO FULMINO UN RAYO DE LA TORMENTA",T_RAYO,0, 0, false, "TORMENTA"),
        mb("SE LO LLEVO UNA RIADA",         T_CLIMA, 1, 0, false, "TORMENTA", "PANTANO"),
        mb("LO ENCEGUECIO EL REFLEJO DEL SALAR",T_CHISTE,4,0, false, "SALAR"),
    };

    /**
     * Elige una muerte coherente con el bioma del nivel:
     *   - descarta las EXCLUSIVAS que no pertenecen a este escenario
     *   - 20% sesga por la causa (ver PlayerCar.C_*)
     * bioma = nombre de la Palette del nivel (ej "PLAYA"); null = solo comunes.
     */
    public static Muerte alAzar(int causa, String bioma)
    {
        if (Greenfoot.getRandomNumber(5) == 0) {
            for (int intento = 0; intento < 40; intento++) {
                Muerte c = CATALOGO[Greenfoot.getRandomNumber(CATALOGO.length)];
                if (c.encajaBioma(bioma) && encaja(c, causa)) return c;
            }
        }
        for (int intento = 0; intento < 60; intento++) {
            Muerte c = CATALOGO[Greenfoot.getRandomNumber(CATALOGO.length)];
            if (c.encajaBioma(bioma)) return c;
        }
        return CATALOGO[0];   // ORILLADO: siempre valido
    }

    /** Compat: sin bioma solo devuelve muertes comunes. */
    public static Muerte alAzar(int causa) { return alAzar(causa, null); }

    private static boolean encaja(Muerte c, int causa)
    {
        switch (causa) {
            case 2:  return c.tmpl == T_INCENDIO || c.tmpl == T_EXPLOTA || c.tmpl == T_DETONA
                         || c.tmpl == T_RAYO || c.tmpl == T_MAFIA_DRIVEBY;   // C_DISPARO
            case 1:  return c.tmpl == T_VUELCO || c.tmpl == T_CRIATURA || c.tmpl == T_CHISTE; // C_ANIMAL
            case 3:  return c.mafia || c.tmpl == T_MAQUINA || c.tmpl == T_PORTAL;             // C_TIEMPO
            default: return c.tmpl == T_PROP || c.tmpl == T_VUELCO || c.tmpl == T_GIRA
                         || c.tmpl == T_CAIDA || c.mafia;                                     // C_CHOQUE
        }
    }

    public static int total() { return CATALOGO.length; }
}
