import greenfoot.*;

/**
 * Roca (meteorito) que cae del cielo hacia un punto y revienta al impactar.
 * Se usa en la muerte METEORITO. No se congela con el mundo.
 */
public class Cae extends Objeto3D
{
    private final double xImpacto, zImpacto;
    private double vy = 55;

    public Cae(double xImpacto, double zImpacto)
    {
        this.xImpacto = xImpacto;
        this.zImpacto = zImpacto;
        this.x = xImpacto + Greenfoot.getRandomNumber(700) - 350;
        this.z = zImpacto + 1600;
        this.altura = 6500;
        inicializar(roca(), 520, 520);
    }

    public void act()
    {
        RaceWorld w = (RaceWorld) getWorld();
        if (w == null) return;

        altura -= vy;
        vy += 4.5;
        x += (xImpacto - x) * 0.09;
        z += (zImpacto - z) * 0.09;

        if (altura <= 90) {
            for (int i = 0; i < 5; i++)
                w.addObject(new Explosion(xImpacto + Greenfoot.getRandomNumber(900) - 450, 160,
                                          zImpacto + Greenfoot.getRandomNumber(700) - 350, 1900), -500, -500);
            Camara.sacudir(36);
            Sonido.efecto("explosion.wav");
            w.removeObject(this);
            return;
        }
        proyectar();
    }

    private GreenfootImage roca()
    {
        GreenfootImage g = new GreenfootImage(96, 96);
        g.setColor(new Color(58, 40, 30));
        g.fillOval(12, 12, 72, 72);
        g.setColor(new Color(40, 28, 22));
        g.fillOval(30, 34, 24, 20);
        g.setColor(new Color(255, 150, 40, 210));
        g.fillOval(0, 0, 96, 44);
        g.setColor(new Color(255, 220, 150, 180));
        g.fillOval(24, 4, 48, 22);
        return g;
    }
}
