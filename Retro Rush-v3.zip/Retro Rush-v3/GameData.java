import java.io.*;
import java.util.*;

/**
 * Estado global del juego. No es un Actor ni un World: solo guarda datos
 * que sobreviven entre mundos (menu -> carrera -> resultados).
 */
public class GameData
{
    public static final int ANCHO = 800;
    public static final int ALTO  = 600;
    public static final int NIVEL_MAX = 40;
    /** Cada cuantos niveles hay un jefe (mini-jefe); el nivel MAX es el jefe final. */
    public static final int NIVELES_POR_JEFE = 5;

    /** La intro comic se muestra una sola vez por sesion (menu la repite). */
    public static boolean introVista = false;

    // ---- modo admin (combo CONTROL + Z + 4 en el menu) ----
    // NO persiste: hay que rehacer el combo cada sesion. El combo tambien lo apaga.
    public static boolean adminMenu = false;   // combo hecho: aparece el apartado MODO ADMIN en Ajustes
    public static boolean adminTodo = false;   // se pulso "DESBLOQUEAR TODO"
    public static boolean adminInstakill = false;  // tecla K -> el jugador muere al instante
    public static boolean adminNextLevel = false;  // tecla L -> salta el nivel (2 veces salta al jefe)
    // MODO DIOS: cada cosa se activa por separado (menu DiosWorld)
    public static boolean diosVida   = false;  // no recibes dano
    public static boolean diosBalas  = false;  // balas infinitas, sin recarga
    public static boolean diosDano   = false;  // balas hacen 55 (EL DON ~10 tiros)
    public static boolean diosTurbo  = false;  // turbo infinito
    public static boolean diosInmune = false;  // los choques y efectos NO te frenan
    public static boolean diosUlti   = false;  // la ULTI siempre esta llena
    public static boolean modoDios() { return diosVida || diosBalas || diosDano || diosTurbo || diosInmune || diosUlti; }
    public static boolean finalDesbloqueado = false;  // se termino el juego alguna vez (sí persiste)

    private static final String F_FINAL = "final.flag";

    /** true si la partida actual empezo desde el menu NIVELES (no cuenta al ranking). */
    public static boolean runAdmin = false;

    /** El combo muestra/oculta los botones de admin (NO desbloquea nada solo). */
    public static void activarAdmin() { adminMenu = true; }

    public static void quitarAdmin()
    {
        adminMenu = false;
        adminTodo = false;
        adminInstakill = false;
        adminNextLevel = false;
        diosVida = false; diosBalas = false; diosDano = false; diosTurbo = false;
        diosInmune = false; diosUlti = false;
        if (!auto().desbloqueado()) autoSeleccionado = 0;
    }

    /** El boton DESBLOQUEAR TODO: alterna tener todo desbloqueado o no. */
    public static void alternarTodo()
    {
        adminTodo = !adminTodo;
        if (!adminTodo && !auto().desbloqueado()) autoSeleccionado = 0;
    }

    public static void desbloquearFinal()  { finalDesbloqueado = true; marcar(F_FINAL); }

    public static void cargarAdmin()
    {
        // limpia flags de admin de versiones anteriores (antes se guardaban)
        borrar("admin.flag");
        borrar("admin_todo.flag");
        if (existe(F_FINAL)) finalDesbloqueado = true;
    }

    private static boolean existe(String f)
    {
        try { return new File(f).exists(); } catch (Exception e) { return false; }
    }

    private static void borrar(String f)
    {
        try { new File(f).delete(); } catch (Exception e) {}
    }

    private static void marcar(String f)
    {
        try {
            PrintWriter pw = new PrintWriter(new FileWriter(f));
            pw.println("1");
            pw.close();
        } catch (Exception ignorada) {}
    }

    // ---- autos disponibles ----
    public static CarType[] autos = CarType.crearLista();
    public static int autoSeleccionado = 0;

    // ---- progreso ----
    public static int puntajeTotal   = 0;   // acumulado historico -> desbloquea autos
    public static int puntajeCarrera = 0;   // puntaje de la partida actual
    public static int nivelActual    = 1;
    public static long tiempoInicio  = 0;
    public static long tiempoTotalMs = 0;
    public static boolean completado = false;
    public static int ultimaPenalizacion = 0;

    // ---- modo challenge ----
    public static boolean modoChallenge = false;
    public static int energiaCarry = 0;
    public static int tiempoCarry  = 0;
    public static final int TIEMPO_CHALLENGE_INICIAL = 4200;
    public static final int TIEMPO_CHALLENGE_BONUS   = 1500;

    /** Cuantas veces se recorrieron los 15 tramos en modo challenge. */
    public static int vuelta = 0;

    /** Cada cuantos frames sube un tramo de dificultad en challenge. */
    public static final int FRAMES_POR_TRAMO = 2200;

    /** Fraccion del puntaje total que se pierde al ser destruido. */
    public static final double PENALIZACION = 0.25;

    // ==================================================================
    // ROGUELITE: modificadores que se acumulan al elegir mejoras.
    // Se resetean al empezar una partida nueva. El resto del juego los lee.
    // ==================================================================
    public static double  modPuntaje      = 1.0;   // multiplicador de puntos
    public static int     modVelocidad    = 0;     // + a la velocidad objetivo
    public static int     modEnergiaMax   = 0;     // + a la energia maxima
    public static double  modDanoRecibido = 1.0;   // multiplicador de dano (<1 mejor)
    public static int     modBalas        = 0;     // + al cargador
    public static double  modCadencia     = 1.0;   // <1 dispara mas rapido
    public static double  modRegenBalas   = 1.0;   // <1 recarga mas rapido
    public static double  modNitro        = 1.0;   // potencia del turbo
    public static double  modUltiCarga    = 1.0;   // velocidad de carga de la bazuca
    public static double  modRoce         = 1.0;   // multiplicador de puntos por roce
    public static int     modInvuln       = 0;     // + frames de invulnerabilidad
    public static double  modSalto        = 1.0;   // altura de salto
    public static double  modFrenazo      = 1.0;   // >1 conservas mas velocidad al chocar
    public static int     modArranqueEnergia = 0;  // energia extra al empezar cada nivel
    public static int     modArranqueUlti    = 0;  // ulti al empezar cada nivel
    public static boolean modImanPuntos   = false; // los roces cuentan desde mas lejos
    public static boolean modEscudoInicial = false;// bloqueas el primer golpe de cada nivel
    public static boolean modExplotaChoque = false;// al chocar, revientas a los rivales cerca
    public static boolean modBalaDoble    = false; // toda arma dispara doble
    public static boolean modRevivir      = false; // una vez por partida, revives con 40
    public static boolean modRegenEnergia = false; // recuperas 1 de energia cada 2 s
    public static boolean revivirUsado    = false;
    public static double  suerteMult      = 0.0;    // sube la prob. de rara/epica/legendaria
    public static int     modDanoBala     = 1;      // dano de cada bala a jefes/helis (base 1)
    public static double  modRecarga      = 1.0;    // <1 = recarga (RECARGA) mas rapida
    public static boolean modSinUlti      = false;  // carta trampa: te quedas sin bazuca

    /** Mejoras ya elegidas en esta partida (ids), para no repetir las unicas. */
    public static List<String> mejorasElegidas = new ArrayList<String>();

    /** Tras un jefe: 0 normal, 1 = proxima seleccion todo rara+, 2 = todo epica+. */
    public static int cartaGarantizada = 0;

    public static void resetMejoras()
    {
        modPuntaje = 1.0; modVelocidad = 0; modEnergiaMax = 0; modDanoRecibido = 1.0;
        modBalas = 0; modCadencia = 1.0; modRegenBalas = 1.0; modNitro = 1.0;
        modUltiCarga = 1.0; modRoce = 1.0; modInvuln = 0; modSalto = 1.0; modFrenazo = 1.0;
        modArranqueEnergia = 0; modArranqueUlti = 0;
        modImanPuntos = false; modEscudoInicial = false; modExplotaChoque = false;
        modBalaDoble = false; modRevivir = false; modRegenEnergia = false; revivirUsado = false;
        suerteMult = 0.0; modDanoBala = 1; modRecarga = 1.0; modSinUlti = false;
        cartaGarantizada = 0;
        mejorasElegidas = new ArrayList<String>();
    }

    // ---- ranking ----
    public static List<RankEntry> ranking = new ArrayList<RankEntry>();
    private static final String ARCHIVO = "ranking.txt";
    private static boolean cargado = false;

    public static CarType auto()
    {
        return autos[autoSeleccionado];
    }

    public static void nuevaPartida()
    {
        nuevaPartida(false);
    }

    public static void nuevaPartida(boolean challenge)
    {
        modoChallenge = challenge;
        puntajeCarrera = 0;
        nivelActual = 1;
        vuelta = 0;
        tiempoTotalMs = 0;
        completado = false;
        energiaCarry = challenge ? 100 : 0;
        tiempoCarry  = TIEMPO_CHALLENGE_INICIAL;
        tiempoInicio = System.currentTimeMillis();
        runAdmin = false;
        resetMejoras();
    }

    public static long tiempoActualMs()
    {
        if (tiempoInicio == 0) return 0;
        return System.currentTimeMillis() - tiempoInicio;
    }

    /**
     * Cierra la partida y guarda el resultado en el ranking.
     * Si ganaste, el puntaje de la carrera se suma al total.
     * Si perdiste, no se suma NADA y encima se descuenta un 25% del total.
     */
    public static void terminarPartida(boolean gano)
    {
        completado = gano;
        tiempoTotalMs = tiempoActualMs();

        // El challenge SIEMPRE termina cuando te destruyen: seria absurdo
        // castigarlo. Ahi el puntaje se suma igual y no hay penalizacion.
        if (gano || modoChallenge) {
            puntajeTotal += puntajeCarrera;
            ultimaPenalizacion = 0;
        } else {
            ultimaPenalizacion = (int) (puntajeTotal * PENALIZACION);
            puntajeTotal -= ultimaPenalizacion;
            if (puntajeTotal < 0) puntajeTotal = 0;
        }

        // las partidas empezadas desde el menu NIVELES no van al ranking
        if (runAdmin) return;

        RankEntry e = new RankEntry(auto().nombre, puntajeCarrera, tiempoTotalMs,
                                    gano, modoChallenge);
        ranking.add(e);
        guardarRanking();
    }

    public static String formatoTiempo(long ms)
    {
        long total = ms / 100;          // decimas
        long min = total / 600;
        long seg = (total / 10) % 60;
        long dec = total % 10;
        return String.format("%02d:%02d.%d", min, seg, dec);
    }

    // ------------------------------------------------------------------
    // Persistencia simple en archivo de texto (funciona ejecutando local)
    // ------------------------------------------------------------------
    public static void cargarRanking()
    {
        if (cargado) return;
        cargado = true;
        BufferedReader br = null;
        try {
            File f = new File(ARCHIVO);
            if (!f.exists()) return;
            br = new BufferedReader(new FileReader(f));
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] p = linea.split(";");
                if (p.length >= 4) {
                    boolean ch = (p.length >= 5) && Boolean.parseBoolean(p[4]);
                    ranking.add(new RankEntry(p[0],
                                              Integer.parseInt(p[1]),
                                              Long.parseLong(p[2]),
                                              Boolean.parseBoolean(p[3]),
                                              ch));
                }
            }
        } catch (Exception ex) {
            System.out.println("No se pudo leer el ranking: " + ex.getMessage());
        } finally {
            try { if (br != null) br.close(); } catch (Exception ignorada) {}
        }
    }

    public static void guardarRanking()
    {
        PrintWriter pw = null;
        try {
            pw = new PrintWriter(new FileWriter(ARCHIVO));
            for (RankEntry e : ranking) {
                pw.println(e.auto + ";" + e.puntaje + ";" + e.tiempoMs + ";"
                           + e.completado + ";" + e.challenge);
            }
        } catch (Exception ex) {
            System.out.println("No se pudo guardar el ranking: " + ex.getMessage());
        } finally {
            if (pw != null) pw.close();
        }
    }

    /** Top por puntaje (mayor primero). */
    public static List<RankEntry> topPuntaje()
    {
        List<RankEntry> l = new ArrayList<RankEntry>(ranking);
        Collections.sort(l, new Comparator<RankEntry>() {
            public int compare(RankEntry a, RankEntry b) { return b.puntaje - a.puntaje; }
        });
        return l;
    }

    /** Supervivencia del challenge: gana el que aguanto MAS tiempo. */
    public static List<RankEntry> topSupervivencia()
    {
        List<RankEntry> l = new ArrayList<RankEntry>();
        for (RankEntry e : ranking) if (e.challenge) l.add(e);
        Collections.sort(l, new Comparator<RankEntry>() {
            public int compare(RankEntry a, RankEntry b) { return Long.compare(b.tiempoMs, a.tiempoMs); }
        });
        return l;
    }

    /** Top por tiempo (menor primero), solo campanas completadas. */
    public static List<RankEntry> topTiempo()
    {
        List<RankEntry> l = new ArrayList<RankEntry>();
        for (RankEntry e : ranking) if (e.completado && !e.challenge) l.add(e);
        Collections.sort(l, new Comparator<RankEntry>() {
            public int compare(RankEntry a, RankEntry b) { return Long.compare(a.tiempoMs, b.tiempoMs); }
        });
        return l;
    }

    /** Top general: puntaje + bonus por rapidez. */
    public static List<RankEntry> topFinal()
    {
        List<RankEntry> l = new ArrayList<RankEntry>(ranking);
        Collections.sort(l, new Comparator<RankEntry>() {
            public int compare(RankEntry a, RankEntry b) { return b.puntajeFinal() - a.puntajeFinal(); }
        });
        return l;
    }
}
