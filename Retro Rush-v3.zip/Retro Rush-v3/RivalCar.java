import greenfoot.*;

/**
 * Auto rival.
 *
 * - Si es mas lento, aparece chico en el horizonte, crece y lo rebasamos.
 * - Si es mas rapido, aparece grande por detras, nos pasa y se aleja
 *   achicandose hacia el horizonte.
 */
public class RivalCar extends Objeto3D
{
    private int carril;
    private double factor;         // velocidad respecto a la nuestra
    private boolean contado = false;
    private boolean contramano = false;
    private Color color;
    /** Ya se contabilizo el roce con este auto. */
    public boolean roceContado = false;

    private static final Color[] COLORES = {
        new Color(230, 220, 60), new Color(60, 200, 90), new Color(220, 90, 40),
        new Color(230, 230, 235), new Color(60, 90, 210), new Color(150, 60, 190)
    };

    public RivalCar(int carril, LevelConfig cfg, boolean nosRebasa)
    {
        this.carril = carril;
        Color c = COLORES[Greenfoot.getRandomNumber(COLORES.length)];
        this.color = c;
        inicializar(Sprites.rival(c), 400, 300);

        x = Camara.centroCarril(carril);
        altura = 0;

        if (nosRebasa) {
            factor = 1.10 + Greenfoot.getRandomNumber(25) / 100.0;
            z = 300;                               // aparece pegado atras
        } else {
            factor = 0.50 + Greenfoot.getRandomNumber(40) / 100.0;
            if (cfg.nivel >= 5) factor += 0.08;
            z = 15000 + Greenfoot.getRandomNumber(4000);
        }
    }

    /** Auto que viene DE FRENTE por la calzada contraria (puentes). */
    public RivalCar deFrente()
    {
        contramano = true;
        factor = -0.7 - Greenfoot.getRandomNumber(45) / 100.0;   // se acerca de frente
        z = 15000 + Greenfoot.getRandomNumber(6000);
        setBase(Sprites.rivalFrente(color));
        return this;
    }

    public void act()
    {
        RaceWorld w = (RaceWorld) getWorld();
        if (w == null || w.congelado()) return;

        double v = w.getVelocidad();
        z += contramano ? v * factor : v * factor - v;   // contramano: acercamiento propio

        if (!contado && z < Camara.Z_JUGADOR) {
            contado = true;
            if (contramano)      w.sumarPuntaje(120);   // esquivaste uno de frente
            else if (factor < 1) w.sumarPuntaje(150);   // lo rebasamos nosotros
        }

        if (z < 150 || z > 30000) { w.removeObject(this); return; }

        proyectar();
    }

    /** Al chocar el rival tambien se descontrola y se frena. */
    public void rebotar()
    {
        factor = Math.max(0.30, factor - 0.30);
        z += 220;
        roceContado = true;          // un choque no cuenta ademas como roce
    }

    /** Lo destruye la explosion de la ulti. */
    public void destruir()
    {
        RaceWorld w = (RaceWorld) getWorld();
        if (w == null) return;
        w.sumarPuntaje(300);
        w.addObject(new Explosion(x, 120, z, 900), -500, -500);
        w.removeObject(this);
    }

    public int getCarril() { return carril; }
}
