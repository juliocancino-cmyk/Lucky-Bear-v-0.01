import greenfoot.*;

/**
 * Garage estilo FR Legends: flechas para cambiar de auto, estadisticas,
 * y desbloqueo por puntaje total acumulado.
 */
public class GarageWorld extends World
{
    private int indice = GameData.autoSeleccionado;
    private MenuButton anterior, siguiente, seleccionar, volver;

    public GarageWorld()
    {
        super(GameData.ANCHO, GameData.ALTO, 1);

        anterior    = new MenuButton("<",           "prev",  60, 56);
        siguiente   = new MenuButton(">",           "next",  60, 56);
        seleccionar = new MenuButton("SELECCIONAR", "sel",  260, 56);
        volver      = new MenuButton("VOLVER",      "back", 150, 52);

        addObject(volver,       95, 562);
        addObject(anterior,    210, 562);
        addObject(siguiente,   282, 562);
        addObject(seleccionar, 560, 562);

        dibujar();
    }

    public void act()
    {
        if (anterior.fueClickeado()) {
            indice = (indice - 1 + GameData.autos.length) % GameData.autos.length;
            dibujar();
        } else if (siguiente.fueClickeado()) {
            indice = (indice + 1) % GameData.autos.length;
            dibujar();
        } else if (seleccionar.fueClickeado() && GameData.autos[indice].desbloqueado()) {
            GameData.autoSeleccionado = indice;
            Greenfoot.setWorld(new MenuWorld());
        } else if (volver.fueClickeado()) {
            Greenfoot.setWorld(new MenuWorld());
        }
    }

    private void dibujar()
    {
        CarType c = GameData.autos[indice];
        boolean ok = c.desbloqueado();
        seleccionar.setActivo(ok);
        seleccionar.setTexto(ok ? "SELECCIONAR" : "BLOQUEADO");

        GreenfootImage f = getBackground();
        f.setColor(new Color(38, 40, 48));
        f.fill();

        // piso del garage
        f.setColor(new Color(52, 55, 65));
        f.fillRect(0, 360, GameData.ANCHO, GameData.ALTO - 360);
        f.setColor(new Color(70, 74, 86));
        for (int x = 0; x < GameData.ANCHO; x += 80) f.fillRect(x, 360, 3, GameData.ALTO - 360);

        // titulo
        f.setFont(new Font("Monospaced", true, false, 44));
        f.setColor(new Color(250, 205, 40));
        f.drawString("GARAGE", 40, 70);
        f.setFont(new Font("Monospaced", true, false, 18));
        f.setColor(Color.WHITE);
        f.drawString("PUNTOS TOTALES: " + GameData.puntajeTotal, 40, 100);

        // nombre del auto (arriba a la izquierda)
        f.setFont(new Font("Monospaced", true, false, 26));
        f.setColor(ok ? Color.WHITE : new Color(160, 160, 165));
        f.drawString(c.nombre + "   (" + (indice + 1) + "/" + GameData.autos.length + ")", 55, 148);

        // auto (mitad izquierda)
        GreenfootImage img = c.imagen();
        img.scale(300, 225);
        if (!ok) img.setTransparency(70);
        f.drawImage(img, 45, 172);

        barra(f, 60, 428, "VELOCIDAD", c.velocidad, new Color(230, 90, 70));
        barra(f, 60, 470, "MANEJO",    c.manejo,    new Color(90, 190, 240));

        // ---- panel de info (mitad derecha, texto envuelto) ----
        int px = 388, pw = GameData.ANCHO - px - 20;
        f.setColor(new Color(20, 22, 28, 235));
        f.fillRect(px, 150, pw, 384);
        f.setColor(new Color(255, 200, 60));
        f.drawRect(px, 150, pw, 384);

        int y = 180;
        f.setFont(new Font("Monospaced", true, false, 13));
        f.setColor(new Color(150, 150, 160));
        f.drawString("HABILIDAD", px + 14, y);
        y += 22;
        f.setFont(new Font("Monospaced", true, false, 19));
        f.setColor(new Color(255, 210, 70));
        f.drawString(c.nombreHabilidad(), px + 14, y);
        y += 22;
        y = texto(f, c.descripcionHabilidad(), px + 14, y, 40, Color.WHITE, 14);
        if (c.derrapa)
            y = texto(f, "+ Derrapa y echa humo al cambiar de carril", px + 14, y, 40,
                      new Color(255, 120, 170), 13);

        y += 14;
        f.setFont(new Font("Monospaced", true, false, 13));
        f.setColor(new Color(150, 150, 160));
        f.drawString("ULTI  (tecla X)", px + 14, y);
        y += 22;
        f.setFont(new Font("Monospaced", true, false, 19));
        f.setColor(new Color(120, 220, 255));
        f.drawString(c.ultiNombre(), px + 14, y);
        y += 22;
        texto(f, c.ultiDesc(), px + 14, y, 40, Color.WHITE, 14);

        if (!ok) {
            f.setFont(new Font("Monospaced", true, false, 17));
            f.setColor(new Color(255, 110, 110));
            f.drawString("Necesitas " + c.puntajeDesbloqueo + " puntos", px + 14, 512);
        }
    }

    /** Dibuja texto envuelto y devuelve la Y siguiente. */
    private int texto(GreenfootImage f, String s, int x, int y, int max, Color col, int tam)
    {
        f.setFont(new Font("Monospaced", false, false, tam));
        f.setColor(col);
        String cur = "";
        for (String p : s.split(" ")) {
            if (!cur.isEmpty() && cur.length() + p.length() + 1 > max) {
                f.drawString(cur, x, y); y += tam + 5; cur = p;
            } else cur = cur.isEmpty() ? p : cur + " " + p;
        }
        if (!cur.isEmpty()) { f.drawString(cur, x, y); y += tam + 5; }
        return y;
    }

    private void barra(GreenfootImage f, int x, int y, String etiqueta, int valor, Color color)
    {
        f.setFont(new Font("Monospaced", true, false, 15));
        f.setColor(Color.WHITE);
        f.drawString(etiqueta, x, y - 6);
        f.setColor(new Color(255, 255, 255, 60));
        f.fillRect(x, y, 200, 16);
        f.setColor(color);
        f.fillRect(x, y, valor * 20, 16);
        f.setColor(Color.BLACK);
        f.drawRect(x, y, 200, 16);
    }
}
