/**
 * Dificultad de cada nivel (hasta GameData.NIVEL_MAX).
 * Las unidades son de MUNDO (las mismas que usa la camara), no pixeles.
 */
public class LevelConfig
{
    public int nivel;
    public int distanciaObjetivo;
    public double velocidadBase;
    public int framesTrafico;
    public int framesEnemigo;
    public int tiempoLimite;        // en frames
    public HeliTipo heli;
    public Palette paleta;
    /** true = puente de 2 calzadas separadas por barrera (solo algunos niveles nocturnos). */
    public boolean puente;

    private LevelConfig(int n)
    {
        nivel = n;

        // curva larga: 40 niveles. La velocidad crece menos y ademas
        // RaceWorld.velocidadObjetivo() le pone un techo (~340 km/h): antes
        // el nivel final llegaba a 415 y era imposible reaccionar.
        distanciaObjetivo = 4200 + n * 360;
        velocidadBase     = 110 + n * 3.3;
        framesTrafico     = Math.max(14, 74 - (int) (n * 1.5));
        framesEnemigo     = Math.max(58, 250 - n * 5);

        // frames que tardarias yendo siempre a fondo, con un 45% de margen
        double frames = distanciaObjetivo * 100.0 / (velocidadBase + 40);
        tiempoLimite  = (int) (frames * 1.45);

        heli   = HeliTipo.paraNivel(n);
        paleta = Palette.get(n);

        // puente nocturno: algunos niveles oscuros de la primera mitad
        puente = (paleta.nombre.equals("NOCHE")
               || paleta.nombre.equals("AUTOPISTA")
               || paleta.nombre.equals("NEON")) && n <= 20;

        paleta.oscurecerHaciaJefe(n);   // los niveles se oscurecen y enrojecen hacia el jefe
    }

    /**
     * Modo challenge: cada vez que se completan los 15 tramos empieza una
     * vuelta nueva y todo se endurece. Esto es lo que lo hace infinito.
     */
    public void aplicarVuelta(int vuelta)
    {
        if (vuelta <= 0) return;

        velocidadBase *= 1 + vuelta * 0.10;
        framesTrafico  = Math.max(11, framesTrafico - vuelta * 3);
        framesEnemigo  = Math.max(45, framesEnemigo - vuelta * 12);

        heli.vida     += vuelta;
        heli.dano     += vuelta * 2;
        heli.cadencia  = Math.max(30, heli.cadencia - vuelta * 6);
        heli.puntos   += vuelta * 200;
    }

    public static LevelConfig get(int n)
    {
        if (n < 1) n = 1;
        if (n > GameData.NIVEL_MAX) n = GameData.NIVEL_MAX;
        return new LevelConfig(n);
    }
}
