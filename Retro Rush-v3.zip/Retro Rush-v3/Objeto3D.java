import greenfoot.*;

/**
 * Clase base de todo lo que vive en la ruta con perspectiva.
 * Guarda las coordenadas de mundo y se encarga de colocarse y
 * escalarse solo en pantalla cada frame.
 */
public abstract class Objeto3D extends Actor
{
    protected double x;        // lateral
    protected double altura;   // altura del borde inferior del sprite
    protected double z;        // profundidad

    protected double anchoMundo;
    protected double altoMundo;

    protected GreenfootImage base;
    private int ultimoAncho = -1;

    protected void inicializar(GreenfootImage base, double anchoMundo, double altoMundo)
    {
        this.base = base;
        this.anchoMundo = anchoMundo;
        this.altoMundo = altoMundo;
        setImage(new GreenfootImage(base));
    }

    /** Cambia la imagen base y fuerza el re-escalado (pilotos animados). */
    protected void setBase(GreenfootImage nueva)
    {
        base = nueva;
        ultimoAncho = -1;
    }

    /** Recalcula posicion y tamano en pantalla segun la profundidad. */
    protected void proyectar()
    {
        double e = Camara.escala(z);
        int w = (int) (anchoMundo * e);
        int h = (int) (altoMundo * e);

        if (w < 2 || h < 2) { setLocation(-500, -500); return; }

        // solo re-escalamos cuando el tamano cambio de verdad (rendimiento).
        // Umbral 3 px: con la camara dinamica (FOCAL variable) el tamano se
        // mueve casi cada frame y no hace falta re-escalar por 1 pixel.
        if (ultimoAncho < 0 || Math.abs(w - ultimoAncho) >= 3) {
            GreenfootImage img = new GreenfootImage(base);
            img.scale(w, h);
            setImage(img);
            ultimoAncho = w;
        }

        int sx = Camara.px(x, z);
        int sy = Camara.py(altura, z) - getImage().getHeight() / 2;
        setLocation(sx, sy);
    }

    /** Distancia real en 3D hasta otro objeto. */
    public double distanciaA(Objeto3D o)
    {
        double dx = o.x - x;
        double da = o.altura - altura;
        double dz = o.z - z;
        return Math.sqrt(dx * dx + da * da + dz * dz);
    }

    public double getX3D()    { return x; }
    public double getAltura() { return altura; }
    public double getZ()      { return z; }
}
