import greenfoot.*;
import java.util.*;

/**
 * Mejora roguelite. Entre niveles el juego ofrece 3 al azar (MejoraWorld) y
 * la elegida se acumula el resto de la partida (modificadores en GameData).
 *
 * RAREZAS y probabilidad: cada rareza tiene un peso base. Las cartas SUERTE
 * suben GameData.suerteMult, que multiplica el peso de rara / epica /
 * legendaria (las legendarias son casi imposibles sin suerte). Una carta
 * que ya elegiste NO vuelve a salir... salvo las SUERTE, que se repiten.
 */
public class Mejora
{
    public static final int COMUN = 0, RARA = 1, EPICA = 2, LEGENDARIA = 3;

    // peso base por rareza (probabilidad relativa de aparecer)
    private static final double[] PESO = { 1000, 220, 34, 0.8 };

    // categorias de icono
    public static final int I_VEL = 0, I_ENE = 1, I_ARMA = 2, I_PTS = 3,
                            I_SUERTE = 4, I_ULTI = 5, I_SALTO = 6, I_ESP = 7;

    public final String id, nombre, desc;
    public final int rareza;
    public final int icono;
    public final boolean esSuerte;   // repetible

    public Mejora(String id, String nombre, String desc, int rareza, int icono, boolean esSuerte)
    {
        this.id = id; this.nombre = nombre; this.desc = desc;
        this.rareza = rareza; this.icono = icono; this.esSuerte = esSuerte;
    }

    public Color color()
    {
        switch (rareza) {
            case LEGENDARIA: return new Color(255, 200, 60);
            case EPICA:      return new Color(190, 120, 255);
            case RARA:       return new Color(110, 180, 255);
            default:         return new Color(205, 205, 210);
        }
    }

    public String rarezaNombre()
    {
        switch (rareza) {
            case LEGENDARIA: return "LEGENDARIA";
            case EPICA:      return "EPICA";
            case RARA:       return "RARA";
            default:         return "COMUN";
        }
    }

    private double peso()
    {
        double w = PESO[rareza];
        if (rareza >= RARA) w *= (1.0 + Math.min(7.0, GameData.suerteMult));
        return w;
    }

    /** Probabilidad aproximada de que esta carta salga en un hueco, en %. */
    public double probabilidad()
    {
        double total = 0;
        for (Mejora m : CATALOGO)
            if (m.esSuerte || !GameData.mejorasElegidas.contains(m.id)) total += m.peso();
        return total <= 0 ? 0 : peso() / total * 100.0;
    }

    // ==================================================================
    public static void aplicar(String id)
    {
        GameData.mejorasElegidas.add(id);
        switch (id) {
            // suerte (repetibles)
            case "suerte_1": GameData.suerteMult += 0.5;  break;
            case "suerte_2": GameData.suerteMult += 1.3;  break;
            case "suerte_3": GameData.suerteMult += 2.6;  break;

            // puntaje
            case "pts_1": GameData.modPuntaje += 0.12; break;
            case "pts_2": GameData.modPuntaje += 0.24; break;
            case "pts_3": GameData.modPuntaje += 0.42; break;
            case "pts_leg": GameData.modPuntaje += 1.1; break;
            case "roce_1": GameData.modRoce += 0.50; break;
            case "roce_2": GameData.modRoce += 1.00; break;
            case "iman":   GameData.modImanPuntos = true; break;

            // velocidad / turbo
            case "vel_1": GameData.modVelocidad += 10; break;
            case "vel_2": GameData.modVelocidad += 22; break;
            case "vel_3": GameData.modVelocidad += 38; break;
            case "vel_leg": GameData.modVelocidad += 58; GameData.modFrenazo += 0.2; break;
            case "nitro_1": GameData.modNitro += 0.22; break;
            case "nitro_2": GameData.modNitro += 0.48; break;
            case "ulti_1": GameData.modUltiCarga += 0.28; break;
            case "ulti_2": GameData.modUltiCarga += 0.60; break;
            case "ulti_leg": GameData.modUltiCarga += 1.0; GameData.modArranqueUlti = 45; break;
            case "arr_ulti": GameData.modArranqueUlti = 50; GameData.modUltiCarga += 0.1; break;

            // defensa
            case "ene_1": GameData.modEnergiaMax += 20; break;
            case "ene_2": GameData.modEnergiaMax += 45; break;
            case "ene_3": GameData.modEnergiaMax += 75; break;
            case "blin_1": GameData.modDanoRecibido *= 0.90; break;
            case "blin_2": GameData.modDanoRecibido *= 0.80; break;
            case "blin_3": GameData.modDanoRecibido *= 0.68; break;
            case "blin_leg": GameData.modDanoRecibido *= 0.50; GameData.modEnergiaMax += 30; break;
            case "inv_1": GameData.modInvuln += 20; break;
            case "inv_2": GameData.modInvuln += 45; break;
            case "fren_1": GameData.modFrenazo += 0.20; break;
            case "fren_2": GameData.modFrenazo += 0.45; break;
            case "esc_niv": GameData.modEscudoInicial = true; break;
            case "regen_e": GameData.modRegenEnergia = true; break;
            case "revivir": GameData.modRevivir = true; break;
            case "arr_ene": GameData.modArranqueEnergia += 25; break;

            // armas
            case "bal_1": GameData.modBalas += 2; break;
            case "bal_2": GameData.modBalas += 4; break;
            case "cad_1": GameData.modCadencia *= 0.88; break;
            case "cad_2": GameData.modCadencia *= 0.76; break;
            case "cad_leg": GameData.modCadencia *= 0.60; GameData.modBalas += 2; break;
            case "rgb_1": GameData.modRegenBalas *= 0.80; break;
            case "rgb_2": GameData.modRegenBalas *= 0.62; break;
            case "doble": GameData.modBalaDoble = true; break;
            case "explota": GameData.modExplotaChoque = true; break;

            // movilidad
            case "salto_1": GameData.modSalto += 0.22; break;
            case "salto_2": GameData.modSalto += 0.45; break;

            // combinadas (trade-offs suaves)
            case "glass":    GameData.modPuntaje += 0.9; GameData.modEnergiaMax -= 18; break;
            case "vel_frag": GameData.modVelocidad += 30; GameData.modDanoRecibido *= 1.08; break;
            case "tanque":   GameData.modEnergiaMax += 55; GameData.modVelocidad -= 12; break;
            case "afort":    GameData.modPuntaje += 0.10; GameData.modEnergiaMax += 8; break;
            case "kamikaze": GameData.modRoce += 0.7; GameData.modDanoRecibido *= 1.06; break;
            case "sabio":    GameData.modUltiCarga += 0.35; GameData.modPuntaje += 0.12; break;
            case "acero":    GameData.modDanoRecibido *= 0.82; GameData.modFrenazo += 0.15; break;
            case "gatillo":  GameData.modCadencia *= 0.82; GameData.modBalas += 1; break;

            // dano de balas a jefes / helis
            case "dano_1": GameData.modDanoBala += 1; break;
            case "dano_2": GameData.modDanoBala += 2; break;
            case "dano_3": GameData.modDanoBala += 4; break;
            case "dano_leg": GameData.modDanoBala += 8; break;

            // recarga
            case "rec_1": GameData.modRecarga *= 0.80; break;
            case "rec_2": GameData.modRecarga *= 0.60; break;

            // cartas trampa / sacrificio
            case "t_frenos":  GameData.modVelocidad += 40; GameData.modFrenazo = 0.40; break;
            case "t_papel":   GameData.modPuntaje += 1.5; GameData.modDanoRecibido *= 1.5; break;
            case "t_lastre":  GameData.modEnergiaMax += 60; GameData.modVelocidad -= 25; break;
            case "t_avaro":   GameData.modRoce += 1.2; GameData.modEnergiaMax -= 25; break;
            case "s_todo":    GameData.modPuntaje += 1.0; GameData.modEnergiaMax -= 35; break;
            case "s_pacifista": GameData.modSinUlti = true; GameData.modPuntaje += 1.2; break;
            case "s_glass":   GameData.modDanoBala += 6; GameData.modDanoRecibido *= 1.35; break;

            // legendarias unicas
            case "leg_todo":
                GameData.modPuntaje += 0.3; GameData.modVelocidad += 16;
                GameData.modEnergiaMax += 22; GameData.modDanoRecibido *= 0.88;
                GameData.modCadencia *= 0.9; GameData.modUltiCarga += 0.25;
                break;
            case "leg_fenix": GameData.modRevivir = true; GameData.modRegenEnergia = true;
                              GameData.modEnergiaMax += 20; break;
        }
    }

    // ==================================================================
    private static final Mejora[] CATALOGO = {
        // --- SUERTE (repetibles) ---
        new Mejora("suerte_1","AMULETO",       "Sube la probabilidad de cartas raras y mejores", COMUN, I_SUERTE, true),
        new Mejora("suerte_2","TREBOL DE ORO", "Sube MUCHO la probabilidad de cartas buenas",    RARA,  I_SUERTE, true),
        new Mejora("suerte_3","PACTO",         "Probabilidad de cartas buenas por las nubes",    EPICA, I_SUERTE, true),

        // --- puntaje ---
        new Mejora("pts_1","GANCHO",       "+15% a todos los puntos",          COMUN, I_PTS, false),
        new Mejora("pts_2","PATROCINADOR", "+30% a todos los puntos",          RARA,  I_PTS, false),
        new Mejora("pts_3","LEYENDA",      "+60% a todos los puntos",          EPICA, I_PTS, false),
        new Mejora("pts_leg","IDOLO",      "Sube los puntos una barbaridad",   LEGENDARIA, I_PTS, false),
        new Mejora("roce_1","ROZANDO",     "Los roces valen +50%",             COMUN, I_PTS, false),
        new Mejora("roce_2","AL MILIMETRO","Los roces valen el doble",         RARA,  I_PTS, false),
        new Mejora("iman",  "IMAN",        "Los roces cuentan desde mas lejos",RARA,  I_PTS, false),

        // --- velocidad / turbo ---
        new Mejora("vel_1","AFINADO",   "+12 de velocidad punta",          COMUN, I_VEL, false),
        new Mejora("vel_2","ADMISION",  "+26 de velocidad punta",          RARA,  I_VEL, false),
        new Mejora("vel_3","BITURBO",   "+46 de velocidad punta",          EPICA, I_VEL, false),
        new Mejora("vel_leg","COHETE",  "Mucha velocidad punta y mas inercia", LEGENDARIA, I_VEL, false),
        new Mejora("nitro_1","VALVULA", "El turbo empuja +22%",            COMUN, I_VEL, false),
        new Mejora("nitro_2","OXIDO",   "El turbo empuja +48%",            RARA,  I_VEL, false),
        new Mejora("ulti_1","POLVORA",  "La bazuca carga +28% mas rapido", COMUN, I_ULTI, false),
        new Mejora("ulti_2","ARSENAL",  "La bazuca carga +60% mas rapido", RARA,  I_ULTI, false),
        new Mejora("ulti_leg","SOBRECARGA","La bazuca carga volando y arrancas con algo", LEGENDARIA, I_ULTI, false),
        new Mejora("arr_ulti","PRECARGA","Empiezas cada nivel con media bazuca", RARA, I_ULTI, false),

        // --- defensa ---
        new Mejora("ene_1","REFUERZO",  "+25 de energia maxima",   COMUN, I_ENE, false),
        new Mejora("ene_2","CHASIS",    "+55 de energia maxima",   RARA,  I_ENE, false),
        new Mejora("ene_3","FORTALEZA", "+95 de energia maxima",   EPICA, I_ENE, false),
        new Mejora("blin_1","LAMINA",   "-12% de dano recibido",   COMUN, I_ENE, false),
        new Mejora("blin_2","PLACA",    "-25% de dano recibido",   RARA,  I_ENE, false),
        new Mejora("blin_3","BUNKER",   "-40% de dano recibido",   EPICA, I_ENE, false),
        new Mejora("blin_leg","BLINDAJE PESADO","La mitad de dano y algo de energia", LEGENDARIA, I_ENE, false),
        new Mejora("inv_1","AMORTIGUA", "+20 frames invulnerable tras un golpe", COMUN, I_ENE, false),
        new Mejora("inv_2","FANTASMA",  "+45 frames invulnerable tras un golpe", RARA,  I_ENE, false),
        new Mejora("fren_1","INERCIA",  "Conservas +20% de velocidad al chocar", COMUN, I_VEL, false),
        new Mejora("fren_2","TREN DE RITMO","Conservas +45% de velocidad al chocar", RARA, I_VEL, false),
        new Mejora("esc_niv","SANTO",   "Bloqueas el primer golpe de cada nivel", EPICA, I_ENE, false),
        new Mejora("regen_e","BOTIQUIN","Recuperas energia lentamente", RARA, I_ENE, false),
        new Mejora("revivir","SEGUNDA VIDA","Una vez por partida revives con 40", EPICA, I_ESP, false),
        new Mejora("arr_ene","DESCANSO","+25 de energia al empezar cada nivel", COMUN, I_ENE, false),

        // --- armas ---
        new Mejora("bal_1","CARGADOR",  "+2 balas en el cargador",  COMUN, I_ARMA, false),
        new Mejora("bal_2","TAMBOR",    "+4 balas en el cargador",  RARA,  I_ARMA, false),
        new Mejora("cad_1","GATILLO FACIL","Disparas 15% mas rapido", COMUN, I_ARMA, false),
        new Mejora("cad_2","AUTOMATICO","Disparas 30% mas rapido",  RARA,  I_ARMA, false),
        new Mejora("cad_leg","MINIGUN", "Disparas mucho mas rapido y +2 balas", LEGENDARIA, I_ARMA, false),
        new Mejora("rgb_1","RECAMARA",  "Las balas se reponen 20% antes", COMUN, I_ARMA, false),
        new Mejora("rgb_2","FABRICA",   "Las balas se reponen 38% antes", RARA,  I_ARMA, false),
        new Mejora("doble", "DOBLE CANON","Toda arma dispara doble gastando 1 bala", EPICA, I_ARMA, false),
        new Mejora("explota","ONDA EXPANSIVA","Al chocar revientas rivales cercanos", EPICA, I_ESP, false),

        // --- movilidad ---
        new Mejora("salto_1","SUSPENSION","Saltas 22% mas alto",  COMUN, I_SALTO, false),
        new Mejora("salto_2","CATAPULTA", "Saltas 45% mas alto y flotas mas", RARA, I_SALTO, false),

        // --- combinadas ---
        new Mejora("glass", "FILO",      "+90% puntos, pero -18 de energia max", EPICA, I_PTS, false),
        new Mejora("vel_frag","AL LIMITE","+30 velocidad, pero +8% dano",   RARA,  I_VEL, false),
        new Mejora("tanque","MAMUT",     "+55 energia, pero -12 velocidad", RARA,  I_ENE, false),
        new Mejora("afort", "TREBOL",    "+10% puntos y +8 energia",        COMUN, I_PTS, false),
        new Mejora("kamikaze","TEMERARIO","Roces +70%, pero +6% dano",      RARA,  I_PTS, false),
        new Mejora("sabio", "ESTRATEGA", "Bazuca +35% carga y +12% puntos", RARA,  I_ULTI, false),
        new Mejora("acero", "YUNQUE",    "-18% dano y +15% inercia",        RARA,  I_ENE, false),
        new Mejora("gatillo","DEDO RAPIDO","+18% cadencia y +1 bala",       COMUN, I_ARMA, false),

        // --- dano de balas (para jefes) ---
        new Mejora("dano_1","TIRO CERTERO",   "Tus balas hacen mas dano a jefes y helis", COMUN, I_ARMA, false),
        new Mejora("dano_2","MUNICION PESADA","Tus balas hacen bastante mas dano",         RARA,  I_ARMA, false),
        new Mejora("dano_3","PERFORANTE",     "Tus balas atraviesan blindaje: mucho dano", EPICA, I_ARMA, false),
        new Mejora("dano_leg","OJIVA",        "Tus balas destrozan: matas jefes en pocos tiros", LEGENDARIA, I_ARMA, false),

        // --- recarga ---
        new Mejora("rec_1","MANOS RAPIDAS",  "Recargas 20% mas rapido al quedarte seco",  COMUN, I_ARMA, false),
        new Mejora("rec_2","CARGADOR RAPIDO","Recargas 40% mas rapido",                   RARA,  I_ARMA, false),

        // --- CARTAS TRAMPA / SACRIFICIO (tienen un costo) ---
        new Mejora("t_frenos", "SIN FRENOS",   "+40 velocidad, pero pierdes casi toda la velocidad al chocar", RARA, I_VEL, false),
        new Mejora("t_papel",  "PIEL DE PAPEL","x2.5 puntos, pero recibes +50% de dano",   EPICA, I_PTS, false),
        new Mejora("t_lastre", "LASTRE",       "+60 de energia, pero -25 de velocidad",    COMUN, I_ENE, false),
        new Mejora("t_avaro",  "AVARO",        "Roces mucho mejores, pero -25 de energia max", RARA, I_PTS, false),
        new Mejora("s_todo",   "TODO O NADA",  "x2 puntos, pero -35 de energia maxima",    RARA,  I_PTS, false),
        new Mejora("s_pacifista","PACIFISTA",  "Te quedas SIN bazuca (X), pero +120% puntos", EPICA, I_ULTI, false),
        new Mejora("s_glass",  "CANON FRAGIL", "Tus balas hacen mucho dano, pero recibes +35% de dano", EPICA, I_ARMA, false),

        // --- legendarias unicas ---
        new Mejora("leg_todo", "OBRA MAESTRA", "Un poco de TODO: puntos, velocidad, energia, blindaje, cadencia y bazuca", LEGENDARIA, I_ESP, false),
        new Mejora("leg_fenix","FENIX",        "Revives, regeneras energia y algo de energia max", LEGENDARIA, I_ESP, false),
    };

    /** Tres cartas distintas, por peso, sin repetir (salvo las SUERTE). */
    public static Mejora[] tresAlAzar() { return tresAlAzar(0); }

    /** minRareza: fuerza que todas sean de esa rareza o mejor (jefes). */
    public static Mejora[] tresAlAzar(int minRareza)
    {
        List<Mejora> pool = new ArrayList<Mejora>();
        for (Mejora m : CATALOGO) {
            if (!m.esSuerte && GameData.mejorasElegidas.contains(m.id)) continue;
            if (m.rareza < minRareza && !m.esSuerte) continue;
            pool.add(m);
        }
        if (pool.size() < 3) {   // el filtro dejo muy pocas: relajar
            pool.clear();
            for (Mejora m : CATALOGO)
                if (m.esSuerte || !GameData.mejorasElegidas.contains(m.id)) pool.add(m);
        }

        Mejora[] r = new Mejora[3];
        for (int k = 0; k < 3 && !pool.isEmpty(); k++) {
            double total = 0;
            for (Mejora m : pool) total += m.peso();
            double dado = Math.random() * total;
            Mejora elegida = pool.get(pool.size() - 1);
            for (Mejora m : pool) { dado -= m.peso(); if (dado <= 0) { elegida = m; break; } }
            r[k] = elegida;
            pool.remove(elegida);          // que no salga dos veces en la misma pantalla
        }
        for (int k = 0; k < 3; k++) if (r[k] == null) r[k] = CATALOGO[3];
        return r;
    }

    public static int total() { return CATALOGO.length; }
}
