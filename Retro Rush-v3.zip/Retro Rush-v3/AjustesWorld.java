import greenfoot.*;

/**
 * AJUSTES. Reemplaza al viejo boton CREDITOS del menu.
 *
 *   CONTROLES  - lista de todos los controles
 *   SONIDO     - dos barras que se arrastran (musica y efectos)
 *   CREDITOS   - NIGHT REAPERS STUDIO
 *   HISTORIA   - vuelve a ver la intro comic
 *   MODO ADMIN - solo si el combo esta activo: niveles, desbloqueo,
 *                insta kill, next level, modo dios y VER FINAL
 */
public class AjustesWorld extends World
{
    private int vista = 0;   // 0 menu, 1 controles, 2 sonido, 3 creditos, 4 modo admin

    // geometria de las barras de sonido
    private static final int SLX = 70, SLW = 470;
    private static final int Y_MUS = 190, Y_SFX = 320;

    public AjustesWorld()
    {
        super(GameData.ANCHO, GameData.ALTO, 1);
        Sonido.pararMotor();
        Sonido.musica("musica_menu.wav");
        mostrar(0);
    }

    private void mostrar(int v)
    {
        vista = v;
        removeObjects(getObjects(MenuButton.class));

        if (v == 0) {
            addObject(new MenuButton("CONTROLES", "controles", 300, 50), 400, 186);
            addObject(new MenuButton("SONIDO",    "sonido",    300, 50), 400, 248);
            addObject(new MenuButton("CREDITOS",  "creditos",  300, 50), 400, 310);
            addObject(new MenuButton("HISTORIA",  "historia",  300, 50), 400, 372);
            if (GameData.adminMenu)
                addObject(new MenuButton("MODO ADMIN", "admin", 300, 50), 400, 434);
            addObject(new MenuButton("VOLVER AL MENU", "menu", 300, 50), 400, 520);
        } else if (v == 4) {
            addObject(new MenuButton("NIVELES", "a_niveles", 360, 42), 400, 132);
            addObject(new MenuButton("DESBLOQUEO TODO:  " + onOff(GameData.adminTodo),        "a_todo", 360, 42), 400, 182);
            addObject(new MenuButton("INSTA KILL (tecla K):  " + onOff(GameData.adminInstakill), "a_kill", 360, 42), 400, 232);
            addObject(new MenuButton("NEXT LEVEL (tecla L):  " + onOff(GameData.adminNextLevel), "a_next", 360, 42), 400, 282);
            addObject(new MenuButton("MODO DIOS", "a_dios", 360, 42), 400, 332);
            addObject(new MenuButton("VER FINAL", "final", 360, 42), 400, 382);
            addObject(new MenuButton("VOLVER", "atras", 220, 46), 400, 456);
        } else {
            addObject(new MenuButton("VOLVER", "atras", 220, 50), 400, 520);
        }
        dibujar();
    }

    private static String onOff(boolean b) { return b ? "ON" : "off"; }

    public void act()
    {
        // barras de sonido arrastrables
        if (vista == 2) {
            MouseInfo m = Greenfoot.getMouseInfo();
            if (m != null && (Greenfoot.mousePressed(null) || Greenfoot.mouseDragged(null))) {
                int v = (int) Math.round((m.getX() - SLX) * 100.0 / SLW);
                v = Math.max(0, Math.min(100, v));
                if (Math.abs(m.getY() - Y_MUS) < 30) { Sonido.fijarMusica(v); dibujar(); }
                else if (Math.abs(m.getY() - Y_SFX) < 30) { Sonido.fijarEfectos(v); dibujar(); }
            }
        }

        MenuButton clic = null;
        for (Object o : getObjects(MenuButton.class)) {
            MenuButton b = (MenuButton) o;
            if (b.fueClickeado()) { clic = b; break; }
        }
        if (clic == null) return;

        switch (clic.accion) {
            case "controles": mostrar(1); break;
            case "sonido":    mostrar(2); break;
            case "creditos":  mostrar(3); break;
            case "historia":  Greenfoot.setWorld(new IntroComic()); break;
            case "final":     Greenfoot.setWorld(new FinalComic()); break;
            case "menu":      Greenfoot.setWorld(new MenuWorld()); break;
            case "atras":     mostrar(0); break;

            // ---- MODO ADMIN ----
            case "admin":     mostrar(4); break;
            case "a_niveles": Greenfoot.setWorld(new NivelesWorld()); break;
            case "a_dios":    Greenfoot.setWorld(new DiosWorld()); break;
            case "a_todo":    GameData.alternarTodo(); mostrar(4); break;
            case "a_kill":    GameData.adminInstakill = !GameData.adminInstakill; mostrar(4); break;
            case "a_next":    GameData.adminNextLevel = !GameData.adminNextLevel; mostrar(4); break;
        }
    }

    // ==================================================================
    private void dibujar()
    {
        GreenfootImage f = getBackground();
        f.setColor(new Color(16, 16, 24));
        f.fill();
        f.setColor(new Color(26, 24, 38));
        for (int y = 0; y < GameData.ALTO; y += 26) f.fillRect(0, y, GameData.ANCHO, 12);

        f.setColor(new Color(250, 205, 40));
        f.setFont(new Font("Monospaced", true, false, 40));
        String titulo = vista == 1 ? "CONTROLES" : vista == 2 ? "SONIDO"
                      : vista == 3 ? "CREDITOS" : vista == 4 ? "MODO ADMIN" : "AJUSTES";
        f.drawString(titulo, 60, 78);

        if (vista == 1)      dibujarControles(f);
        else if (vista == 2) dibujarSonido(f);
        else if (vista == 3) dibujarCreditos(f);
        else if (vista == 4) {
            f.setFont(new Font("Monospaced", false, false, 13));
            f.setColor(new Color(190, 190, 200));
            f.drawString("En juego: K mata al instante  -  L salta el nivel (x2 salta al jefe).", 60, 530);
            f.drawString("Con el modo admin, morir REINICIA el nivel (no vuelve al 1).", 60, 552);
        }
    }

    private void dibujarControles(GreenfootImage f)
    {
        String[][] filas = {
            { "FLECHAS  /  A D",   "Cambiar de carril" },
            { "FLECHA ARRIBA / W",  "Saltar por encima de autos y animales" },
            { "SPACE",              "Disparar (municion limitada, se recarga)" },
            { "X",                  "ULTI del auto (barra NITRO/ULTI llena)" },
            { "SHIFT",              "Nitro / turbo (gasta la barra de ULTI)" },
            { "P  /  ESC",          "Pausa" },
            { "M",                  "Silenciar / activar el sonido" },
            { "R",                  "Reiniciar el nivel (estando en pausa)" },
            { "Q",                  "Salir al menu (estando en pausa)" },
        };
        f.setFont(new Font("Monospaced", true, false, 16));
        int y = 140;
        for (String[] r : filas) {
            f.setColor(new Color(255, 220, 120));
            f.drawString(r[0], 60, y);
            f.setColor(Color.WHITE);
            f.drawString(r[1], 330, y);
            y += 40;
        }
    }

    private void dibujarSonido(GreenfootImage f)
    {
        slider(f, "MUSICA",  Sonido.volMusica,  Y_MUS);
        slider(f, "EFECTOS", Sonido.volEfectos, Y_SFX);

        f.setFont(new Font("Monospaced", false, false, 15));
        f.setColor(new Color(180, 180, 190));
        f.drawString("Arrastra las barras.   La tecla M silencia todo al instante.", 60, 430);
    }

    private void slider(GreenfootImage f, String etiqueta, int valor, int y)
    {
        f.setFont(new Font("Monospaced", true, false, 20));
        f.setColor(Color.WHITE);
        f.drawString(etiqueta + "   " + valor + "%", SLX, y - 22);

        f.setColor(new Color(255, 255, 255, 45));
        f.fillRect(SLX, y - 7, SLW, 14);
        f.setColor(new Color(120, 210, 255));
        f.fillRect(SLX, y - 7, (int) (SLW * valor / 100.0), 14);
        f.setColor(Color.BLACK);
        f.drawRect(SLX, y - 7, SLW, 14);

        // "pomo"
        int kx = SLX + (int) (SLW * valor / 100.0);
        f.setColor(new Color(250, 205, 40));
        f.fillRect(kx - 7, y - 16, 14, 32);
        f.setColor(Color.BLACK);
        f.drawRect(kx - 7, y - 16, 14, 32);
    }

    private void dibujarCreditos(GreenfootImage f)
    {
        f.setFont(new Font("Monospaced", true, false, 44));
        f.setColor(new Color(230, 60, 60));
        f.drawString("NIGHT REAPERS", 130, 200);
        f.drawString("STUDIO", 240, 252);

        f.setFont(new Font("Monospaced", true, false, 19));
        f.setColor(Color.WHITE);
        f.drawString("Diseno y programacion :  The_Trilex", 130, 320);
        f.drawString("Motor                 :  Greenfoot (Java)", 130, 352);
        f.drawString("Graficos y sonido     :  del estudio", 130, 384);

        f.setFont(new Font("Monospaced", false, false, 15));
        f.setColor(new Color(180, 180, 190));
        f.drawString("RETRO RUSH  -  " + GameData.NIVEL_MAX + " niveles  -  8 autos  -  roguelite", 130, 440);
        f.drawString(Muerte.total() + " formas de morir  -  " + Mejora.total() + " cartas", 130, 468);
    }
}
