import greenfoot.*;

/**
 * Final del juego, en vinetas. Se muestra al derribar al jefe de la torre.
 * Despues queda desbloqueado en AJUSTES > VER FINAL.
 *
 * CLICK / ESPACIO avanza.  ESC lo salta.
 */
public class FinalComic extends World
{
    private int panel = 0;

    private final CarType tipo = GameData.auto();
    private final String[][] textos;

    public FinalComic()
    {
        super(GameData.ANCHO, GameData.ALTO, 1);
        Sonido.pararMotor();
        Sonido.musica("musica_menu.wav");

        // el final se cuenta con la tripulacion y el auto con los que ganaste
        textos = new String[][] {
            { "La torre arde a tu espalda.",
              "El jefe de la Organizacion ya no",
              "manda sobre la Autopista 9." },
            { tipo.cond + " pisa a fondo.",
              tipo.copi + " cuenta el dinero del maletero",
              "y por primera vez se rie." },
            { "La frontera es una linea de luz",
              "al final del asfalto.",
              "Nadie los sigue." },
            { "Cambiaron de nombre. De cara.",
              "El " + tipo.nombre + " los llevo lejos.",
              "" },
            { "Pero cada tanto, de noche,",
              tipo.cond + " y " + tipo.copi + " vuelven",
              "a la Autopista 9.",
              "F I N" }
        };
        dibujar();
    }

    private GreenfootImage autoFinal()
    {
        return Sprites.autoTrasero(tipo.cuerpo, tipo.detalle, tipo.modelo);
    }

    public void act()
    {
        String k = Greenfoot.getKey();
        if ("escape".equals(k)) { salir(); return; }

        boolean avanzar = Greenfoot.mouseClicked(null)
                       || "space".equals(k) || "enter".equals(k);
        if (!avanzar) return;

        panel++;
        if (panel >= textos.length) { salir(); return; }
        Sonido.efecto("boton.wav");
        dibujar();
    }

    private void salir()
    {
        // si venias de terminar el juego, ve al resumen; si no, al menu
        if (GameData.completado) Greenfoot.setWorld(new ResultWorld());
        else                     Greenfoot.setWorld(new MenuWorld());
    }

    // ==================================================================
    private void dibujar()
    {
        GreenfootImage f = getBackground();
        int W = GameData.ANCHO, H = GameData.ALTO;
        f.setColor(new Color(8, 8, 12));
        f.fill();

        int ex = 34, ey = 30, ew = W - 68, eh = 336;
        switch (panel) {
            case 0:  escTorreArde(f, ex, ey, ew, eh); break;
            case 1:  escInterior(f, ex, ey, ew, eh);  break;
            case 2:  escFrontera(f, ex, ey, ew, eh);  break;
            case 3:  escGaraje(f, ex, ey, ew, eh);    break;
            default: escNoche(f, ex, ey, ew, eh);     break;
        }
        grano(f, ex, ey, ew, eh);

        f.setColor(new Color(238, 234, 224));
        f.drawRect(ex - 3, ey - 3, ew + 6, eh + 6);
        f.drawRect(ex - 6, ey - 6, ew + 12, eh + 12);

        f.setColor(new Color(238, 234, 224));
        f.fillRect(ex - 6, ey - 30, 168, 22);
        f.setColor(new Color(12, 12, 16));
        f.setFont(new Font("Monospaced", true, false, 14));
        f.drawString("FINAL  /  " + (panel + 1), ex + 4, ey - 13);

        int ty = ey + eh + 20;
        f.setColor(new Color(246, 242, 232));
        f.fillRect(ex - 6, ty, ew + 12, H - ty - 20);
        f.setColor(Color.BLACK);
        f.drawRect(ex - 6, ty, ew + 12, H - ty - 20);
        f.drawRect(ex - 4, ty + 2, ew + 8, H - ty - 24);

        String[] ls = textos[Math.min(panel, textos.length - 1)];
        f.setColor(new Color(18, 18, 22));
        for (int i = 0; i < ls.length; i++) {
            boolean fin = ls[i].startsWith("F ");
            f.setFont(new Font("Monospaced", true, false, fin ? 34 : 19));
            f.drawString(ls[i], ex + 16, ty + 30 + i * 24);
        }

        f.setFont(new Font("Monospaced", true, false, 12));
        f.setColor(new Color(120, 120, 120));
        f.drawString(panel + 1 >= textos.length ? "CLICK / ESPACIO  salir"
                                                : "CLICK / ESPACIO  continuar     .     ESC  saltar",
                     ex + 16, H - 30);
    }

    private void grano(GreenfootImage f, int x, int y, int w, int h)
    {
        f.setColor(new Color(0, 0, 0, 40));
        for (int i = 0; i < 90; i++)
            f.fillRect(x + Greenfoot.getRandomNumber(w), y + Greenfoot.getRandomNumber(h), 2, 2);
        f.setColor(new Color(0, 0, 0, 70));
        f.fillOval(x - 40, y - 40, 90, 90);
        f.fillOval(x + w - 50, y - 40, 90, 90);
        f.fillOval(x - 40, y + h - 50, 90, 90);
        f.fillOval(x + w - 50, y + h - 50, 90, 90);
    }

    private void cielo(GreenfootImage f, int x, int y, int w, int h, Color a, Color b)
    {
        for (int i = 0; i < h; i++)
            { f.setColor(Sprites.mezclar(a, b, i / (double) h)); f.fillRect(x, y + i, w, 1); }
    }

    private void escTorreArde(GreenfootImage f, int x, int y, int w, int h)
    {
        cielo(f, x, y, w, h, new Color(30, 6, 8), new Color(210, 90, 30));
        int tw = (int) (w * 0.5), th = h + 8;
        GreenfootImage t = Sprites.torreDiablo(tw, th);
        t.rotate(6);
        f.drawImage(t, x + w - tw - 20, y);
        // llamas
        f.setColor(new Color(255, 170, 50, 200));
        for (int i = 0; i < 20; i++) {
            int fx = x + w - tw - 10 + Greenfoot.getRandomNumber(tw);
            int fy = y + 40 + Greenfoot.getRandomNumber(h - 80);
            f.fillOval(fx, fy, 10, 16);
        }
        // el auto huyendo en primer plano (el que llevabas)
        GreenfootImage car = autoFinal();
        car.scale(150, 112);
        f.drawImage(car, x + 40, y + h - 128);
    }

    private void escInterior(GreenfootImage f, int x, int y, int w, int h)
    {
        cielo(f, x, y, w, h, new Color(20, 16, 34), new Color(120, 70, 40));
        f.setColor(new Color(28, 24, 30));
        f.fillPolygon(new int[]{ x + w / 2 - 12, x + w / 2 + 12, x + w / 2 + 240, x + w / 2 - 240 },
                      new int[]{ y + h / 2, y + h / 2, y + h, y + h }, 4);
        f.setColor(new Color(245, 222, 120));
        for (int i = 0; i < 6; i++) f.fillRect(x + w / 2 - 3, y + h / 2 + 10 + i * i * 4, 6, 14);
        GreenfootImage a = Sprites.persona(0, false, tipo.pelo1, tipo.melena1);
        GreenfootImage b = Sprites.persona(1, true,  tipo.pelo2, tipo.melena2);
        a.scale(70, 140); b.scale(70, 140);
        f.drawImage(a, x + w / 2 - 110, y + h - 158);
        f.drawImage(b, x + w / 2 + 40,  y + h - 158);
        // billetes
        f.setColor(new Color(120, 200, 120));
        for (int i = 0; i < 12; i++)
            f.fillRect(x + w / 2 - 10 + Greenfoot.getRandomNumber(80), y + 40 + Greenfoot.getRandomNumber(120), 14, 7);
    }

    private void escFrontera(GreenfootImage f, int x, int y, int w, int h)
    {
        cielo(f, x, y, w, h, new Color(20, 30, 60), new Color(255, 210, 130));
        f.setColor(new Color(255, 245, 210));
        f.fillRect(x, y + h - 60, w, 8);
        f.setColor(new Color(26, 24, 30));
        f.fillPolygon(new int[]{ x + w / 2 - 10, x + w / 2 + 10, x + w / 2 + 200, x + w / 2 - 200 },
                      new int[]{ y + h / 2 + 30, y + h / 2 + 30, y + h, y + h }, 4);
        GreenfootImage car = autoFinal();
        car.scale(110, 84);
        f.drawImage(car, x + w / 2 - 55, y + h - 96);
    }

    private void escGaraje(GreenfootImage f, int x, int y, int w, int h)
    {
        f.setColor(new Color(24, 24, 30));
        f.fillRect(x, y, w, h);
        f.setColor(new Color(38, 38, 48));
        for (int i = 0; i < w; i += 44) f.fillRect(x + i, y, 2, h);

        // autos viejos, en sombra a los costados
        int[] mod = { 3, 4 };
        for (int i = 0; i < 2; i++) {
            GreenfootImage c = Sprites.autoTrasero(new Color(60, 60, 70), new Color(40, 40, 48), mod[i]);
            c.scale(120, 90);
            f.drawImage(c, x + (i == 0 ? 20 : w - 140), y + h - 118);
        }
        // el auto con el que ganaste, al centro y bajo el foco
        f.setColor(new Color(255, 240, 200, 40));
        f.fillOval(x + w / 2 - 130, y + 20, 260, h - 20);
        GreenfootImage cur = autoFinal();
        cur.scale(190, 142);
        f.drawImage(cur, x + w / 2 - 95, y + h - 170);
    }

    private void escNoche(GreenfootImage f, int x, int y, int w, int h)
    {
        cielo(f, x, y, w, h, new Color(6, 6, 20), new Color(40, 20, 60));
        f.setColor(new Color(255, 255, 255, 150));
        for (int i = 0; i < 40; i++)
            f.fillOval(x + Greenfoot.getRandomNumber(w), y + Greenfoot.getRandomNumber(h - 80), 2, 2);
        f.setColor(new Color(26, 22, 28));
        f.fillPolygon(new int[]{ x + w / 2 - 10, x + w / 2 + 10, x + w / 2 + 220, x + w / 2 - 220 },
                      new int[]{ y + h / 2 + 30, y + h / 2 + 30, y + h, y + h }, 4);
        GreenfootImage car = autoFinal();
        car.scale(96, 72);
        f.drawImage(car, x + w / 2 - 48, y + h - 82);
    }
}
