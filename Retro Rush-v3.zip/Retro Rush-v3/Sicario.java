import greenfoot.*;

/**
 * Sicario de la Organizacion: un tipo de traje negro parado en la ruta que
 * te dispara. Aguanta un par de balazos. Si lo dejas llegar, te embiste.
 * Aparece de vez en cuando en los niveles y como escolta del SOLDADO / EL DON.
 */
public class Sicario extends Objeto3D
{
    private final int carril;
    private int vida = 2;
    private int timer = 45;
    private int flash = 0;
    private int frame = 0, animT = 0;
    private boolean contado = false;

    public Sicario(int carril)
    {
        this.carril = carril;
        x = Camara.centroCarril(carril);
        altura = 0;
        z = 17000 + Greenfoot.getRandomNumber(5000);
        inicializar(Sprites.sicario(0), 150, 360);
    }

    public void act()
    {
        RaceWorld w = (RaceWorld) getWorld();
        if (w == null || w.congelado()) return;

        z -= w.getVelocidad() * 0.85;          // se te viene encima

        PlayerCar j = w.getJugador();
        if (j != null && z < 15000 && z > 1400) {
            if (--timer <= 0) {
                timer = 55 + Greenfoot.getRandomNumber(45);
                w.addObject(new EnemyBullet(x, 210, z, j, 9), -500, -500);
            }
        }

        // te embiste si llega
        if (!contado && z < Camara.Z_JUGADOR) {
            contado = true;
            if (j != null && j.getCarril() == carril && !j.enElAire()) {
                j.recibirDano(14);
                w.addObject(new Explosion(x, 120, Camara.Z_JUGADOR, 320), -500, -500);
            }
        }
        if (z < 300 || z > 34000) { w.removeObject(this); return; }

        if (++animT >= 8) { animT = 0; frame = (frame + 1) % 2; setBase(Sprites.sicario(frame)); }

        if (flash > 0) flash--;
        proyectar();
        getImage().setTransparency((flash > 0 && flash % 4 < 2) ? 130 : 255);
    }

    public void recibirDano(int d)
    {
        vida -= d;
        flash = 6;
        RaceWorld w = (RaceWorld) getWorld();
        if (w == null) return;
        if (vida <= 0) {
            w.sumarPuntaje(240);
            w.addObject(new Explosion(x, 120, z, 260), -500, -500);
            w.removeObject(this);
        }
    }
}
