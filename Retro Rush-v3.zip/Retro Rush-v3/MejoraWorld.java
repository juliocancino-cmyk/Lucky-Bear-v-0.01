import greenfoot.*;

/**
 * Pantalla de mejora roguelite: entre niveles, elige 1 de 3 al azar.
 * Cada carta muestra su rareza, un icono, la probabilidad de haber salido,
 * y su efecto. CLICK en una tarjeta, o teclas 1 / 2 / 3.
 */
public class MejoraWorld extends World
{
    private final Mejora[] ops = pedir();
    private int hover = -1;

    private static Mejora[] pedir()
    {
        int min = GameData.cartaGarantizada;   // 0 normal, 1 rara+, 2 epica+
        GameData.cartaGarantizada = 0;
        return Mejora.tresAlAzar(min);
    }

    private static final int CARD_W = 240, CARD_H = 320, GAP = 18;
    private static final int Y0 = 150;

    public MejoraWorld()
    {
        super(GameData.ANCHO, GameData.ALTO, 1);
        Sonido.pararMotor();
        Sonido.musica("musica_menu.wav");
        dibujar();
    }

    public void act()
    {
        MouseInfo m = Greenfoot.getMouseInfo();
        int nh = -1;
        if (m != null)
            for (int i = 0; i < 3; i++) if (dentro(i, m.getX(), m.getY())) nh = i;
        if (nh != hover) { hover = nh; dibujar(); }

        int elegido = -1;
        if (Greenfoot.mouseClicked(null) && hover >= 0) elegido = hover;
        String k = Greenfoot.getKey();
        if ("1".equals(k)) elegido = 0;
        if ("2".equals(k)) elegido = 1;
        if ("3".equals(k)) elegido = 2;

        if (elegido >= 0 && ops[elegido] != null) {
            Mejora.aplicar(ops[elegido].id);
            Sonido.efecto("nivel.wav");
            Greenfoot.setWorld(new RaceWorld());
        }
    }

    private int cardX(int i) { return GameData.ANCHO / 2 - (CARD_W * 3 + GAP * 2) / 2 + i * (CARD_W + GAP); }

    private boolean dentro(int i, int mx, int my)
    {
        int x = cardX(i);
        return mx >= x && mx <= x + CARD_W && my >= Y0 && my <= Y0 + CARD_H;
    }

    // ==================================================================
    private void dibujar()
    {
        GreenfootImage f = getBackground();
        f.setColor(new Color(14, 14, 22));
        f.fill();
        f.setColor(new Color(24, 22, 36));
        for (int y = 0; y < GameData.ALTO; y += 26) f.fillRect(0, y, GameData.ANCHO, 12);

        f.setFont(new Font("Monospaced", true, false, 38));
        f.setColor(new Color(250, 205, 40));
        f.drawString("ELIGE UNA MEJORA", 60, 66);

        f.setFont(new Font("Monospaced", true, false, 15));
        f.setColor(Color.WHITE);
        f.drawString("Nivel " + GameData.nivelActual + "/" + GameData.NIVEL_MAX
                   + "     Mejoras activas: " + GameData.mejorasElegidas.size()
                   + "     Suerte x" + String.format("%.1f", 1.0 + GameData.suerteMult), 60, 96);
        f.setColor(new Color(150, 150, 160));
        f.drawString("Una carta ya elegida no vuelve a salir (menos las de SUERTE).", 60, 120);

        for (int i = 0; i < 3; i++) tarjeta(f, i);

        f.setFont(new Font("Monospaced", true, false, 14));
        f.setColor(new Color(150, 150, 160));
        f.drawString("CLICK  o  teclas  1 / 2 / 3", GameData.ANCHO / 2 - 120, GameData.ALTO - 24);
    }

    private void tarjeta(GreenfootImage f, int i)
    {
        Mejora m = ops[i];
        if (m == null) return;
        int x = cardX(i), y = Y0;
        boolean h = (i == hover);
        Color c = m.color();

        f.setColor(new Color(0, 0, 0, 150));
        f.fillRect(x + 6, y + 8, CARD_W, CARD_H);
        f.setColor(h ? new Color(44, 46, 62) : new Color(28, 28, 40));
        f.fillRect(x, y, CARD_W, CARD_H);
        f.setColor(c);
        f.drawRect(x, y, CARD_W, CARD_H);
        f.drawRect(x + 1, y + 1, CARD_W - 2, CARD_H - 2);
        if (h || m.rareza == Mejora.LEGENDARIA) f.drawRect(x + 3, y + 3, CARD_W - 6, CARD_H - 6);

        // banda de rareza
        f.setColor(c);
        f.fillRect(x, y, CARD_W, 28);
        f.setColor(new Color(15, 15, 20));
        f.setFont(new Font("Monospaced", true, false, 14));
        f.drawString(m.rarezaNombre() + (m.esSuerte ? "  repetible" : ""), x + 10, y + 20);

        // icono
        icono(f, x + CARD_W / 2, y + 96, 46, m.icono, c);

        // nombre (centrado a ojo)
        f.setColor(Color.WHITE);
        f.setFont(new Font("Monospaced", true, false, 20));
        f.drawString(recorta(m.nombre, 18), x + 12, y + 156);

        // numero grande de fondo
        f.setColor(new Color(255, 255, 255, 30));
        f.setFont(new Font("Monospaced", true, false, 64));
        f.drawString("" + (i + 1), x + CARD_W - 48, y + 60);

        // descripcion envuelta
        f.setFont(new Font("Monospaced", false, false, 14));
        f.setColor(new Color(222, 222, 230));
        int ly = y + 190;
        for (String linea : envolver(m.desc, 26)) {
            if (ly > y + CARD_H - 44) break;
            f.drawString(linea, x + 12, ly);
            ly += 20;
        }

        // probabilidad
        f.setFont(new Font("Monospaced", true, false, 12));
        f.setColor(new Color(150, 150, 160));
        double p = m.probabilidad();
        String ps = p >= 1 ? String.format("%.1f%%", p) : String.format("%.3f%%", p);
        f.drawString("prob. " + ps, x + 12, y + CARD_H - 14);
    }

    // ---- iconos procedurales por categoria ----
    private void icono(GreenfootImage f, int cx, int cy, int s, int tipo, Color c)
    {
        f.setColor(new Color(0, 0, 0, 90));
        f.fillOval(cx - s / 2 - 3, cy - s / 2 - 3, s + 6, s + 6);
        f.setColor(c);
        int r = s / 2;
        switch (tipo) {
            case Mejora.I_VEL:      // chevrones
                for (int i = 0; i < 3; i++) {
                    int o = -r + 6 + i * 10;
                    f.fillPolygon(new int[]{ cx + o - 4, cx + o + 8, cx + o - 4 },
                                  new int[]{ cy - r + 4, cy, cy + r - 4 }, 3);
                }
                break;
            case Mejora.I_ENE:      // escudo
                f.fillPolygon(new int[]{ cx - r + 3, cx + r - 3, cx + r - 3, cx, cx - r + 3 },
                              new int[]{ cy - r + 3, cy - r + 3, cy + 2, cy + r - 2, cy + 2 }, 5);
                f.setColor(new Color(15, 15, 20));
                f.fillPolygon(new int[]{ cx - r + 9, cx + r - 9, cx + r - 9, cx, cx - r + 9 },
                              new int[]{ cy - r + 8, cy - r + 8, cy, cy + r - 8, cy }, 5);
                break;
            case Mejora.I_ARMA:     // 3 balas
                for (int i = 0; i < 3; i++) f.fillRect(cx - r + 4 + i * 11, cy - 8, 7, 18);
                break;
            case Mejora.I_PTS:      // estrella
                estrella(f, cx, cy, r - 2);
                break;
            case Mejora.I_SUERTE:   // trebol
                f.fillOval(cx - 12, cy - 12, 13, 13);
                f.fillOval(cx - 1, cy - 12, 13, 13);
                f.fillOval(cx - 12, cy - 1, 13, 13);
                f.fillOval(cx - 1, cy - 1, 13, 13);
                f.fillRect(cx - 2, cy + 4, 4, r);
                break;
            case Mejora.I_ULTI:     // cohete
                f.fillPolygon(new int[]{ cx, cx + 8, cx - 8 }, new int[]{ cy - r + 2, cy, cy }, 3);
                f.fillRect(cx - 8, cy, 16, r - 4);
                f.setColor(new Color(255, 160, 60));
                f.fillPolygon(new int[]{ cx - 8, cx + 8, cx }, new int[]{ cy + r - 4, cy + r - 4, cy + r + 6 }, 3);
                break;
            case Mejora.I_SALTO:    // flecha arriba
                f.fillPolygon(new int[]{ cx, cx + r - 2, cx - r + 2 }, new int[]{ cy - r + 2, cy + 2, cy + 2 }, 3);
                f.fillRect(cx - 5, cy + 2, 10, r - 4);
                break;
            default:                // rombo (especial)
                f.fillPolygon(new int[]{ cx, cx + r - 2, cx, cx - r + 2 },
                              new int[]{ cy - r + 2, cy, cy + r - 2, cy }, 4);
        }
    }

    private void estrella(GreenfootImage f, int cx, int cy, int r)
    {
        int[] xs = new int[10], ys = new int[10];
        for (int i = 0; i < 10; i++) {
            double ang = Math.PI / 2 + i * Math.PI / 5;
            int rr = (i % 2 == 0) ? r : r / 2;
            xs[i] = cx + (int) (Math.cos(ang) * rr);
            ys[i] = cy - (int) (Math.sin(ang) * rr);
        }
        f.fillPolygon(xs, ys, 10);
    }

    private String recorta(String s, int max)
    {
        return s.length() <= max ? s : s.substring(0, max - 1) + ".";
    }

    private java.util.List<String> envolver(String s, int max)
    {
        java.util.List<String> out = new java.util.ArrayList<String>();
        String cur = "";
        for (String p : s.split(" ")) {
            if (!cur.isEmpty() && cur.length() + p.length() + 1 > max) { out.add(cur); cur = p; }
            else cur = cur.isEmpty() ? p : cur + " " + p;
        }
        if (!cur.isEmpty()) out.add(cur);
        return out;
    }
}
