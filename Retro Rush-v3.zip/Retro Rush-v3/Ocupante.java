import greenfoot.*;

/**
 * Un ocupante del auto en las cinematicas de derrota.
 *
 * modo:
 *   LLORA    - se sienta en el suelo y llora (no se mueve)
 *   ALEJARSE - camina hacia el borde, cabizbajo
 *   ESCOLTA  - camina hasta metaX (p.ej. la miniban de la mafia) y desaparece
 *   CRAWL    - sale a gatas, lento (vuelco)
 *
 * El aspecto (pelo / melena) lo pone quien lo crea. No se congela con el
 * mundo: la derrota necesita que siga animando.
 */
public class Ocupante extends Objeto3D
{
    public static final int LLORA = 0, ALEJARSE = 1, ESCOLTA = 2, CRAWL = 3;

    private final int modo;
    private final int dir;
    private final Color pelo;
    private final boolean melena;
    private double metaX;
    private int paso = 0;
    private int t = 0;
    private boolean llego = false;

    public Ocupante(double x, double z, int dir, Color pelo, boolean melena, int modo)
    {
        this.x = x;
        this.z = z;
        this.altura = 0;
        this.dir = dir;
        this.pelo = pelo;
        this.melena = melena;
        this.modo = modo;
        this.metaX = x;

        if (modo == LLORA) inicializar(Sprites.personaEnSuelo(0, dir < 0, pelo, melena), 150, 150);
        else               inicializar(Sprites.persona(0, dir < 0, pelo, melena), 130, 210);
    }

    public Ocupante conMeta(double mx) { this.metaX = mx; return this; }

    public void act()
    {
        RaceWorld w = (RaceWorld) getWorld();
        if (w == null) return;
        t++;

        if (modo == LLORA) {
            if (t % 11 == 0) { paso = (paso + 1) % 2; setBase(Sprites.personaEnSuelo(paso, dir < 0, pelo, melena)); }
            proyectar();
            return;
        }

        double vel = (modo == CRAWL) ? 2.2 : (modo == ESCOLTA ? 2.8 : 5.5);
        int animCada = (modo == CRAWL) ? 14 : 9;
        int demora = (modo == CRAWL) ? 30 : (modo == ESCOLTA ? 55 : 22);

        if (t > demora) {
            if (modo == ESCOLTA) {
                if (Math.abs(metaX - x) > vel) x += (metaX > x) ? vel : -vel;
                else llego = true;
            } else {
                x += dir * vel;
            }
        }

        if (t % animCada == 0 && !llego) { paso = (paso + 1) % 2; setBase(Sprites.persona(paso, dir < 0, pelo, melena)); }
        proyectar();

        if (llego) {
            int tr = Math.max(0, getImage().getTransparency() - 12);
            getImage().setTransparency(tr);
            if (tr <= 0) { w.removeObject(this); return; }
        }
        if (Math.abs(x) > Camara.SEMI_RUTA + 1700) w.removeObject(this);
    }
}
