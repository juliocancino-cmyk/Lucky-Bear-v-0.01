import greenfoot.*;

/**
 * Historia inicial en vinetas, estilo comic noir. Se muestra una vez al
 * arrancar (MenuWorld la lanza si GameData.introVista es false) y se puede
 * repetir desde el menu (boton HISTORIA).
 *
 * CLICK / ESPACIO avanza.  ESC la salta.
 *
 * Motivo visual recurrente: la TORRE de la Organizacion, que aparece lejana
 * al principio y enorme al final (es donde espera el jefe).
 */
public class IntroComic extends World
{
    private int panel = 0;
    private int t = 0;

    private final String[][] textos = {
        { "1984. La Autopista 9, de noche,",
          "es de RETRO RUSH: el circuito ilegal",
          "mas rapido del pais." },
        { "Marco y Lena robaron un auto",
          "para correr una noche.",
          "Era el auto de la Organizacion." },
        { "La Organizacion no perdona.",
          "Quiere su auto. Y a ellos dos",
          "los quiere en una zanja." },
        { GameData.NIVEL_MAX + " tramos hasta la frontera.",
          "Helicopteros, sicarios al volante,",
          "y un jefe esperando en su torre." },
        { "No hay frenos que valgan.",
          "Solo acelerar.",
          "",
          "RETRO  RUSH" }
    };

    public IntroComic()
    {
        super(GameData.ANCHO, GameData.ALTO, 1);
        Sonido.pararMotor();
        Sonido.musica("musica_menu.wav");
        dibujar();
    }

    public void act()
    {
        t++;
        String k = Greenfoot.getKey();
        if ("escape".equals(k)) { irAlMenu(); return; }

        boolean avanzar = Greenfoot.mouseClicked(null)
                       || "space".equals(k) || "enter".equals(k);
        if (!avanzar) return;

        panel++;
        if (panel >= textos.length) { irAlMenu(); return; }
        t = 0;
        Sonido.efecto("boton.wav");
        dibujar();
    }

    private void irAlMenu()
    {
        GameData.introVista = true;
        Greenfoot.setWorld(new MenuWorld());
    }

    // ==================================================================
    private void dibujar()
    {
        GreenfootImage f = getBackground();
        int W = GameData.ANCHO, H = GameData.ALTO;

        f.setColor(new Color(8, 8, 12));
        f.fill();

        // marco de la vineta (mas ancho que alto, centrado y ARRIBA)
        int ex = 34, ey = 30, ew = W - 68, eh = 336;

        switch (panel) {
            case 0:  escenaAutopista(f, ex, ey, ew, eh); break;
            case 1:  escenaGaraje(f, ex, ey, ew, eh);    break;
            case 2:  escenaTorre(f, ex, ey, ew, eh);     break;
            case 3:  escenaMapa(f, ex, ey, ew, eh);      break;
            default: escenaArranque(f, ex, ey, ew, eh);  break;
        }
        grano(f, ex, ey, ew, eh);

        // doble borde blanco
        f.setColor(new Color(238, 234, 224));
        f.drawRect(ex - 3, ey - 3, ew + 6, eh + 6);
        f.drawRect(ex - 6, ey - 6, ew + 12, eh + 12);

        // etiqueta de capitulo
        f.setColor(new Color(238, 234, 224));
        f.fillRect(ex - 6, ey - 30, 176, 22);
        f.setColor(new Color(12, 12, 16));
        f.setFont(new Font("Monospaced", true, false, 14));
        f.drawString("RETRO RUSH  /  " + (panel + 1), ex + 4, ey - 13);

        // globo de texto
        int ty = ey + eh + 20;
        f.setColor(new Color(246, 242, 232));
        f.fillRect(ex - 6, ty, ew + 12, H - ty - 20);
        f.setColor(Color.BLACK);
        f.drawRect(ex - 6, ty, ew + 12, H - ty - 20);
        f.drawRect(ex - 4, ty + 2, ew + 8, H - ty - 24);

        String[] ls = textos[Math.min(panel, textos.length - 1)];
        f.setColor(new Color(18, 18, 22));
        for (int i = 0; i < ls.length; i++) {
            boolean titulo = ls[i].startsWith("RETRO");
            f.setFont(new Font("Monospaced", true, false, titulo ? 30 : 19));
            f.drawString(ls[i], ex + 16, ty + 30 + i * 24);
        }

        // pie: pista de control
        f.setFont(new Font("Monospaced", true, false, 12));
        f.setColor(new Color(120, 120, 120));
        String pie = (panel + 1 >= textos.length)
                   ? "CLICK / ESPACIO  empezar"
                   : "CLICK / ESPACIO  continuar     .     ESC  saltar";
        f.drawString(pie, ex + 16, H - 30);
    }

    // ---- helpers ----------------------------------------------------
    private void cielo(GreenfootImage f, int x, int y, int w, int h, Color a, Color b)
    {
        for (int i = 0; i < h; i++)
            { f.setColor(Sprites.mezclar(a, b, i / (double) h)); f.fillRect(x, y + i, w, 1); }
    }

    private void grano(GreenfootImage f, int x, int y, int w, int h)
    {
        f.setColor(new Color(0, 0, 0, 40));
        for (int i = 0; i < 90; i++)
            f.fillRect(x + Greenfoot.getRandomNumber(w), y + Greenfoot.getRandomNumber(h), 2, 2);
        // vineteo en las esquinas
        f.setColor(new Color(0, 0, 0, 70));
        f.fillOval(x - 40, y - 40, 90, 90);
        f.fillOval(x + w - 50, y - 40, 90, 90);
        f.fillOval(x - 40, y + h - 50, 90, 90);
        f.fillOval(x + w - 50, y + h - 50, 90, 90);
    }

    /** La torre-diablo de la Organizacion. escala 0..1 = lejana..colosal. */
    private void torre(GreenfootImage f, int cx, int baseY, double escala)
    {
        int tw = (int) (44 + escala * 190);
        int th = (int) (110 + escala * 300);
        GreenfootImage t = Sprites.torreDiablo(tw, th);
        f.drawImage(t, cx - tw / 2, baseY - th);
    }

    private void escenaAutopista(GreenfootImage f, int x, int y, int w, int h)
    {
        cielo(f, x, y, w, h, new Color(30, 20, 58), new Color(235, 120, 66));
        f.setColor(new Color(255, 210, 120));
        f.fillOval(x + w - 150, y + h - 120, 96, 96);
        // torre lejanisima como silueta simple (no la cara de diablo, queda raro chico)
        f.setColor(new Color(24, 14, 20));
        f.fillRect(x + 70, y + h - 150, 26, 120);
        f.fillPolygon(new int[]{ x + 70, x + 83, x + 96 }, new int[]{ y + h - 150, y + h - 168, y + h - 150 }, 3);
        f.setColor(new Color(26, 22, 28));
        f.fillPolygon(new int[]{ x + w / 2 - 10, x + w / 2 + 10, x + w / 2 + 200, x + w / 2 - 200 },
                      new int[]{ y + h / 2 + 20, y + h / 2 + 20, y + h, y + h }, 4);
        f.setColor(new Color(245, 222, 120));
        for (int i = 0; i < 6; i++) f.fillRect(x + w / 2 - 3, y + h / 2 + 24 + i * i * 4, 6, 14);
        GreenfootImage car = Sprites.autoTrasero(new Color(200, 40, 40), new Color(240, 240, 240), 0);
        car.scale(120, 90);
        f.drawImage(car, x + w / 2 - 60, y + h - 104);
    }

    private void escenaGaraje(GreenfootImage f, int x, int y, int w, int h)
    {
        f.setColor(new Color(24, 24, 30));
        f.fillRect(x, y, w, h);
        f.setColor(new Color(38, 38, 48));
        for (int i = 0; i < w; i += 44) f.fillRect(x + i, y, 2, h);
        f.setColor(new Color(255, 220, 140, 55));
        f.fillOval(x + w / 2 - 120, y - 10, 240, 200);
        GreenfootImage car = Sprites.autoTrasero(new Color(200, 40, 40), new Color(240, 240, 240), 0);
        car.scale(190, 142);
        f.drawImage(car, x + w / 2 - 95, y + h - 168);
        GreenfootImage a = Sprites.persona(0, false, new Color(58, 42, 30), false);
        GreenfootImage b = Sprites.persona(0, true,  new Color(234, 200, 72), true);
        a.scale(66, 132); b.scale(66, 132);
        f.drawImage(a, x + w / 2 - 190, y + h - 150);
        f.drawImage(b, x + w / 2 + 124, y + h - 150);
    }

    private void escenaTorre(GreenfootImage f, int x, int y, int w, int h)
    {
        cielo(f, x, y, w, h, new Color(40, 4, 10), new Color(160, 26, 26));
        // rayo detras de la torre
        f.setColor(new Color(255, 230, 180, 180));
        f.drawLine(x + w / 2 + 60, y, x + w / 2 + 20, y + h / 2);
        f.drawLine(x + w / 2 + 20, y + h / 2, x + w / 2 + 70, y + h / 2 + 40);
        // la torre-diablo, enorme
        int tw = (int) (w * 0.7), th = h + 10;
        GreenfootImage t = Sprites.torreDiablo(tw, th);
        f.drawImage(t, x + w / 2 - tw / 2, y);
        // resplandor rojo en la base
        f.setColor(new Color(255, 60, 40, 90));
        f.fillOval(x + w / 2 - tw / 2, y + h - 40, tw, 70);
    }

    private void escenaMapa(GreenfootImage f, int x, int y, int w, int h)
    {
        f.setColor(new Color(32, 38, 32));
        f.fillRect(x, y, w, h);
        int px = x + 26, py = y + h - 34;
        int nn = GameData.NIVEL_MAX;
        for (int i = 1; i <= nn; i++) {
            int nx = x + 26 + (int) (i * (w - 90) / (double) nn);
            int ny = y + h - 34 - (int) (Math.abs(Math.sin(i * 0.6)) * (h * 0.5));
            f.setColor(new Color(210, 200, 170));
            f.drawLine(px, py, nx, ny);
            f.setColor(i % 10 == 0 ? new Color(255, 120, 90) : new Color(235, 210, 90));
            f.fillOval(nx - 3, ny - 3, 6, 6);
            px = nx; py = ny;
        }
        torre(f, px + 6, py + 4, 0.5);
        GreenfootImage heli = Sprites.helicoptero(HeliTipo.paraNivel(6));
        heli.scale(130, 66);
        f.drawImage(heli, x + 36, y + 22);
    }

    private void escenaArranque(GreenfootImage f, int x, int y, int w, int h)
    {
        cielo(f, x, y, w, h, new Color(18, 18, 40), new Color(78, 36, 96));
        f.setColor(new Color(255, 255, 255, 130));
        for (int i = 0; i < 26; i++)
            f.fillRect(x + Greenfoot.getRandomNumber(w), y + Greenfoot.getRandomNumber(h), 3, 46);
        f.setColor(new Color(120, 120, 130, 160));
        f.fillOval(x + w / 2 - 130, y + h - 92, 130, 74);
        f.fillOval(x + w / 2 + 6,   y + h - 98, 140, 78);
        GreenfootImage car = Sprites.autoTrasero(new Color(200, 40, 40), new Color(240, 240, 240), 0);
        car.scale(180, 134);
        f.drawImage(car, x + w / 2 - 90, y + h - 150);
    }
}
