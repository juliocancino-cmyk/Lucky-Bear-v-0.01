import greenfoot.*;

/**
 * Menu principal.
 *
 * Admin: CONTROL + Z + 4 a la vez activa (o desactiva) el MODO ADMIN.
 * Ya no aparecen botones sueltos: las opciones de admin (NIVELES,
 * DESBLOQUEAR TODO, INSTA KILL, NEXT LEVEL, MODO DIOS) salen dentro de
 * AJUSTES -> MODO ADMIN, que solo se ve con el modo activado.
 */
public class MenuWorld extends World
{
    private MenuButton jugar, challenge, garage, ranking, ajustes;
    private boolean comboPrev = false;

    public MenuWorld()
    {
        super(GameData.ANCHO, GameData.ALTO, 1);
        Sonido.pararMotor();
        Sonido.musica("musica_menu.wav");

        GameData.cargarRanking();
        GameData.cargarAdmin();

        jugar     = new MenuButton("JUGAR",     "jugar",     260, 50);
        challenge = new MenuButton("CHALLENGE", "challenge", 260, 50);
        garage    = new MenuButton("GARAGE",    "garage",    260, 50);
        ranking   = new MenuButton("RANKING",   "ranking",   260, 50);
        ajustes   = new MenuButton("AJUSTES",   "ajustes",   260, 50);

        addObject(jugar,     190, 336);
        addObject(challenge, 190, 392);
        addObject(garage,    190, 448);
        addObject(ranking,   190, 504);
        addObject(ajustes,   190, 560);

        dibujarFondo();
    }

    public void act()
    {
        if (!GameData.introVista) {
            GameData.introVista = true;
            Greenfoot.setWorld(new IntroComic());
            return;
        }

        boolean combo = comboAdmin();
        if (combo && !comboPrev) {
            if (GameData.adminMenu) { GameData.quitarAdmin(); Sonido.efecto("boton.wav"); }
            else                    { GameData.activarAdmin(); Sonido.efecto("nivel.wav"); }
            dibujarFondo();
        }
        comboPrev = combo;

        if (jugar.fueClickeado()) {
            GameData.nuevaPartida(false);
            Greenfoot.setWorld(new RaceWorld());
        } else if (challenge.fueClickeado()) {
            GameData.nuevaPartida(true);
            Greenfoot.setWorld(new RaceWorld());
        } else if (garage.fueClickeado()) {
            Greenfoot.setWorld(new GarageWorld());
        } else if (ranking.fueClickeado()) {
            Greenfoot.setWorld(new RankingWorld());
        } else if (ajustes.fueClickeado()) {
            Greenfoot.setWorld(new AjustesWorld());
        }

        String t = Greenfoot.getKey();
        if ("enter".equals(t)) {
            GameData.nuevaPartida(false);
            Greenfoot.setWorld(new RaceWorld());
        }
    }

    /** CONTROL + Z + 4 (mayus/minus da igual). ALT/SHIFT valen de respaldo. */
    static boolean comboAdmin()
    {
        if (!teclaAbajo("z") || !teclaAbajo("4")) return false;
        return teclaAbajo("control") || teclaAbajo("ctrl")
            || teclaAbajo("alt") || teclaAbajo("shift");
    }

    private static boolean teclaAbajo(String k)
    {
        try { return Greenfoot.isKeyDown(k); }
        catch (Exception e) { return false; }
    }

    // ==================================================================
    private void dibujarFondo()
    {
        GreenfootImage f = getBackground();
        Palette p = Palette.get(3);   // atardecer

        f.setColor(p.cieloAlto);
        f.fillRect(0, 0, GameData.ANCHO, 200);
        f.setColor(p.cieloBajo);
        f.fillRect(0, 200, GameData.ANCHO, 130);
        f.setColor(p.suelo);
        f.fillRect(0, 330, GameData.ANCHO, GameData.ALTO - 330);

        // sol retro con bandas
        f.setColor(new Color(255, 200, 70));
        f.fillOval(560, 90, 180, 180);
        f.setColor(p.cieloBajo);
        for (int y = 190; y < 270; y += 14) f.fillRect(555, y, 190, 7);

        GreenfootImage auto = GameData.auto().imagen();
        auto.scale(300, 225);
        f.drawImage(auto, 520, 330);

        // panel oscuro (cubre titulo-abajo, texto y botones)
        int px = 30, pw = 460;
        f.setColor(new Color(10, 8, 16, 214));
        f.fillRect(px, 150, pw, GameData.ALTO - 150);
        f.setColor(new Color(255, 190, 70));
        f.fillRect(px, 150, pw, 4);

        f.setFont(new Font("Monospaced", true, false, 60));
        f.setColor(new Color(0, 0, 0, 170));
        f.drawString("RETRO RUSH", 46, 120);
        f.setColor(new Color(255, 205, 40));
        f.drawString("RETRO RUSH", 42, 116);

        f.setFont(new Font("Monospaced", true, false, 15));
        f.setColor(new Color(255, 235, 190));
        f.drawString("Carreras arcade  -  " + GameData.NIVEL_MAX + " niveles y jefe final", 46, 182);

        f.setFont(new Font("Monospaced", true, false, 14));
        f.setColor(new Color(120, 210, 255));
        f.drawString("AUTO: " + GameData.auto().nombre, 46, 214);
        f.setColor(new Color(255, 220, 120));
        f.drawString("PUNTOS TOTALES: " + GameData.puntajeTotal, 46, 240);

        f.setFont(new Font("Monospaced", false, false, 12));
        f.setColor(new Color(255, 175, 125));
        f.drawString("CHALLENGE: infinito, 1 vida, mas dificil cada vuelta", 46, 266);

        if (GameData.adminMenu) {
            f.setFont(new Font("Monospaced", true, false, 12));
            f.setColor(new Color(120, 255, 160));
            String s = "MODO ADMIN";
            if (GameData.adminTodo)  s += "  todo";
            if (GameData.modoDios()) s += "  DIOS";
            f.drawString(s, 46, 292);
        }
    }
}
