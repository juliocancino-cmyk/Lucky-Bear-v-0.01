import greenfoot.*;

/**
 * Vehiculo de la Organizacion que aparece en las cinematicas de derrota.
 *
 *   VAN   - miniban negra: llega desde atras, para junto al auto y se va.
 *           (la copiloto secuestrada camina hacia ella; la crea PlayerCar)
 *   TRUCK - camioneta: pasa de largo disparandole al auto siniestrado.
 *
 * No se congela con el mundo.
 */
public class MafiaVehiculo extends Objeto3D
{
    public static final int VAN = 0, TRUCK = 1;

    private final int tipo;
    private final double xObjetivo;
    private final double zParada;
    private int fase = 0;      // 0 llega, 1 espera, 2 se va
    private int espera = 0;
    private int t = 0;

    public MafiaVehiculo(int tipo, double x, double zParada)
    {
        this.tipo = tipo;
        this.xObjetivo = x;
        this.zParada = zParada;
        this.x = x;
        // VAN llega de frente (desde la ruta) y para; TRUCK viene por detras y adelanta
        this.z = (tipo == VAN) ? 4600 : 150;
        this.altura = 0;
        GreenfootImage sp = (tipo == VAN) ? Sprites.minivan(new Color(18, 18, 20))
                                          : Sprites.camioneta(new Color(26, 24, 22));
        inicializar(sp, tipo == VAN ? 460 : 440, tipo == VAN ? 380 : 300);
    }

    public void act()
    {
        RaceWorld w = (RaceWorld) getWorld();
        if (w == null) return;
        t++;

        if (tipo == TRUCK) {
            z += 90;                                   // pasa de largo, siempre
            if (t % 12 == 0 && z > 400 && z < 1500) {  // rafaga contra el auto
                Sonido.efecto("disparo.wav");
                w.addObject(new Explosion(xObjetivo + Greenfoot.getRandomNumber(200) - 100,
                                          130, Camara.Z_JUGADOR + 120, 360), -500, -500);
            }
            if (z > 16000) { w.removeObject(this); return; }
            proyectar();
            return;
        }

        // VAN: se acerca de frente, para al lado, espera y se va hacia adelante
        if (fase == 0) {
            z += (zParada - z) * 0.09;
            if (Math.abs(z - zParada) < 40) { fase = 1; espera = 170; }
        } else if (fase == 1) {
            if (--espera <= 0) fase = 2;
        } else {
            z += 150;                        // acelera hacia adelante y se pierde
            if (z > 16000) { w.removeObject(this); return; }
        }
        proyectar();
    }

    /** x donde para la van, para que la copiloto camine hacia alli. */
    public double getXParada() { return xObjetivo; }
}
