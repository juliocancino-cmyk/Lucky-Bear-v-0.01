import greenfoot.*;

/**
 * Cualquier cosa que cae del cielo hacia un punto y revienta al impactar:
 * meteoritos, pianos, cajas fuertes, yunques, camiones, rocas, etc.
 * Se usa en las cinematicas de muerte. No se congela con el mundo.
 */
public class CosaCae extends Objeto3D
{
    private final double xImp, zImp, radio;
    private double vy;

    public CosaCae(GreenfootImage sp, double xImp, double zImp, double w, double h, double radio)
    {
        this.xImp = xImp;
        this.zImp = zImp;
        this.radio = radio;
        this.x = xImp + Greenfoot.getRandomNumber(500) - 250;
        this.z = zImp + 1400;
        this.altura = 6200;
        this.vy = 50;
        inicializar(sp, w, h);
    }

    public void act()
    {
        RaceWorld w = (RaceWorld) getWorld();
        if (w == null) return;

        altura -= vy;
        vy += 4.6;
        x += (xImp - x) * 0.09;
        z += (zImp - z) * 0.09;

        if (altura <= 90) {
            int n = radio > 1200 ? 5 : 3;
            for (int i = 0; i < n; i++)
                w.addObject(new Explosion(xImp + Greenfoot.getRandomNumber(800) - 400, 150,
                                          zImp + Greenfoot.getRandomNumber(600) - 300, radio), -500, -500);
            Camara.sacudir(radio > 1200 ? 36 : 22);
            Sonido.efecto("explosion.wav");
            w.removeObject(this);
            return;
        }
        proyectar();
    }
}
