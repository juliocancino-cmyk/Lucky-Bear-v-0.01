import greenfoot.*;

/**
 * Menu del MODO DIOS (admin). Cada opcion se activa por separado para
 * probar combinaciones y ver como se comportan los sistemas.
 *
 *   VIDA INFINITA   - no recibes dano
 *   BALAS INFINITAS - cargador lleno siempre, sin recarga
 *   DAÑO FUERTE     - cada bala hace 55 (EL DON cae en ~10 tiros, no en 1)
 *   TURBO INFINITO  - el nitro no se gasta
 *   INMUNE A EFECTOS - los choques y golpes NO te frenan
 *   ULTI INFINITA   - la barra de ULTI siempre esta llena
 */
public class DiosWorld extends World
{
    private MenuButton bVida, bBalas, bDano, bTurbo, bInmune, bUlti, bVolver;
    private final boolean desdePartida;

    public DiosWorld() { this(false); }

    public DiosWorld(boolean desdePartida)
    {
        super(GameData.ANCHO, GameData.ALTO, 1);
        this.desdePartida = desdePartida;
        Sonido.pararMotor();
        Sonido.musica("musica_menu.wav");

        bVida   = new MenuButton("", "vida",   360, 46);
        bBalas  = new MenuButton("", "balas",  360, 46);
        bDano   = new MenuButton("", "dano",   360, 46);
        bTurbo  = new MenuButton("", "turbo",  360, 46);
        bInmune = new MenuButton("", "inmune", 360, 46);
        bUlti   = new MenuButton("", "ulti",   360, 46);
        bVolver = new MenuButton("VOLVER", "volver", 220, 48);

        addObject(bVida,   400, 168);
        addObject(bBalas,  400, 222);
        addObject(bDano,   400, 276);
        addObject(bTurbo,  400, 330);
        addObject(bInmune, 400, 384);
        addObject(bUlti,   400, 438);
        addObject(bVolver, 400, 520);

        refrescar();
        dibujar();
    }

    private void refrescar()
    {
        bVida.setTexto("VIDA INFINITA:    " + (GameData.diosVida   ? "ON" : "off"));
        bBalas.setTexto("BALAS INFINITAS:  " + (GameData.diosBalas  ? "ON" : "off"));
        bDano.setTexto("DANO FUERTE:      " + (GameData.diosDano    ? "ON" : "off"));
        bTurbo.setTexto("TURBO INFINITO:   " + (GameData.diosTurbo  ? "ON" : "off"));
        bInmune.setTexto("INMUNE A EFECTOS: " + (GameData.diosInmune ? "ON" : "off"));
        bUlti.setTexto("ULTI INFINITA:    " + (GameData.diosUlti    ? "ON" : "off"));
    }

    public void act()
    {
        boolean cambio = true;
        if (bVida.fueClickeado())        GameData.diosVida   = !GameData.diosVida;
        else if (bBalas.fueClickeado())  GameData.diosBalas  = !GameData.diosBalas;
        else if (bDano.fueClickeado())   GameData.diosDano   = !GameData.diosDano;
        else if (bTurbo.fueClickeado())  GameData.diosTurbo  = !GameData.diosTurbo;
        else if (bInmune.fueClickeado()) GameData.diosInmune = !GameData.diosInmune;
        else if (bUlti.fueClickeado())   GameData.diosUlti   = !GameData.diosUlti;
        else if (bVolver.fueClickeado()) { volver(); return; }
        else cambio = false;

        if (cambio) { Sonido.efecto("boton.wav"); refrescar(); dibujar(); }
        if ("escape".equals(Greenfoot.getKey())) volver();
    }

    private void volver()
    {
        // si veniamos de la pausa, reiniciamos el nivel con lo que se cambio
        if (desdePartida) Greenfoot.setWorld(new RaceWorld());
        else              Greenfoot.setWorld(new AjustesWorld());
    }

    private void dibujar()
    {
        GreenfootImage f = getBackground();
        f.setColor(new Color(14, 14, 22));
        f.fill();
        f.setColor(new Color(26, 24, 38));
        for (int y = 0; y < GameData.ALTO; y += 26) f.fillRect(0, y, GameData.ANCHO, 12);

        f.setFont(new Font("Monospaced", true, false, 38));
        f.setColor(new Color(120, 255, 160));
        f.drawString("MODO DIOS", 60, 78);

        f.setFont(new Font("Monospaced", true, false, 13));
        f.setColor(Color.WHITE);
        f.drawString("Activa lo que quieras para probar combinaciones.", 60, 110);
        f.setColor(new Color(160, 160, 170));
        f.drawString("DANO FUERTE = 55 por bala (EL DON aguanta ~10 tiros).", 60, 130);

        f.setFont(new Font("Monospaced", true, false, 12));
        f.setColor(new Color(150, 150, 160));
        f.drawString("Se apaga solo al salir del modo admin.", 60, GameData.ALTO - 26);
    }
}
