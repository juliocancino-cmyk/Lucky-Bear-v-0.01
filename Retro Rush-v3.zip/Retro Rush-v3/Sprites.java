import greenfoot.*;

/**
 * Todos los sprites dibujados por codigo, ahora en VISTA TRASERA
 * (los vemos desde atras, como en Out Run).
 */
public class Sprites
{
    /**
     * Auto visto desde atras. Base 200x150; despues la camara lo escala.
     * Las cabezas de los personajes las dibuja aparte la clase Pilotos, que
     * espera una ventana trasera por la zona x 55..150, y 20..55: todos los
     * modelos la respetan.
     *
     * Cada modelo (ver CarType.M_*) tiene su propia silueta: no es un
     * recoloreo.
     */
    public static GreenfootImage autoTrasero(Color cuerpo, Color detalle)
    {
        return autoTrasero(cuerpo, detalle, 0);
    }

    public static GreenfootImage autoTrasero(Color cuerpo, Color detalle, int modelo)
    {
        GreenfootImage img = new GreenfootImage(200, 150);
        switch (modelo) {
            case 1:  autoGT(img, cuerpo, detalle);       break;
            case 2:  autoDrift(img, cuerpo, detalle);    break;
            case 3:  autoPatrulla(img, cuerpo, detalle); break;
            case 4:  autoProto(img, cuerpo, detalle);    break;
            case 5:  autoRally(img, cuerpo, detalle);    break;
            case 6:  autoSuper(img, cuerpo, detalle);    break;
            case 7:  autoDerrapa(img, cuerpo, detalle);  break;
            default: autoClasico(img, cuerpo, detalle);  break;
        }
        return img;
    }

    /** Auto rival visto DE FRENTE (viene en contramano en los puentes). Base 200x150. */
    public static GreenfootImage rivalFrente(Color c)
    {
        GreenfootImage img = new GreenfootImage(200, 150);
        Color o = mezclar(c, Color.BLACK, 0.5);
        sombra(img, 200);
        rueda(img, 4, 92, 30, 44); rueda(img, 166, 92, 30, 44);
        img.setColor(c);   img.fillRect(26, 38, 148, 86);          // carroceria
        img.setColor(o);   img.fillRect(20, 104, 160, 18);         // paragolpes
        img.setColor(new Color(38, 44, 58)); img.fillRect(44, 28, 112, 34);   // parabrisas
        img.setColor(new Color(20, 22, 30)); img.fillRect(52, 34, 96, 22);
        img.setColor(new Color(255, 250, 210));                    // faros
        img.fillRect(30, 92, 30, 18); img.fillRect(140, 92, 30, 18);
        img.setColor(new Color(255, 240, 170, 130));               // halo de faros
        img.fillOval(22, 86, 46, 30); img.fillOval(132, 86, 46, 30);
        img.setColor(new Color(70, 72, 82)); img.fillRect(74, 98, 52, 12);    // parrilla
        return img;
    }

    /** Auto rival: coche comun, sin pilotos asomados. */
    public static GreenfootImage rival(Color c)
    {
        GreenfootImage img = new GreenfootImage(200, 150);
        // los rivales alternan entre el clasico y el GT segun el color
        if ((c.getRed() + c.getGreen() + c.getBlue()) % 2 == 0)
            autoClasico(img, c, mezclar(c, Color.BLACK, 0.5));
        else
            autoGT(img, c, mezclar(c, Color.BLACK, 0.5));
        return img;
    }

    // ---- piezas comunes -------------------------------------------------
    private static void sombra(GreenfootImage img, int W)
    {
        img.setColor(new Color(0, 0, 0, 90));
        img.fillOval(6, 128, W - 12, 20);
    }

    private static void rueda(GreenfootImage img, int x, int y, int w, int h)
    {
        img.setColor(new Color(20, 20, 24));
        img.fillRect(x, y, w, h);
        img.setColor(new Color(92, 94, 102));
        img.fillRect(x + w / 5, y + h / 3, w * 3 / 5, h / 3);
    }

    // ==================================================================
    // MODELO 0 - CLASICO 84 : muscle car ochentero, cuadrado, paragolpes
    //            cromado y dos pilotos redondos.
    // ==================================================================
    private static void autoClasico(GreenfootImage img, Color cuerpo, Color detalle)
    {
        int W = 200;
        Color oscuro = mezclar(cuerpo, Color.BLACK, 0.45);
        sombra(img, W);

        rueda(img, 2, 92, 30, 46);
        rueda(img, W - 32, 92, 30, 46);

        // cabina alta y cuadrada
        img.setColor(cuerpo);
        img.fillRect(40, 28, W - 80, 52);
        img.setColor(new Color(35, 45, 70));
        img.fillRect(50, 34, W - 100, 36);
        img.setColor(new Color(90, 130, 180, 120));
        img.fillRect(50, 34, W - 100, 12);

        // aleron fino
        img.setColor(detalle);
        img.fillRect(24, 74, W - 48, 10);
        img.setColor(oscuro);
        img.fillRect(34, 80, 10, 12);
        img.fillRect(W - 44, 80, 10, 12);

        // carroceria trasera maciza
        img.setColor(cuerpo);
        img.fillRect(14, 86, W - 28, 44);
        img.setColor(oscuro);
        img.fillRect(14, 116, W - 28, 16);

        // paragolpes cromado
        img.setColor(new Color(205, 208, 214));
        img.fillRect(10, 126, W - 20, 9);

        // pilotos redondos
        img.setColor(new Color(235, 60, 60));
        img.fillOval(26, 94, 26, 22);
        img.fillOval(W - 52, 94, 26, 22);
        img.setColor(new Color(255, 170, 170));
        img.fillOval(31, 98, 12, 10);
        img.fillOval(W - 47, 98, 12, 10);

        img.setColor(new Color(240, 240, 235));
        img.fillRect(84, 108, 34, 15);
        img.setColor(Color.BLACK);
        img.drawRect(84, 108, 34, 15);
        img.drawRect(14, 86, W - 29, 44);
        img.drawRect(40, 28, W - 81, 52);
    }

    // ==================================================================
    // MODELO 1 - TURBO GT : cuna baja y ancha, aleron alto con soportes,
    //            4 pilotos redondos y doble escape con calor.
    // ==================================================================
    private static void autoGT(GreenfootImage img, Color cuerpo, Color detalle)
    {
        int W = 200;
        Color oscuro = mezclar(cuerpo, Color.BLACK, 0.5);
        sombra(img, W);

        rueda(img, 0, 96, 34, 44);
        rueda(img, W - 34, 96, 34, 44);

        // techo bajo y corto
        img.setColor(cuerpo);
        img.fillRect(52, 40, W - 104, 40);
        img.setColor(new Color(30, 38, 60));
        img.fillRect(60, 45, W - 120, 28);
        img.setColor(new Color(120, 150, 200, 110));
        img.fillRect(60, 45, W - 120, 9);

        // cuerpo ancho y chato
        img.setColor(cuerpo);
        img.fillRect(10, 92, W - 20, 34);
        img.setColor(oscuro);
        img.fillRect(10, 116, W - 20, 12);

        // aleron GT alto sobre dos soportes
        img.setColor(oscuro);
        img.fillRect(40, 66, 10, 24);
        img.fillRect(W - 50, 66, 10, 24);
        img.setColor(detalle);
        img.fillRect(20, 58, W - 40, 10);

        // 4 pilotos
        img.setColor(new Color(240, 70, 70));
        img.fillOval(20, 96, 20, 16);
        img.fillOval(44, 96, 20, 16);
        img.fillOval(W - 64, 96, 20, 16);
        img.fillOval(W - 40, 96, 20, 16);

        // doble escape con brillo de calor
        img.setColor(new Color(60, 60, 66));
        img.fillRect(78, 124, 16, 10);
        img.fillRect(W - 94, 124, 16, 10);
        img.setColor(new Color(255, 140, 60, 180));
        img.fillOval(80, 126, 12, 8);
        img.fillOval(W - 92, 126, 12, 8);

        img.setColor(Color.BLACK);
        img.drawRect(10, 92, W - 21, 34);
        img.drawRect(52, 40, W - 105, 40);
    }

    // ==================================================================
    // MODELO 2 - DRIFT KING : tuner de carroceria ancha, guardabarros
    //            abultados, aleron enorme y barra de luz LED atras.
    // ==================================================================
    private static void autoDrift(GreenfootImage img, Color cuerpo, Color detalle)
    {
        int W = 200;
        Color oscuro = mezclar(cuerpo, Color.BLACK, 0.4);
        sombra(img, W);

        rueda(img, 0, 92, 30, 48);
        rueda(img, W - 30, 92, 30, 48);

        // guardabarros abultados (sobresalen del cuerpo)
        img.setColor(oscuro);
        img.fillOval(-6, 84, 46, 46);
        img.fillOval(W - 40, 84, 46, 46);

        // techo hatchback inclinado
        img.setColor(cuerpo);
        img.fillPolygon(new int[]{48, W - 48, W - 58, 58}, new int[]{34, 34, 78, 78}, 4);
        img.setColor(new Color(28, 36, 54));
        img.fillPolygon(new int[]{58, W - 58, W - 64, 64}, new int[]{40, 40, 70, 70}, 4);
        img.setColor(new Color(120, 150, 200, 110));
        img.fillRect(64, 40, W - 128, 8);

        // cuerpo ancho
        img.setColor(cuerpo);
        img.fillRect(8, 92, W - 16, 34);
        img.setColor(oscuro);
        img.fillRect(8, 116, W - 16, 12);

        // aleron GT gigante sobre torres altas
        img.setColor(new Color(40, 40, 44));
        img.fillRect(34, 54, 12, 34);
        img.fillRect(W - 46, 54, 12, 34);
        img.setColor(detalle);
        img.fillRect(12, 44, W - 24, 12);
        img.setColor(mezclar(detalle, Color.WHITE, 0.3));
        img.fillRect(12, 44, W - 24, 4);

        // barra de luz LED continua
        img.setColor(new Color(60, 20, 20));
        img.fillRect(20, 100, W - 40, 12);
        img.setColor(new Color(255, 70, 70));
        for (int i = 0; i < (W - 40) / 10; i++) img.fillRect(22 + i * 10, 102, 6, 8);

        // splitter delantero (abajo)
        img.setColor(new Color(35, 35, 38));
        img.fillRect(4, 126, W - 8, 8);

        img.setColor(Color.BLACK);
        img.drawRect(8, 92, W - 17, 34);
    }

    // ==================================================================
    // MODELO 3 - PATRULLA X : interceptor policial, barra de luces en el
    //            techo, paragolpes de embestida y antena.
    // ==================================================================
    private static void autoPatrulla(GreenfootImage img, Color cuerpo, Color detalle)
    {
        int W = 200;
        Color oscuro = mezclar(cuerpo, Color.BLACK, 0.45);
        sombra(img, W);

        rueda(img, 2, 92, 30, 46);
        rueda(img, W - 32, 92, 30, 46);

        // cabina de sedan
        img.setColor(cuerpo);
        img.fillRect(42, 30, W - 84, 50);
        img.setColor(new Color(34, 42, 66));
        img.fillRect(52, 36, W - 104, 34);
        img.setColor(new Color(120, 150, 200, 110));
        img.fillRect(52, 36, W - 104, 11);

        // barra de luces en el techo (segmentos azul / rojo)
        img.setColor(new Color(30, 30, 34));
        img.fillRect(66, 20, W - 132, 12);
        img.setColor(new Color(60, 90, 255));
        img.fillRect(70, 22, (W - 140) / 2 - 2, 8);
        img.setColor(new Color(255, 60, 60));
        img.fillRect(70 + (W - 140) / 2 + 2, 22, (W - 140) / 2 - 2, 8);

        // antena
        img.setColor(new Color(20, 20, 22));
        img.fillRect(60, 8, 3, 16);

        // maletero plano (sin aleron)
        img.setColor(cuerpo);
        img.fillRect(14, 84, W - 28, 46);
        img.setColor(oscuro);
        img.fillRect(14, 116, W - 28, 14);

        // franja reflectante
        img.setColor(new Color(235, 235, 240));
        img.fillRect(14, 100, W - 28, 8);

        // pilotos
        img.setColor(new Color(235, 60, 60));
        img.fillRect(24, 90, 40, 14);
        img.fillRect(W - 64, 90, 40, 14);

        // paragolpes de embestida (push bar)
        img.setColor(new Color(180, 184, 190));
        img.fillRect(8, 122, W - 16, 6);
        img.fillRect(40, 118, 8, 14);
        img.fillRect(W - 48, 118, 8, 14);

        img.setColor(Color.BLACK);
        img.drawRect(14, 84, W - 29, 46);
        img.drawRect(42, 30, W - 85, 50);
    }

    // ==================================================================
    // MODELO 4 - PROTOTIPO Z : carroceria de gota, cupula redonda, motor
    //            trasero brillante y aletas de difusor. Sin ruedas a la
    //            vista (faldones), con resplandor de suspension.
    // ==================================================================
    private static void autoProto(GreenfootImage img, Color cuerpo, Color detalle)
    {
        int W = 200;
        Color oscuro = mezclar(cuerpo, Color.BLACK, 0.5);
        Color claro  = mezclar(cuerpo, Color.WHITE, 0.15);

        // resplandor bajo el chasis (antigravedad)
        img.setColor(new Color(detalle.getRed(), detalle.getGreen(), detalle.getBlue(), 90));
        img.fillOval(20, 120, W - 40, 24);

        // cuerpo en forma de gota
        img.setColor(cuerpo);
        img.fillOval(6, 70, W - 12, 62);
        img.setColor(claro);
        img.fillOval(6, 70, W - 12, 20);
        img.setColor(oscuro);
        img.fillOval(6, 108, W - 12, 24);

        // faldones laterales (tapan las ruedas)
        img.setColor(oscuro);
        img.fillRect(2, 104, 26, 26);
        img.fillRect(W - 28, 104, 26, 26);

        // cupula redonda tintada
        img.setColor(new Color(40, 55, 80));
        img.fillOval(58, 26, W - 116, 52);
        img.setColor(new Color(140, 180, 230, 120));
        img.fillOval(64, 30, W - 128, 20);

        // aletas de difusor
        img.setColor(detalle);
        img.fillPolygon(new int[]{18, 30, 30}, new int[]{130, 108, 130}, 3);
        img.fillPolygon(new int[]{W - 18, W - 30, W - 30}, new int[]{130, 108, 130}, 3);

        // barra de motor trasera brillante
        img.setColor(mezclar(detalle, Color.WHITE, 0.4));
        img.fillRect(46, 96, W - 92, 12);
        img.setColor(detalle);
        img.fillRect(42, 92, W - 84, 6);

        // linea LED trasera fina
        img.setColor(new Color(255, 120, 120));
        img.fillRect(40, 112, W - 80, 4);
    }

    // ==================================================================
    // MODELO 5 - RALLY RS : alto, ruedas tacos, guardabarros de plastico,
    //            snorkel en el techo, rueda de auxilio y faro de techo.
    // ==================================================================
    private static void autoRally(GreenfootImage img, Color cuerpo, Color detalle)
    {
        int W = 200;
        Color oscuro = mezclar(cuerpo, Color.BLACK, 0.4);
        sombra(img, W);

        // ruedas grandes de taco
        img.setColor(new Color(18, 18, 20));
        img.fillRect(-2, 86, 36, 52);
        img.fillRect(W - 34, 86, 36, 52);
        img.setColor(new Color(70, 72, 78));
        img.fillOval(2, 98, 24, 24);
        img.fillOval(W - 26, 98, 24, 24);

        // guardabarros de plastico negro
        img.setColor(new Color(28, 28, 30));
        img.fillRect(-4, 84, 42, 12);
        img.fillRect(W - 38, 84, 42, 12);

        // cabina alta
        img.setColor(cuerpo);
        img.fillRect(42, 26, W - 84, 52);
        img.setColor(new Color(34, 42, 62));
        img.fillRect(52, 32, W - 104, 34);

        // faro en el techo
        img.setColor(new Color(30, 30, 34));
        img.fillRect(84, 16, W - 168, 12);
        img.setColor(new Color(255, 245, 190));
        img.fillRect(88, 18, 16, 8);
        img.fillRect(W - 104, 18, 16, 8);
        // snorkel
        img.setColor(oscuro);
        img.fillRect(46, 20, 8, 40);

        // carroceria
        img.setColor(cuerpo);
        img.fillRect(14, 84, W - 28, 44);
        img.setColor(oscuro);
        img.fillRect(14, 116, W - 28, 12);

        // franjas de rally
        img.setColor(detalle);
        img.fillRect(76, 84, 12, 44);
        img.fillRect(W - 88, 84, 12, 44);

        // rueda de auxilio atras
        img.setColor(new Color(18, 18, 20));
        img.fillOval(W / 2 - 22, 92, 44, 44);
        img.setColor(new Color(70, 72, 78));
        img.fillOval(W / 2 - 9, 105, 18, 18);

        // pilotos
        img.setColor(new Color(235, 60, 60));
        img.fillRect(22, 88, 30, 12);
        img.fillRect(W - 52, 88, 30, 12);

        img.setColor(Color.BLACK);
        img.drawRect(14, 84, W - 29, 44);
        img.drawRect(42, 26, W - 85, 52);
    }

    // ==================================================================
    // MODELO 6 - HYPER S9 : hipercar bajisimo y ancho, aleron activo,
    //            difusor de aletas, cuadruple escape central.
    // ==================================================================
    private static void autoSuper(GreenfootImage img, Color cuerpo, Color detalle)
    {
        int W = 200;
        Color oscuro = mezclar(cuerpo, Color.BLACK, 0.5);
        Color claro  = mezclar(cuerpo, Color.WHITE, 0.18);
        sombra(img, W);

        img.setColor(new Color(16, 16, 20));
        img.fillRect(2, 100, 30, 38);
        img.fillRect(W - 32, 100, 30, 38);

        // techo cortisimo
        img.setColor(cuerpo);
        img.fillPolygon(new int[]{ 62, W - 62, W - 78, 78 }, new int[]{ 30, 30, 66, 66 }, 4);
        img.setColor(new Color(24, 30, 48));
        img.fillPolygon(new int[]{ 72, W - 72, W - 82, 82 }, new int[]{ 35, 35, 60, 60 }, 4);
        img.setColor(new Color(120, 150, 210, 110));
        img.fillRect(82, 35, W - 164, 8);

        // cuerpo bajo y ancho con hombro brillante
        img.setColor(cuerpo);
        img.fillRect(6, 88, W - 12, 34);
        img.setColor(claro);
        img.fillRect(6, 88, W - 12, 7);
        img.setColor(oscuro);
        img.fillRect(6, 114, W - 12, 12);

        // aleron activo sobre soportes finos
        img.setColor(new Color(30, 30, 34));
        img.fillRect(46, 60, 6, 26);
        img.fillRect(W - 52, 60, 6, 26);
        img.setColor(detalle);
        img.fillRect(24, 54, W - 48, 8);

        // cuadruple escape central + calor
        img.setColor(new Color(40, 40, 46));
        for (int i = 0; i < 4; i++) img.fillRect(W / 2 - 30 + i * 16, 124, 11, 9);
        img.setColor(new Color(255, 150, 70, 170));
        img.fillOval(W / 2 - 26, 126, 60, 6);

        // difusor de aletas
        img.setColor(new Color(24, 24, 28));
        for (int i = 0; i < 6; i++) img.fillRect(30 + i * 24, 126, 4, 12);

        // luces LED finas
        img.setColor(detalle);
        img.fillRect(20, 96, W - 40, 3);

        img.setColor(Color.BLACK);
        img.drawRect(6, 88, W - 13, 34);
    }

    // ==================================================================
    // MODELO 7 - SLIDE-X : misil de derrape. Bajo, ancho, ruedas con
    //            camber (abiertas arriba), aleron bajo y salida de escape
    //            lateral. Jaula antivuelco insinuada tras la luneta.
    // ==================================================================
    private static void autoDerrapa(GreenfootImage img, Color cuerpo, Color detalle)
    {
        int W = 200;
        Color oscuro = mezclar(cuerpo, Color.BLACK, 0.45);
        sombra(img, W);

        // ruedas con camber: paralelogramos con la parte de arriba hacia afuera
        img.setColor(new Color(18, 18, 22));
        img.fillPolygon(new int[]{ -6, 20, 30, 6 },        new int[]{ 92, 96, 138, 134 }, 4);
        img.fillPolygon(new int[]{ W + 6, W - 20, W - 30, W - 6 }, new int[]{ 92, 96, 138, 134 }, 4);
        img.setColor(new Color(90, 60, 120));            // llantas
        img.fillOval(2, 106, 18, 18);
        img.fillOval(W - 20, 106, 18, 18);

        // cabina baja
        img.setColor(cuerpo);
        img.fillRect(48, 30, W - 96, 44);
        img.setColor(new Color(26, 30, 42));
        img.fillRect(58, 35, W - 116, 30);
        // jaula antivuelco
        img.setColor(new Color(210, 210, 220));
        img.drawLine(60, 64, 74, 38);
        img.drawLine(W - 60, 64, W - 74, 38);
        img.drawLine(74, 38, W - 74, 38);

        // cuerpo ancho
        img.setColor(cuerpo);
        img.fillRect(8, 90, W - 16, 34);
        img.setColor(oscuro);
        img.fillRect(8, 114, W - 16, 12);

        // aleron bajo tipo "ducktail"
        img.setColor(detalle);
        img.fillRect(20, 80, W - 40, 10);

        // salida de escape lateral con humo
        img.setColor(new Color(50, 50, 56));
        img.fillRect(0, 108, 14, 8);
        img.setColor(new Color(150, 150, 156, 150));
        img.fillOval(-6, 104, 16, 16);

        // luces
        img.setColor(new Color(255, 70, 70));
        img.fillRect(26, 96, 40, 12);
        img.fillRect(W - 66, 96, 40, 12);

        // livery flecha
        img.setColor(mezclar(detalle, Color.WHITE, 0.25));
        img.fillPolygon(new int[]{ W / 2 - 18, W / 2, W / 2 + 18 }, new int[]{ 122, 96, 122 }, 3);

        img.setColor(Color.BLACK);
        img.drawRect(8, 90, W - 17, 34);
        img.drawRect(48, 30, W - 97, 44);
    }

    // ==================================================================
    // VEHICULOS DE LA MAFIA (cinematicas de derrota), vista trasera.
    // ==================================================================
    /** Miniban negra. Base 200x150. */
    public static GreenfootImage minivan(Color cuerpo)
    {
        int W = 200;
        GreenfootImage img = new GreenfootImage(W, 150);
        Color oscuro = mezclar(cuerpo, Color.BLACK, 0.5);
        sombra(img, W);

        rueda(img, 4, 96, 30, 44);
        rueda(img, W - 34, 96, 30, 44);

        // caja alta de monovolumen
        img.setColor(cuerpo);
        img.fillRect(16, 22, W - 32, 108);
        img.setColor(oscuro);
        img.fillRect(16, 118, W - 32, 14);

        // luneta trasera ahumada
        img.setColor(new Color(18, 20, 26));
        img.fillRect(30, 30, W - 60, 44);
        img.setColor(new Color(60, 66, 80, 120));
        img.fillRect(30, 30, W - 60, 12);

        // puertas traseras + manijas
        img.setColor(oscuro);
        img.fillRect(W / 2 - 2, 74, 4, 44);
        img.setColor(new Color(150, 150, 155));
        img.fillRect(W / 2 - 18, 92, 12, 4);
        img.fillRect(W / 2 + 6, 92, 12, 4);

        // luces
        img.setColor(new Color(220, 60, 60));
        img.fillRect(24, 100, 30, 14);
        img.fillRect(W - 54, 100, 30, 14);

        img.setColor(Color.BLACK);
        img.drawRect(16, 22, W - 33, 108);
        return img;
    }

    /** Camioneta pickup con un sicario asomado en la caja. Base 200x150. */
    public static GreenfootImage camioneta(Color cuerpo)
    {
        int W = 200;
        GreenfootImage img = new GreenfootImage(W, 150);
        Color oscuro = mezclar(cuerpo, Color.BLACK, 0.45);
        sombra(img, W);

        rueda(img, 2, 92, 32, 48);
        rueda(img, W - 34, 92, 32, 48);

        // cabina
        img.setColor(cuerpo);
        img.fillRect(44, 34, W - 88, 44);
        img.setColor(new Color(20, 22, 28));
        img.fillRect(54, 40, W - 108, 30);

        // caja de carga con barra antivuelco
        img.setColor(cuerpo);
        img.fillRect(14, 74, W - 28, 54);
        img.setColor(oscuro);
        img.fillRect(14, 118, W - 28, 12);
        img.setColor(new Color(30, 30, 34));
        img.fillRect(40, 44, 8, 34);
        img.fillRect(W - 48, 44, 8, 34);
        img.drawLine(44, 46, W - 44, 46);

        // sicario asomado disparando
        img.setColor(new Color(232, 196, 162));
        img.fillOval(W / 2 - 10, 52, 20, 20);
        img.setColor(new Color(24, 24, 28));
        img.fillRect(W / 2 - 14, 70, 28, 22);
        img.setColor(new Color(40, 40, 46));
        img.fillRect(W / 2 + 8, 62, 34, 6);            // arma apuntando
        img.setColor(new Color(255, 220, 120, 220));
        img.fillOval(W / 2 + 40, 58, 14, 14);          // fogonazo

        img.setColor(new Color(220, 60, 60));
        img.fillRect(22, 104, 30, 14);
        img.fillRect(W - 52, 104, 30, 14);

        img.setColor(Color.BLACK);
        img.drawRect(14, 74, W - 29, 54);
        return img;
    }

    /**
     * La TORRE de la Organizacion: un rascacielos con forma de cabeza de
     * diablo — dos cuernos, dos ojos rojos furiosos y una sonrisa maléfica
     * de ventanas encendidas. Anclada abajo.
     */
    public static GreenfootImage torreDiablo(int W, int H)
    {
        GreenfootImage img = new GreenfootImage(W, H);
        Color piedra  = new Color(20, 13, 20);
        Color piedra2 = new Color(34, 20, 30);

        int topW = (int) (W * 0.60);
        int topY = (int) (H * 0.30);

        // cuerpo (se estrecha hacia arriba)
        img.setColor(piedra);
        img.fillPolygon(new int[]{ 0, W, (W + topW) / 2, (W - topW) / 2 },
                        new int[]{ H, H, topY, topY }, 4);
        img.setColor(piedra2);
        img.fillPolygon(new int[]{ (W - topW) / 2, W / 2, W / 2, 0 },
                        new int[]{ topY, topY, H, H }, 4);

        // cuernos
        int cornH = (int) (H * 0.24);
        img.setColor(piedra);
        img.fillPolygon(new int[]{ (W - topW) / 2 - 2, (W - topW) / 2 + (int)(W*0.14), (W - topW) / 2 + (int)(W*0.05) },
                        new int[]{ topY + 12, topY + 12, topY - cornH }, 3);
        img.fillPolygon(new int[]{ (W + topW) / 2 + 2, (W + topW) / 2 - (int)(W*0.14), (W + topW) / 2 - (int)(W*0.05) },
                        new int[]{ topY + 12, topY + 12, topY - cornH }, 3);

        // ventanas tenues por todo el cuerpo
        img.setColor(new Color(190, 110, 45, 110));
        for (int yy = topY + 8; yy < H - 8; yy += 14)
            for (int xx = 8; xx < W - 8; xx += 14)
                if ((xx * 7 + yy * 13) % 3 == 0) img.fillRect(xx, yy, 3, 4);

        // OJOS: trapecios rojos inclinados hacia el centro (furia)
        int oy = (int) (H * 0.40), oh = (int) (H * 0.11);
        img.setColor(new Color(255, 55, 35));
        img.fillPolygon(new int[]{ (int)(W*0.28), (int)(W*0.45), (int)(W*0.45), (int)(W*0.30) },
                        new int[]{ oy, oy + oh/2, oy + oh, oy + oh }, 4);
        img.fillPolygon(new int[]{ (int)(W*0.72), (int)(W*0.55), (int)(W*0.55), (int)(W*0.70) },
                        new int[]{ oy, oy + oh/2, oy + oh, oy + oh }, 4);
        img.setColor(new Color(255, 220, 140));
        img.fillRect((int)(W*0.35), oy + oh/2, Math.max(3, W/26), Math.max(3, H/44));
        img.fillRect((int)(W*0.60), oy + oh/2, Math.max(3, W/26), Math.max(3, H/44));

        // SONRISA: arco de ventanas encendidas, con dos colmillos (huecos)
        int by0 = (int) (H * 0.60), amp = (int) (H * 0.09);
        int n = 13;
        img.setColor(new Color(255, 150, 45));
        for (int i = 0; i < n; i++) {
            double t = i / (double) (n - 1);
            int bx = (int) (W * 0.24 + t * W * 0.52);
            int by = by0 + (int) (Math.sin(t * Math.PI) * amp);
            boolean colmillo = (i == 3 || i == 9);
            img.fillRect(bx, by, colmillo ? 5 : 9, colmillo ? 22 : 11);
        }

        return img;
    }

    /** Bloque de motor que sale volando (firma del CLASICO 84). Base 90x70. */
    public static GreenfootImage bloqueMotor()
    {
        GreenfootImage img = new GreenfootImage(90, 70);
        img.setColor(new Color(70, 72, 80));
        img.fillRect(8, 12, 74, 50);
        img.setColor(new Color(48, 50, 56));
        img.fillRect(8, 12, 74, 10);
        img.setColor(new Color(30, 30, 34));
        for (int i = 0; i < 4; i++) img.fillRect(14 + i * 18, 22, 8, 34);
        img.setColor(new Color(255, 150, 60, 180));
        img.fillOval(0, 0, 90, 30);
        return img;
    }

    /** Muro contra el que se estrella el SLIDE-X. Base 260x180, anclado abajo. */
    public static GreenfootImage muro()
    {
        GreenfootImage img = new GreenfootImage(260, 180);
        img.setColor(new Color(90, 90, 96));
        img.fillRect(0, 30, 260, 150);
        img.setColor(new Color(70, 70, 76));
        for (int y = 34; y < 180; y += 22)
            for (int x = 0; x < 260; x += 44) img.fillRect(x + (y / 22 % 2) * 22, y, 40, 18);
        img.setColor(new Color(230, 200, 60));
        img.fillRect(0, 8, 260, 16);
        img.setColor(new Color(30, 30, 32));
        img.drawRect(0, 30, 259, 149);
        return img;
    }

    /** Platillo volador para la muerte OVNI. Base 260x130. */
    public static GreenfootImage ovni()
    {
        int W = 260;
        GreenfootImage img = new GreenfootImage(W, 130);
        img.setColor(new Color(120, 220, 255, 220));
        img.fillOval(W / 2 - 52, 4, 104, 72);
        img.setColor(new Color(210, 245, 255, 170));
        img.fillOval(W / 2 - 34, 12, 52, 34);
        img.setColor(new Color(72, 80, 92));
        img.fillOval(4, 48, W - 8, 52);
        img.setColor(new Color(40, 46, 56));
        img.fillOval(28, 64, W - 56, 30);
        for (int i = 0; i < 7; i++) {
            img.setColor(i % 2 == 0 ? new Color(255, 120, 200) : new Color(120, 255, 180));
            img.fillOval(24 + i * (W - 60) / 6, 78, 13, 13);
        }
        return img;
    }

    /** Grieta que cruza la ruta (ataque ROMPER LA CALLE). Base 520x210, anclada abajo. */
    public static GreenfootImage grietaCalle()
    {
        int W = 520, H = 210;
        GreenfootImage g = new GreenfootImage(W, H);

        // abismo negro con borde dentado arriba y abajo
        int[] xs = { 0, 52, 118, 176, 250, 322, 388, 452, W,  W, 452, 360, 286, 210, 132, 66, 0 };
        int[] ys = { 96, 58, 92,  46,  88,  40,  84,  52,  70, H,  H-24, H-6, H-34, H-10, H-30, H-4, H };
        g.setColor(new Color(9, 7, 9));
        g.fillPolygon(xs, ys, xs.length);

        // labio de asfalto roto que se levanta hacia el jugador
        g.setColor(new Color(58, 58, 64));
        g.fillPolygon(new int[]{ 0, W, W, 0 }, new int[]{ 88, 64, 96, 118 }, 4);
        g.setColor(new Color(84, 84, 92));
        g.fillPolygon(new int[]{ 0, W, W, 0 }, new int[]{ 88, 64, 74, 96 }, 4);
        g.setColor(new Color(255, 235, 255));                     // resto de linea blanca partida
        g.fillRect(W / 2 - 46, 78, 30, 6);
        g.fillRect(W / 2 + 16, 70, 30, 6);

        // grietas que bajan
        g.setColor(new Color(18, 16, 18));
        for (int i = 0; i < 7; i++) {
            int cx = 30 + i * 74;
            g.drawLine(cx, 96, cx + ((i % 2 == 0) ? 26 : -22), H);
            g.drawLine(cx, 96, cx + ((i % 2 == 0) ? -14 : 18), H - 40);
        }

        // cascotes al borde
        g.setColor(new Color(66, 66, 72));
        int[] cs = { 24, 90, 150, 300, 370, 470 };
        for (int i = 0; i < cs.length; i++) {
            int cy = 92 + (i * 37) % 60;
            g.fillPolygon(new int[]{ cs[i], cs[i] + 20, cs[i] + 8 },
                          new int[]{ cy, cy + 4, cy + 16 }, 3);
        }
        return g;
    }

    /** Portal para la muerte PORTAL. Base 200x200. */
    public static GreenfootImage portal()
    {
        int S = 200;
        GreenfootImage img = new GreenfootImage(S, S);
        for (int i = 0; i < 6; i++) {
            int a = 210 - i * 32;
            img.setColor(new Color(Math.min(255, 150 + i * 16), 50, Math.max(0, 255 - i * 22),
                                   Math.max(0, a)));
            img.fillOval(i * 15, i * 15, S - i * 30, S - i * 30);
        }
        img.setColor(new Color(18, 0, 34));
        img.fillOval(S / 2 - 22, S / 2 - 22, 44, 44);
        return img;
    }

    /** Criatura gigante para la muerte BESTIA. Base 340x380, anclada abajo. */
    public static GreenfootImage bestia()
    {
        int W = 340, H = 380;
        GreenfootImage img = new GreenfootImage(W, H);
        Color c = new Color(58, 44, 40), d = new Color(38, 28, 24);
        img.setColor(d);
        img.fillRect(46, H - 150, 62, 150);
        img.fillRect(W - 108, H - 150, 62, 150);
        img.setColor(c);
        img.fillOval(18, 100, W - 36, 210);
        img.fillOval(W / 2 - 74, 20, 148, 140);
        img.setColor(new Color(255, 70, 40));
        img.fillOval(W / 2 - 46, 62, 28, 22);
        img.fillOval(W / 2 + 18, 62, 28, 22);
        img.setColor(d);
        img.fillPolygon(new int[]{ W / 2 - 66, W / 2 - 38, W / 2 - 92 }, new int[]{ 40, -24, 26 }, 3);
        img.fillPolygon(new int[]{ W / 2 + 66, W / 2 + 38, W / 2 + 92 }, new int[]{ 40, -24, 26 }, 3);
        img.setColor(new Color(240, 240, 245));
        for (int i = 0; i < 5; i++) img.fillPolygon(
            new int[]{ W / 2 - 40 + i * 20, W / 2 - 32 + i * 20, W / 2 - 24 + i * 20 },
            new int[]{ 150, 128, 150 }, 3);
        return img;
    }

    // ==================================================================
    // PROPS PARA LAS 130 MUERTES
    // ==================================================================

    /** Prop del costado de la ruta contra el que te descarrilas. i mod 12. */
    public static GreenfootImage propLado(int i)
    {
        i = ((i % 12) + 12) % 12;
        GreenfootImage g = new GreenfootImage(140, 300);
        Color metal = new Color(46, 48, 54), gris = new Color(96, 96, 102);
        switch (i) {
            case 0:  return arbolChoque();
            case 1:  return farola();
            case 2:  g.setColor(new Color(88, 82, 74)); g.fillOval(20, 150, 100, 130);           // roca
                     g.setColor(new Color(64, 60, 54)); g.fillOval(44, 190, 44, 44); return g;
            case 3:  return cartel(new Color(210, 60, 40));                                       // cartel
            case 4:  g.setColor(metal);                                                          // cerca
                     for (int k = 0; k < 5; k++) g.fillRect(10 + k * 28, 150, 8, 150);
                     g.fillRect(6, 170, 130, 8); g.fillRect(6, 230, 130, 8); return g;
            case 5:  g.setColor(new Color(200, 60, 50)); g.fillRect(52, 150, 36, 150);           // hidrante
                     g.fillOval(40, 130, 60, 40); g.fillRect(24, 210, 92, 14); return g;
            case 6:  g.setColor(new Color(120, 84, 50)); g.fillRect(14, 220, 112, 20);           // banco
                     g.fillRect(14, 180, 112, 16); g.fillRect(22, 236, 12, 50); g.fillRect(106, 236, 12, 50); return g;
            case 7:  g.setColor(new Color(60, 100, 180)); g.fillRect(46, 180, 48, 60);           // buzon
                     g.setColor(metal); g.fillRect(60, 240, 20, 60); return g;
            case 8:  g.setColor(new Color(40, 120, 60)); g.fillOval(30, 120, 80, 160);           // cactus
                     g.fillRect(10, 180, 34, 24); g.fillRect(96, 200, 34, 24); return g;
            case 9:  g.setColor(new Color(70, 110, 40)); g.fillRect(20, 60, 100, 240);           // contenedor
                     g.setColor(new Color(50, 84, 28)); g.fillRect(20, 60, 100, 20); return g;
            case 10: g.setColor(metal); g.fillRect(60, 90, 12, 210);                             // semaforo
                     g.setColor(new Color(20, 20, 22)); g.fillRect(48, 60, 36, 70);
                     g.setColor(new Color(255, 60, 60)); g.fillOval(56, 68, 20, 20); return g;
            case 11: g.setColor(gris); g.fillRect(44, 40, 52, 260);                              // monolito
                     g.setColor(new Color(120, 120, 128)); g.fillRect(44, 40, 52, 12); return g;
        }
        return g;
    }

    /** Objeto que cae del cielo. i mod 12. */
    public static GreenfootImage objetoCae(int i)
    {
        i = ((i % 12) + 12) % 12;
        int S = 130;
        GreenfootImage g = new GreenfootImage(S, S);
        switch (i) {
            case 0:  g.setColor(new Color(58, 40, 30)); g.fillOval(18, 18, 94, 94);              // meteorito
                     g.setColor(new Color(255, 150, 40, 210)); g.fillOval(0, 0, S, 46); break;
            case 1:  g.setColor(new Color(16, 16, 18)); g.fillRect(10, 40, 110, 60);             // piano
                     g.setColor(Color.WHITE); for (int k=0;k<9;k++) g.fillRect(14+k*12, 44, 9, 24);
                     g.setColor(new Color(16,16,18)); for (int k=0;k<8;k++) g.fillRect(20+k*12, 44, 6, 16); break;
            case 2:  g.setColor(new Color(70, 72, 80)); g.fillRect(24, 24, 82, 82);              // caja fuerte
                     g.setColor(new Color(40,42,48)); g.fillRect(24,24,82,82); g.drawRect(24,24,82,82);
                     g.setColor(new Color(200,200,60)); g.fillOval(80, 58, 16, 16); break;
            case 3:  g.setColor(new Color(40, 42, 48)); g.fillRect(30, 30, 70, 30);              // yunque
                     g.fillRect(44, 58, 42, 44); g.fillRect(20, 26, 90, 12); break;
            case 4:  g.setColor(new Color(235, 235, 240)); g.fillRect(34, 14, 62, 104);          // heladera
                     g.setColor(new Color(180,180,186)); g.fillRect(40, 60, 8, 40); break;
            case 5:  g.setColor(new Color(20, 20, 24)); g.fillRect(20, 30, 90, 62);              // tv
                     g.setColor(new Color(90, 140, 200)); g.fillRect(28, 38, 74, 46); break;
            case 6:  g.setColor(new Color(180, 190, 210)); g.fillOval(24, 40, 82, 44);           // satelite
                     g.setColor(new Color(60, 90, 160)); g.fillRect(0, 52, 24, 20); g.fillRect(106, 52, 24, 20); break;
            case 7:  g.setColor(new Color(210, 210, 216)); g.fillPolygon(new int[]{10,120,10}, new int[]{60,66,72}, 3); // avion
                     g.fillRect(40, 50, 50, 30); g.setColor(new Color(120,60,60)); g.fillRect(84, 46, 30, 8); break;
            case 8:  g.setColor(new Color(30, 30, 34)); g.fillOval(24, 24, 82, 82);              // bola demolicion
                     g.setColor(new Color(90,90,96)); g.fillRect(60, 0, 8, 30); break;
            case 9:  g.setColor(new Color(60, 66, 70)); g.fillRect(56, 8, 16, 60);               // ancla
                     g.fillRect(30, 40, 70, 12); g.fillPolygon(new int[]{20,40,44}, new int[]{60,100,58}, 3);
                     g.fillPolygon(new int[]{110,90,86}, new int[]{60,100,58}, 3); break;
            case 10: g.setColor(new Color(120, 84, 50)); g.fillOval(20, 20, 90, 90);             // roca gigante
                     g.setColor(new Color(90, 62, 38)); g.fillOval(44, 44, 40, 40); break;
            default: g.setColor(new Color(90, 92, 100)); g.fillRect(14, 30, 100, 70);            // chatarra
                     g.setColor(new Color(60,62,70)); g.fillRect(14, 30, 100, 14); break;
        }
        return g;
    }

    /** Criatura gigante. i mod 8. */
    public static GreenfootImage criatura(int i)
    {
        i = ((i % 8) + 8) % 8;
        int W = 340, H = 380;
        GreenfootImage g = new GreenfootImage(W, H);
        Color[] cols = { new Color(58,44,40), new Color(120,40,50), new Color(50,80,60),
                         new Color(220,220,230), new Color(90,70,120), new Color(40,60,90),
                         new Color(150,110,40), new Color(30,30,36) };
        Color c = cols[i], d = mezclar(c, Color.BLACK, 0.4);

        if (i == 1 || i == 4) {                 // tentaculos (kraken / pulpo)
            g.setColor(c);
            g.fillOval(W/2 - 90, 20, 180, 150);
            for (int k = 0; k < 5; k++) {
                int bx = 30 + k * 66;
                g.fillPolygon(new int[]{bx, bx + 26, bx + 8}, new int[]{160, 160, H}, 3);
            }
            g.setColor(new Color(255, 200, 60)); g.fillOval(W/2 - 34, 60, 26, 26); g.fillOval(W/2 + 10, 60, 26, 26);
            return g;
        }
        if (i == 3) {                           // serpiente / gusano
            g.setColor(c);
            for (int k = 0; k < 6; k++) g.fillOval(W/2 - 60 + (int)(Math.sin(k)*40), H - 60 - k*54, 120 - k*8, 90 - k*6);
            g.setColor(new Color(255, 60, 40)); g.fillOval(W/2 - 20, 30, 18, 14); g.fillOval(W/2 + 6, 30, 18, 14);
            return g;
        }
        // cuadrupedo / biped generico
        g.setColor(d);
        g.fillRect(46, H - 150, 62, 150);
        g.fillRect(W - 108, H - 150, 62, 150);
        g.setColor(c);
        g.fillOval(18, 100, W - 36, 210);
        g.fillOval(W/2 - 74, 20, 148, 140);
        g.setColor(new Color(255, 70, 40));
        g.fillOval(W/2 - 46, 62, 28, 22); g.fillOval(W/2 + 18, 62, 28, 22);
        if (i == 0 || i == 6) {                 // cuernos
            g.setColor(d);
            g.fillPolygon(new int[]{W/2-66, W/2-38, W/2-92}, new int[]{40,-24,26}, 3);
            g.fillPolygon(new int[]{W/2+66, W/2+38, W/2+92}, new int[]{40,-24,26}, 3);
        }
        if (i == 2) {                           // dino: dientes
            g.setColor(Color.WHITE);
            for (int k = 0; k < 5; k++) g.fillPolygon(
                new int[]{W/2-40+k*20, W/2-32+k*20, W/2-24+k*20}, new int[]{150,128,150}, 3);
        }
        return g;
    }

    /** Maquina que baja del cielo. i mod 6. */
    public static GreenfootImage maquinaBaja(int i)
    {
        i = ((i % 6) + 6) % 6;
        switch (i) {
            case 0: return ovni();
            case 1: return helicoptero(HeliTipo.paraNivel(20));
            case 2: { GreenfootImage g = new GreenfootImage(200, 200);                            // grua con gancho
                      g.setColor(new Color(60, 62, 70)); g.fillRect(96, 0, 8, 150);
                      g.setColor(new Color(200, 180, 60)); g.fillRect(70, 0, 60, 12);
                      g.setColor(new Color(60,62,70)); g.drawLine(100, 150, 100, 180);
                      g.fillPolygon(new int[]{88,112,100}, new int[]{178,178,196}, 3); return g; }
            case 3: { GreenfootImage g = new GreenfootImage(320, 160);                            // dirigible
                      g.setColor(new Color(180, 60, 60)); g.fillOval(0, 20, 320, 90);
                      g.setColor(new Color(40, 42, 48)); g.fillRect(130, 100, 60, 26); return g; }
            case 4: { GreenfootImage g = new GreenfootImage(240, 150);                            // drone gigante
                      g.setColor(new Color(40, 42, 48)); g.fillRect(60, 50, 120, 40);
                      for (int k=0;k<4;k++){ int cx=k<2?30:210; int cy=k%2==0?30:110;
                        g.setColor(new Color(30,30,36)); g.fillOval(cx-24, cy-8, 48, 16); }
                      g.setColor(new Color(120,220,255)); g.fillOval(110, 60, 20, 20); return g; }
            default: { GreenfootImage g = new GreenfootImage(120, 220);                           // brazo robotico
                      g.setColor(new Color(70, 72, 80)); g.fillRect(50, 0, 20, 150);
                      g.setColor(new Color(50,52,60)); g.fillRect(30, 140, 60, 26);
                      g.fillPolygon(new int[]{30,50,40}, new int[]{166,200,168}, 3);
                      g.fillPolygon(new int[]{90,70,80}, new int[]{166,200,168}, 3); return g; }
        }
    }

    /** Aplastador que baja recto y aplasta. i mod 5. */
    public static GreenfootImage aplastador(int i)
    {
        i = ((i % 5) + 5) % 5;
        int W = 420, H = 260;
        GreenfootImage g = new GreenfootImage(W, H);
        switch (i) {
            case 0:  camionGigante(g); break;
            case 1:  g.setColor(new Color(80, 82, 90)); g.fillRect(20, 20, W - 40, H - 60);       // prensa
                     g.setColor(new Color(40,42,48)); g.fillRect(20, H - 50, W - 40, 20); break;
            case 2:  g.setColor(new Color(30, 30, 34)); g.fillOval(90, 0, 240, 180);              // pie gigante
                     g.fillRect(120, 140, 190, 90); break;
            case 3:  g.setColor(new Color(40, 36, 44)); g.fillRect(0, 0, W, H);                   // edificio
                     g.setColor(new Color(255, 170, 60, 150));
                     for (int y=16;y<H-10;y+=26) for (int x=16;x<W-10;x+=30)
                        if ((x*7+y*13)%3==0) g.fillRect(x, y, 8, 10); break;
            default: g.setColor(new Color(90, 62, 38)); g.fillOval(60, 20, 300, 220); break;      // roca rodante
        }
        return g;
    }

    private static void camionGigante(GreenfootImage g)
    {
        int W = 420;
        g.setColor(new Color(24, 24, 30));
        g.fillRect(20, 30, W - 40, 150);
        g.setColor(new Color(18, 18, 24));
        g.fillRect(20, 160, W - 40, 40);
        g.setColor(new Color(220, 60, 60));
        g.fillRect(40, 130, 60, 30);
        g.fillRect(W - 100, 130, 60, 30);
        g.setColor(new Color(15, 15, 18));
        for (int k = 0; k < 6; k++) g.fillOval(40 + k * 62, 180, 50, 50);
    }

    // ==================================================================
    // JEFES CON ASPECTO PROPIO
    // ==================================================================

    /** Helicoptero-jefe con un sicario SENTADO ATRAS disparando. Base 300x150. */
    public static GreenfootImage heliBoss(int fase)
    {
        int W = 300, H = 150;
        GreenfootImage img = new GreenfootImage(W, H);
        Color casco = fase >= 3 ? new Color(120, 30, 40) : fase == 2 ? new Color(70, 60, 66) : new Color(56, 60, 68);

        // rotores
        img.setColor(new Color(35, 35, 40, 160)); img.fillRect(0, 14, W, 7);
        img.setColor(new Color(35, 35, 40, 80));  img.fillRect(0, 8, W, 18);
        // cola
        img.setColor(mezclar(casco, Color.BLACK, 0.3)); img.fillRect(W - 70, 60, 66, 16);
        // fuselaje
        img.setColor(casco); img.fillOval(60, 34, 160, 74);
        img.setColor(mezclar(casco, Color.BLACK, 0.35)); img.fillOval(60, 74, 160, 34);
        // bahia trasera abierta con el sicario sentado
        img.setColor(new Color(18, 18, 22)); img.fillRect(70, 56, 54, 46);
        img.setColor(new Color(232, 196, 162)); img.fillOval(84, 60, 18, 18);     // cabeza
        img.setColor(new Color(20, 20, 26)); img.fillRect(80, 78, 26, 22);        // torso
        img.setColor(new Color(40, 40, 46)); img.fillRect(60, 82, 26, 6);         // arma
        img.setColor(new Color(255, 210, 120, 220)); img.fillOval(48, 78, 12, 12);// fogonazo
        // cabina
        img.setColor(new Color(255, 90, 90)); img.fillOval(170, 52, 60, 30);
        // patines
        img.setColor(new Color(45, 48, 52)); img.fillRect(80, 116, 130, 6);
        // luces de fase
        img.setColor(fase >= 3 ? new Color(255, 200, 60) : new Color(120, 220, 255));
        for (int i = 0; i < 5; i++) img.fillOval(90 + i * 26, 104, 10, 8);
        return img;
    }

    /** Auto-jefe (SICARIO): coche negro artillado, vista trasera. Base 200x150. */
    public static GreenfootImage autoBoss()
    {
        int W = 200;
        GreenfootImage img = new GreenfootImage(W, 150);
        Color c = new Color(18, 18, 22), o = new Color(10, 10, 12);
        sombra(img, W);
        rueda(img, -2, 90, 34, 48); rueda(img, W - 32, 90, 34, 48);
        img.setColor(o); img.fillRect(20, 30, W - 40, 12);                    // aleron
        img.setColor(c); img.fillRect(44, 32, W - 88, 46);                    // cabina
        img.setColor(new Color(30, 34, 44)); img.fillRect(54, 38, W - 108, 30);
        img.setColor(c); img.fillRect(10, 82, W - 20, 44);
        img.setColor(o); img.fillRect(10, 114, W - 20, 14);
        img.setColor(new Color(255, 50, 50)); img.fillRect(24, 92, 44, 14); img.fillRect(W - 68, 92, 44, 14);
        // torretas
        img.setColor(new Color(40, 42, 48)); img.fillRect(16, 70, 16, 10); img.fillRect(W - 32, 70, 16, 10);
        img.setColor(new Color(255, 200, 80, 200)); img.fillOval(10, 68, 12, 12); img.fillOval(W - 22, 68, 12, 12);
        img.setColor(Color.BLACK); img.drawRect(10, 82, W - 21, 44);
        return img;
    }

    /** Camion-jefe (CAPO): blindado, vista trasera. Base 200x150. */
    public static GreenfootImage camionBoss()
    {
        int W = 200;
        GreenfootImage img = new GreenfootImage(W, 150);
        Color c = new Color(40, 30, 24), o = new Color(24, 18, 14);
        sombra(img, W);
        rueda(img, -4, 88, 40, 52); rueda(img, W - 36, 88, 40, 52);
        img.setColor(c); img.fillRect(8, 18, W - 16, 116);
        img.setColor(o); img.fillRect(8, 116, W - 16, 18);
        img.setColor(new Color(60, 46, 36)); img.fillRect(30, 26, W - 60, 40);   // luneta blindada
        img.setColor(new Color(90, 92, 100));                                    // placas
        img.fillRect(8, 60, W - 16, 10); img.fillRect(8, 90, W - 16, 8);
        img.setColor(new Color(255, 60, 40)); img.fillRect(20, 100, 40, 16); img.fillRect(W - 60, 100, 40, 16);
        img.setColor(new Color(200, 40, 40)); img.fillPolygon(                    // calavera
            new int[]{ W/2 - 14, W/2 + 14, W/2 }, new int[]{ 78, 78, 100 }, 3);
        img.setColor(Color.BLACK); img.drawRect(8, 18, W - 17, 116);
        return img;
    }

    /** EL DON: figura colosal de fondo (traje + sombrero), pecho brillante = punto debil. Base 360x360. */
    public static GreenfootImage donGigante(int fase)
    {
        int W = 360, H = 360;
        GreenfootImage img = new GreenfootImage(W, H);
        Color traje = fase >= 3 ? new Color(60, 12, 16) : new Color(16, 16, 22);

        // hombros / cuerpo
        img.setColor(traje);
        img.fillPolygon(new int[]{ 30, W - 30, W - 60, 60 }, new int[]{ H, H, 140, 140 }, 4);
        // cabeza
        img.setColor(new Color(220, 186, 150));
        img.fillOval(W/2 - 46, 70, 92, 92);
        // sombrero
        img.setColor(new Color(10, 10, 14));
        img.fillOval(W/2 - 80, 78, 160, 30);
        img.fillRect(W/2 - 42, 40, 84, 44);
        // ojos rojos
        img.setColor(new Color(255, 40, 40));
        img.fillRect(W/2 - 28, 118, 18, 8); img.fillRect(W/2 + 10, 118, 18, 8);
        // corbata
        img.setColor(new Color(150, 20, 30));
        img.fillPolygon(new int[]{ W/2 - 10, W/2 + 10, W/2 }, new int[]{ 150, 150, 210 }, 3);
        // PECHO BRILLANTE = punto debil
        int p = 40 + (fase - 1) * 10;
        img.setColor(new Color(255, 180, 60, 220));
        img.fillOval(W/2 - p/2 - 8, 210, p + 16, p + 16);
        img.setColor(new Color(255, 240, 180));
        img.fillOval(W/2 - p/2, 218, p, p);
        return img;
    }

    /** Auto de rivales-sicarios que te adelantan disparando. muerto = sin el tipo asomado. Base 200x150. */
    public static GreenfootImage autoSicario(boolean muerto)
    {
        GreenfootImage img = rival(new Color(24, 24, 30));
        if (!muerto) {
            img.setColor(new Color(232, 196, 162)); img.fillOval(150, 60, 18, 18);   // cabeza asomada
            img.setColor(new Color(20, 20, 26)); img.fillRect(146, 76, 24, 16);      // torso
            img.setColor(new Color(40, 40, 46)); img.fillRect(168, 66, 30, 6);       // arma hacia atras
            img.setColor(new Color(255, 210, 120, 220)); img.fillOval(196, 62, 12, 12);
        }
        return img;
    }

    // ==================================================================
    // MINI-JEFES (rangos bajos de la mafia) - ninguno es igual, y todos
    // mas chicos que los jefes con nombre.
    // ==================================================================

    /** EL RECLUTA: moto vista trasera con el sicario y un arma al costado. Base 120x150. */
    public static GreenfootImage motoSicario()
    {
        int W = 120, H = 150;
        GreenfootImage img = new GreenfootImage(W, H);
        img.setColor(new Color(0, 0, 0, 90)); img.fillOval(24, 134, W - 48, 12);
        // rueda trasera
        img.setColor(new Color(16, 16, 20)); img.fillRect(W / 2 - 20, 68, 40, 68);
        img.setColor(new Color(80, 82, 90)); img.fillRect(W / 2 - 12, 92, 24, 22);
        // chasis
        img.setColor(new Color(120, 20, 24)); img.fillRect(W / 2 - 16, 58, 32, 34);
        // manillar
        img.setColor(new Color(40, 40, 46)); img.fillRect(W / 2 - 30, 50, 60, 6);
        // sicario
        img.setColor(new Color(24, 24, 30)); img.fillRect(W / 2 - 20, 26, 40, 40);   // espalda
        img.setColor(new Color(16, 16, 20)); img.fillOval(W / 2 - 13, 4, 26, 26);     // casco
        img.setColor(new Color(70, 130, 200)); img.fillRect(W / 2 - 11, 12, 22, 6);   // visera
        // brazo con arma hacia atras
        img.setColor(new Color(24, 24, 30)); img.fillRect(W / 2 + 12, 38, 30, 8);
        img.setColor(new Color(40, 40, 46)); img.fillRect(W / 2 + 38, 36, 22, 6);
        img.setColor(new Color(255, 210, 120, 220)); img.fillOval(W / 2 + 56, 32, 12, 12);
        return img;
    }

    /** EL PUNTERO: camioneta con un tipo parado en la caja disparando. Base 200x150. */
    public static GreenfootImage camionetaBoss()
    {
        int W = 200;
        GreenfootImage img = new GreenfootImage(W, 150);
        Color c = new Color(46, 52, 46), o = new Color(26, 30, 26);
        sombra(img, W);
        rueda(img, -2, 92, 34, 46); rueda(img, W - 32, 92, 34, 46);
        // caja
        img.setColor(c); img.fillRect(14, 52, W - 28, 76);
        img.setColor(o); img.fillRect(14, 116, W - 28, 14);
        img.setColor(new Color(60, 66, 60)); img.fillRect(24, 60, W - 48, 40);   // interior de la caja
        // cabina asomando por arriba
        img.setColor(c); img.fillRect(50, 28, W - 100, 30);
        img.setColor(new Color(30, 34, 40)); img.fillRect(60, 32, W - 120, 20);
        // tipo parado en la caja
        img.setColor(new Color(232, 196, 162)); img.fillOval(W / 2 - 10, 38, 20, 20);
        img.setColor(new Color(20, 20, 26)); img.fillRect(W / 2 - 14, 56, 28, 36);
        img.setColor(new Color(40, 40, 46)); img.fillRect(W / 2 + 10, 60, 34, 7);   // arma
        img.setColor(new Color(255, 210, 120, 220)); img.fillOval(W / 2 + 40, 56, 14, 14);
        // luces traseras
        img.setColor(new Color(255, 60, 50)); img.fillRect(22, 104, 34, 12); img.fillRect(W - 56, 104, 34, 12);
        return img;
    }

    /** EL COBRADOR: muscle car blindado que embiste, vista trasera. Base 200x150. */
    public static GreenfootImage muscleBoss()
    {
        int W = 200;
        GreenfootImage img = new GreenfootImage(W, 150);
        Color c = new Color(28, 24, 26), o = new Color(14, 12, 14);
        sombra(img, W);
        rueda(img, -4, 90, 38, 50); rueda(img, W - 34, 90, 38, 50);
        img.setColor(o); img.fillRect(16, 26, W - 32, 10);            // aleron grueso
        img.setColor(c); img.fillRect(40, 28, W - 80, 44);            // techo
        img.setColor(new Color(120, 20, 24)); img.fillRect(50, 34, W - 100, 26);  // luneta roja
        img.setColor(c); img.fillRect(8, 76, W - 16, 50);
        img.setColor(o); img.fillRect(8, 112, W - 16, 16);
        // parachoques reforzado
        img.setColor(new Color(90, 92, 100)); img.fillRect(4, 120, W - 8, 12);
        img.setColor(new Color(255, 50, 45)); img.fillRect(22, 88, 40, 16); img.fillRect(W - 62, 88, 40, 16);
        // escapes
        img.setColor(new Color(60, 60, 66)); img.fillOval(30, 126, 16, 10); img.fillOval(W - 46, 126, 16, 10);
        img.setColor(Color.BLACK); img.drawRect(8, 76, W - 17, 50);
        return img;
    }

    /** EL TENIENTE: helicoptero ligero (mas chico que los jefes). Base 240x120. */
    public static GreenfootImage heliMini(int fase)
    {
        int W = 240, H = 120;
        GreenfootImage img = new GreenfootImage(W, H);
        Color casco = fase >= 3 ? new Color(110, 34, 40) : fase == 2 ? new Color(64, 56, 62) : new Color(50, 54, 60);
        img.setColor(new Color(35, 35, 40, 150)); img.fillRect(0, 12, W, 6);
        img.setColor(new Color(35, 35, 40, 70));  img.fillRect(0, 7, W, 15);
        img.setColor(mezclar(casco, Color.BLACK, 0.3)); img.fillRect(W - 56, 48, 52, 12);  // cola
        img.setColor(casco); img.fillOval(60, 30, 120, 58);
        img.setColor(mezclar(casco, Color.BLACK, 0.35)); img.fillOval(60, 60, 120, 28);
        img.setColor(new Color(255, 90, 90)); img.fillOval(120, 42, 46, 24);   // cabina
        // ametralladora frontal
        img.setColor(new Color(40, 40, 46)); img.fillRect(96, 78, 30, 7);
        img.setColor(new Color(255, 210, 120, 220)); img.fillOval(84, 76, 12, 12);
        img.setColor(new Color(45, 48, 52)); img.fillRect(80, 92, 100, 5);     // patin
        img.setColor(fase >= 3 ? new Color(255, 200, 60) : new Color(120, 220, 255));
        for (int i = 0; i < 4; i++) img.fillOval(92 + i * 24, 84, 8, 7);
        return img;
    }

    /** Sicario de traje negro, de frente, con arma. Base 80x160, anclado abajo. frame 0/1 mueve el brazo. */
    public static GreenfootImage sicario(int frame)
    {
        int W = 80, H = 160;
        GreenfootImage img = new GreenfootImage(W, H);
        Color traje = new Color(20, 20, 26);

        img.setColor(new Color(0, 0, 0, 80));
        img.fillOval(16, H - 12, 48, 10);

        // piernas
        img.setColor(new Color(14, 14, 18));
        img.fillRect(28, 96, 10, 58);
        img.fillRect(42, 96, 10, 58);

        // torso / saco
        img.setColor(traje);
        img.fillRect(22, 46, 36, 54);
        img.setColor(new Color(230, 230, 235));       // camisa
        img.fillRect(36, 48, 8, 30);
        img.setColor(new Color(150, 30, 40));          // corbata
        img.fillRect(38, 48, 4, 22);

        // brazo con arma apuntando
        img.setColor(traje);
        int by = frame == 0 ? 56 : 60;
        img.fillRect(52, by, 22, 8);
        img.setColor(new Color(40, 40, 46));
        img.fillRect(70, by - 2, 16, 6);
        img.setColor(new Color(255, 210, 120, 200));
        if (frame == 1) img.fillOval(84, by - 4, 10, 10);

        // cabeza + lentes
        img.setColor(new Color(228, 190, 156));
        img.fillOval(30, 24, 22, 22);
        img.setColor(new Color(10, 10, 12));
        img.fillOval(28, 18, 26, 12);                  // pelo
        img.fillRect(31, 32, 20, 5);                   // lentes

        return img;
    }

    /** Farol del separador central del puente. Base 120x360, anclado abajo. */
    public static GreenfootImage faroleMedio()
    {
        GreenfootImage g = new GreenfootImage(120, 360);
        g.setColor(new Color(70, 70, 78));
        g.fillRect(36, 338, 48, 22);                 // base sobre la barrera
        g.setColor(new Color(96, 96, 104));
        g.fillRect(53, 54, 14, 292);                 // poste
        g.fillRect(53, 54, 40, 12);                  // brazo
        g.setColor(new Color(40, 42, 48));
        g.fillRect(84, 52, 20, 12);                  // luminaria
        g.setColor(new Color(255, 238, 150, 120));
        g.fillOval(74, 48, 44, 30);                  // halo
        g.setColor(new Color(255, 240, 180));
        g.fillOval(86, 56, 18, 10);                  // luz
        return g;
    }

    /** Farola / poste de luz del costado. Base 90x300, anclada abajo. */
    public static GreenfootImage farola()
    {
        GreenfootImage img = new GreenfootImage(90, 300);
        img.setColor(new Color(40, 42, 48));
        img.fillRect(38, 40, 14, 260);
        img.fillRect(30, 292, 30, 8);
        img.setColor(new Color(55, 58, 66));
        img.fillRect(38, 34, 40, 12);              // brazo
        img.setColor(new Color(30, 32, 38));
        img.fillRect(70, 26, 18, 22);
        img.setColor(new Color(255, 235, 150, 220));
        img.fillOval(70, 34, 18, 12);
        return img;
    }

    /** Arbol grueso de choque, anclado abajo. Base 180x260. */
    public static GreenfootImage arbolChoque()
    {
        GreenfootImage img = new GreenfootImage(180, 260);
        img.setColor(new Color(70, 50, 32));
        img.fillRect(74, 150, 34, 110);
        img.setColor(new Color(52, 36, 22));
        img.fillRect(74, 150, 12, 110);
        img.setColor(new Color(28, 92, 48));
        img.fillOval(6, 6, 168, 150);
        img.setColor(new Color(20, 74, 40));
        img.fillOval(30, 46, 110, 84);
        img.setColor(new Color(40, 118, 64));
        img.fillOval(24, 14, 70, 56);
        return img;
    }

    /**
     * Helicoptero visto de frente/abajo. Base 220x110.
     * El aspecto cambia segun el modelo: pods laterales, doble rotor
     * y blindaje se van sumando en los modelos avanzados.
     */
    public static GreenfootImage helicoptero(HeliTipo t)
    {
        int W = 220, H = 110;
        GreenfootImage img = new GreenfootImage(W, H);

        Color oscuro = mezclar(t.cuerpo, Color.BLACK, 0.4);

        // rotor principal (linea larga borrosa)
        img.setColor(new Color(40, 40, 45, 170));
        img.fillRect(0, 16, W, 6);
        img.setColor(new Color(40, 40, 45, 90));
        img.fillRect(0, 12, W, 14);

        if (t.dobleRotor) {                 // segundo rotor en tandem
            img.setColor(new Color(40, 40, 45, 140));
            img.fillRect(10, 4, W - 20, 5);
            img.setColor(new Color(40, 40, 45, 70));
            img.fillRect(10, 1, W - 20, 11);
        }

        // mastil
        img.setColor(oscuro);
        img.fillRect(W / 2 - 5, 22, 10, 14);

        // pods lanzacohetes
        if (t.pods) {
            img.setColor(oscuro);
            img.fillRect(W / 2 - 82, 52, 34, 16);
            img.fillRect(W / 2 + 48, 52, 34, 16);
            img.setColor(new Color(230, 120, 60));
            img.fillRect(W / 2 - 82, 56, 6, 8);
            img.fillRect(W / 2 + 76, 56, 6, 8);
        }

        // fuselaje
        img.setColor(t.cuerpo);
        img.fillOval(W / 2 - 46, 32, 92, 52);
        img.setColor(oscuro);
        img.fillOval(W / 2 - 46, 60, 92, 26);

        // placas de blindaje
        if (t.blindaje) {
            img.setColor(mezclar(t.cuerpo, Color.WHITE, 0.18));
            img.fillRect(W / 2 - 40, 46, 80, 8);
            img.fillRect(W / 2 - 34, 68, 68, 6);
            img.setColor(Color.BLACK);
            img.drawRect(W / 2 - 40, 46, 80, 8);
        }

        // cabina
        img.setColor(t.cabina);
        img.fillOval(W / 2 - 30, 40, 60, 30);
        img.setColor(mezclar(t.cabina, Color.BLACK, 0.45));
        img.fillOval(W / 2 - 26, 44, 52, 12);

        // patines
        img.setColor(new Color(45, 48, 50));
        img.fillRect(W / 2 - 54, 92, 108, 6);
        img.fillRect(W / 2 - 30, 84, 6, 10);
        img.fillRect(W / 2 + 24, 84, 6, 10);

        // luz
        img.setColor(new Color(240, 70, 70));
        img.fillOval(W / 2 - 6, 78, 12, 8);

        return img;
    }

    public static GreenfootImage bala()
    {
        GreenfootImage img = new GreenfootImage(30, 30);
        img.setColor(new Color(255, 170, 40));
        img.fillOval(0, 0, 30, 30);
        img.setColor(new Color(255, 240, 160));
        img.fillOval(6, 6, 18, 18);
        img.setColor(new Color(255, 250, 220));
        img.fillOval(10, 10, 10, 10);
        return img;
    }

    public static GreenfootImage balaEnemiga()
    {
        GreenfootImage img = new GreenfootImage(28, 28);
        img.setColor(new Color(255, 90, 90));
        img.fillOval(0, 0, 28, 28);
        img.setColor(new Color(255, 200, 200));
        img.fillOval(9, 9, 10, 10);
        return img;
    }

    public static GreenfootImage cohete()
    {
        GreenfootImage img = new GreenfootImage(40, 60);
        img.setColor(new Color(255, 190, 60));
        img.fillOval(8, 38, 24, 22);
        img.setColor(new Color(235, 235, 240));
        img.fillRect(12, 6, 16, 36);
        img.setColor(new Color(220, 55, 55));
        img.fillOval(10, 0, 20, 16);
        img.setColor(new Color(90, 92, 100));
        img.fillRect(4, 30, 8, 14);
        img.fillRect(28, 30, 8, 14);
        return img;
    }

    public static GreenfootImage explosion()
    {
        int S = 160;
        GreenfootImage img = new GreenfootImage(S, S);
        img.setColor(new Color(255, 120, 30, 230));
        img.fillOval(0, 0, S, S);
        img.setColor(new Color(255, 200, 70, 235));
        img.fillOval(S / 6, S / 6, S * 2 / 3, S * 2 / 3);
        img.setColor(new Color(255, 250, 220, 240));
        img.fillOval(S / 3, S / 3, S / 3, S / 3);
        return img;
    }

    /** Palmera / arbol lateral. Base 120x220, anclado abajo. */
    public static GreenfootImage arbol(Color copa, Color tronco)
    {
        GreenfootImage img = new GreenfootImage(120, 220);
        img.setColor(tronco);
        img.fillRect(52, 90, 16, 130);
        img.setColor(copa);
        img.fillOval(10, 10, 100, 96);
        img.setColor(mezclar(copa, Color.BLACK, 0.3));
        img.fillOval(24, 56, 72, 44);
        return img;
    }

    /** Cartel de ruta, para variar el paisaje. */
    public static GreenfootImage cartel(Color base)
    {
        GreenfootImage img = new GreenfootImage(120, 180);
        img.setColor(new Color(90, 90, 96));
        img.fillRect(54, 80, 12, 100);
        img.setColor(base);
        img.fillRect(6, 10, 108, 74);
        img.setColor(Color.BLACK);
        img.drawRect(6, 10, 108, 74);
        img.setColor(new Color(255, 255, 255, 200));
        img.fillRect(18, 28, 84, 12);
        img.fillRect(18, 50, 60, 12);
        return img;
    }

    /**
     * Decorado del costado propio de cada bioma (palmeras, cactus, pinos
     * nevados, edificios, arboles quemados...). Se dibuja igual que un arbol.
     * Base 160x300, anclada abajo.
     */
    public static GreenfootImage decorLado(String bioma, Color copa, Color tronco)
    {
        GreenfootImage g = new GreenfootImage(160, 300);

        if (bioma.equals("PLAYA") || bioma.equals("SALAR")) {                 // palmera
            g.setColor(new Color(92, 68, 42));
            g.fillRect(74, 120, 14, 180);
            g.setColor(new Color(26, 118, 66));
            for (int k = 0; k < 6; k++) {
                double a = Math.PI + k * (Math.PI / 5);
                int ex = 80 + (int) (Math.cos(a) * 78);
                int ey = 128 + (int) (Math.sin(a) * 48);
                g.fillPolygon(new int[]{80, ex, 80}, new int[]{124, ey, 150}, 3);
            }
            g.setColor(new Color(210, 180, 90));
            g.fillOval(70, 116, 16, 12); g.fillOval(84, 118, 14, 12);
            return g;
        }
        if (bioma.equals("DESIERTO") || bioma.equals("CANON")) {             // cactus
            g.setColor(new Color(40, 120, 60));
            g.fillRect(66, 90, 30, 210);
            g.fillRect(24, 150, 34, 22); g.fillRect(24, 120, 18, 54);
            g.fillRect(104, 175, 34, 22); g.fillRect(120, 140, 18, 58);
            g.setColor(mezclar(new Color(40, 120, 60), Color.BLACK, 0.3));
            g.fillRect(66, 90, 8, 210);
            return g;
        }
        if (bioma.equals("NIEVE") || bioma.equals("CRISTAL") || bioma.equals("AURORA")) {  // pino nevado
            g.setColor(tronco); g.fillRect(72, 240, 16, 60);
            g.setColor(mezclar(copa, Color.BLACK, 0.1));
            g.fillPolygon(new int[]{80, 16, 144}, new int[]{20, 250, 250}, 3);
            g.setColor(Color.WHITE);
            g.fillPolygon(new int[]{80, 34, 126}, new int[]{34, 150, 150}, 3);
            g.fillPolygon(new int[]{80, 48, 112}, new int[]{20, 90, 90}, 3);
            return g;
        }
        if (bioma.equals("VOLCAN") || bioma.equals("INFIERNO") || bioma.equals("LA TORRE")) {  // arbol quemado
            g.setColor(new Color(28, 22, 22));
            g.fillRect(70, 70, 20, 230);
            g.fillPolygon(new int[]{40, 90, 78}, new int[]{120, 120, 40}, 3);
            g.fillPolygon(new int[]{120, 74, 84}, new int[]{110, 110, 30}, 3);
            g.setColor(new Color(255, 120, 40, 200));
            g.fillOval(64, 250, 40, 14);
            return g;
        }
        if (bioma.equals("CIUDAD") || bioma.equals("AUTOPISTA") || bioma.equals("NEON")) {  // edificio
            g.setColor(new Color(50, 52, 64));
            g.fillRect(18, 8, 124, 292);
            g.setColor(bioma.equals("NEON") ? new Color(0, 255, 220, 160) : new Color(255, 230, 150, 170));
            for (int y = 24; y < 290; y += 26)
                for (int x = 30; x < 132; x += 24)
                    if (((x + y) % 3) == 0) g.fillRect(x, y, 10, 12);
            return g;
        }
        if (bioma.equals("ORBITA")) {                                        // antena / panel
            g.setColor(new Color(60, 64, 74)); g.fillRect(74, 90, 10, 210);
            g.setColor(new Color(60, 90, 160));
            g.fillRect(30, 96, 40, 24); g.fillRect(90, 96, 40, 24);
            g.setColor(new Color(150, 200, 255)); g.fillOval(66, 70, 26, 26);
            return g;
        }
        return arbol(copa, tronco);                                          // resto: arbol normal
    }

    /**
     * Animal que cruza la ruta. Vista lateral, base 220x150.
     * frame 0/1 alterna las patas; ave = true dibuja alas en vez de patas.
     */
    public static GreenfootImage animal(Palette p, int frame, boolean miraIzquierda)
    {
        int W = 220, H = 150;
        GreenfootImage img = new GreenfootImage(W, H);
        Color c = p.faunaCuerpo;
        Color d = p.faunaDetalle;

        if (p.faunaVuela) {
            // cuerpo
            img.setColor(c);
            img.fillOval(80, 62, 74, 30);
            img.fillOval(140, 52, 34, 28);          // cabeza
            img.setColor(d);
            img.fillPolygon(new int[]{170, 196, 172}, new int[]{62, 68, 74}, 3);  // pico
            // alas que baten
            img.setColor(c);
            if (frame == 0) {
                img.fillPolygon(new int[]{92, 40, 130}, new int[]{68, 18, 74}, 3);
                img.fillPolygon(new int[]{92, 46, 130}, new int[]{80, 118, 86}, 3);
            } else {
                img.fillPolygon(new int[]{92, 62, 130}, new int[]{68, 46, 74}, 3);
                img.fillPolygon(new int[]{92, 66, 130}, new int[]{80, 96, 86}, 3);
            }
            img.setColor(d);
            img.fillPolygon(new int[]{80, 34, 82}, new int[]{68, 78, 88}, 3);     // cola
        } else {
            // sombra
            img.setColor(new Color(0, 0, 0, 70));
            img.fillOval(46, 132, 130, 14);
            // patas
            img.setColor(d);
            int a = frame == 0 ? 0 : 12;
            img.fillRect(62 + a, 96, 15, 40);
            img.fillRect(94 - a, 96, 15, 40);
            img.fillRect(134 + a, 96, 15, 40);
            img.fillRect(160 - a, 96, 15, 40);
            // cuerpo
            img.setColor(c);
            img.fillOval(52, 52, 132, 58);
            img.fillOval(150, 34, 52, 46);          // cabeza
            img.setColor(d);
            img.fillOval(158, 24, 18, 18);          // oreja
            img.fillOval(184, 26, 16, 16);
            img.fillRect(28, 60, 34, 12);           // cola
            img.setColor(Color.BLACK);
            img.fillOval(178, 48, 8, 8);            // ojo
        }

        if (miraIzquierda) img.mirrorHorizontally();
        return img;
    }

    /** Nave del jefe final. Base 420x200. */
    public static GreenfootImage jefe(int fase)
    {
        int W = 420, H = 200;
        GreenfootImage img = new GreenfootImage(W, H);

        Color casco = fase >= 3 ? new Color(120, 30, 40)
                    : fase == 2 ? new Color(80, 60, 70)
                                : new Color(62, 66, 74);

        // rotores dobles
        img.setColor(new Color(35, 35, 40, 160));
        img.fillRect(10, 22, 180, 7);
        img.fillRect(230, 22, 180, 7);
        img.setColor(new Color(35, 35, 40, 80));
        img.fillRect(10, 16, 180, 19);
        img.fillRect(230, 16, 180, 19);

        // casco principal
        img.setColor(casco);
        img.fillOval(70, 46, 280, 96);
        img.setColor(Sprites.mezclar(casco, Color.BLACK, 0.35));
        img.fillOval(70, 100, 280, 48);
        img.fillRect(150, 30, 120, 26);

        // cabina blindada
        img.setColor(new Color(255, 90, 90));
        img.fillOval(168, 62, 84, 38);
        img.setColor(new Color(120, 20, 30));
        img.fillOval(176, 68, 68, 14);

        // torretas
        img.setColor(new Color(40, 42, 48));
        for (int i = 0; i < 3; i++) {
            int off = 96 + i * 44;
            img.fillRect(210 - off - 16, 108, 34, 14);
            img.fillRect(210 + off - 18, 108, 34, 14);
        }

        // luces de fase
        img.setColor(fase >= 3 ? new Color(255, 200, 60) : new Color(120, 220, 255));
        for (int i = 0; i < 6; i++) img.fillOval(96 + i * 44, 132, 12, 10);

        // patines
        img.setColor(new Color(45, 48, 52));
        img.fillRect(96, 158, 228, 9);
        img.fillRect(140, 146, 9, 14);
        img.fillRect(272, 146, 9, 14);

        return img;
    }

    /**
     * Auto del jugador AVERIADO (vista trasera, base 200x150 como autoTrasero).
     * Se hunde sobre el eje, las ruedas se abren hacia afuera y el aleron
     * cuelga de un lado. Sale humo por el capo.
     */
    public static GreenfootImage autoRoto(Color cuerpo, Color detalle)
    {
        return autoRoto(cuerpo, detalle, 0);
    }

    public static GreenfootImage autoRoto(Color cuerpo, Color detalle, int modelo)
    {
        int W = 200, H = 150;
        GreenfootImage img = new GreenfootImage(W, H);
        Color oscuro = mezclar(cuerpo, Color.BLACK, 0.45);

        img.setColor(new Color(0, 0, 0, 95));
        img.fillOval(2, 134, W - 4, 16);

        if (modelo == 4) {
            // PROTOTIPO Z: no tiene ruedas; se cae de morro con chispas
            img.setColor(new Color(70, 70, 78));
            img.fillPolygon(new int[]{ 4, 40, 30, 0 },   new int[]{ 120, 108, 140, 140 }, 4);
            img.fillPolygon(new int[]{ W - 4, W - 40, W - 30, W }, new int[]{ 120, 108, 140, 140 }, 4);
            img.setColor(new Color(255, 220, 130, 220));
            img.fillOval(30, 128, 10, 8);
            img.fillOval(W - 40, 132, 8, 7);
        } else {
            // ruedas dobladas hacia afuera (paralelogramos inclinados)
            img.setColor(new Color(20, 20, 24));
            img.fillPolygon(new int[]{ -2, 22, 34, 6 },      new int[]{ 104, 98, 140, 148 }, 4);
            img.fillPolygon(new int[]{ W + 2, W - 22, W - 34, W - 6 }, new int[]{ 104, 98, 140, 148 }, 4);
            img.setColor(new Color(80, 82, 90));
            img.fillOval(6, 112, 16, 16);
            img.fillOval(W - 22, 112, 16, 16);
        }

        // carroceria hundida
        img.setColor(cuerpo);
        img.fillRect(16, 98, W - 32, 40);
        img.setColor(oscuro);
        img.fillRect(16, 124, W - 32, 14);

        // cabina ladeada
        img.setColor(cuerpo);
        img.fillPolygon(new int[]{ 46, W - 46, W - 40, 40 }, new int[]{ 52, 44, 92, 92 }, 4);
        img.setColor(new Color(35, 45, 70));
        img.fillPolygon(new int[]{ 56, W - 56, W - 52, 52 }, new int[]{ 56, 49, 80, 82 }, 4);

        // aleron colgando de un lado
        img.setColor(detalle);
        img.fillPolygon(new int[]{ 22, W - 30, W - 30, 22 }, new int[]{ 90, 78, 90, 104 }, 4);

        // luces: una encendida, la otra reventada
        img.setColor(new Color(235, 60, 60));
        img.fillRect(24, 106, 44, 15);
        img.setColor(new Color(70, 35, 35));
        img.fillRect(W - 68, 106, 44, 15);
        img.setColor(new Color(20, 20, 22));
        img.drawLine(W - 66, 108, W - 30, 119);
        img.drawLine(W - 66, 119, W - 30, 108);

        // mancha de humo/quemado en el capo
        img.setColor(new Color(38, 38, 42));
        img.fillOval(146, 40, 30, 24);
        img.setColor(new Color(70, 70, 76));
        img.fillOval(150, 30, 18, 16);

        // detalles rotos propios del modelo
        if (modelo == 3) {                 // PATRULLA X: barra de luces reventada
            img.setColor(new Color(30, 30, 34));
            img.fillRect(66, 22, W - 132, 12);
            img.setColor(new Color(90, 60, 60));
            img.fillRect(70, 24, 28, 8);
            img.setColor(new Color(60, 70, 120));
            img.fillRect(104, 24, 24, 8);
            img.setColor(new Color(20, 20, 22));
            img.drawLine(70, 22, 128, 34);
        } else if (modelo == 1 || modelo == 2) {   // GT / DRIFT: aleron partido en el piso
            img.setColor(mezclar(detalle, Color.BLACK, 0.2));
            img.fillPolygon(new int[]{ W - 74, W - 20, W - 16, W - 70 },
                            new int[]{ 132, 122, 132, 142 }, 4);
        }

        img.setColor(Color.BLACK);
        img.drawRect(16, 98, W - 33, 40);
        return img;
    }

    // Los ocupantes: cada auto lleva su tripulacion (color de pelo + melena).
    // La ropa se tinta a juego con el pelo para que se distingan entre autos.
    private static final Color PIEL_OCU = new Color(234, 198, 164);
    private static Color ropaDe(Color pelo) { return mezclar(pelo, new Color(90, 100, 130), 0.5); }
    private static Color pantDe(Color pelo) { return mezclar(ropaDe(pelo), Color.BLACK, 0.4); }

    /**
     * Persona a pie, vista trasera, cabizbaja y caminando. Base 60x120,
     * anclada abajo. frame 0/1 alterna las piernas.
     */
    public static GreenfootImage persona(int frame, boolean miraIzquierda, Color pelo, boolean melena)
    {
        int W = 60, H = 120;
        GreenfootImage img = new GreenfootImage(W, H);

        img.setColor(new Color(0, 0, 0, 70));
        img.fillOval(10, H - 12, 40, 10);

        int a = frame == 0 ? 6 : -6;
        img.setColor(pantDe(pelo));
        img.fillRect(22 + a, 76, 8, 36);
        img.fillRect(30 - a, 76, 8, 36);

        img.setColor(ropaDe(pelo));
        img.fillRect(17, 42, 26, 38);
        img.fillRect(11, 44, 7, 28);
        img.fillRect(42, 44, 7, 28);

        // cabeza gacha
        img.setColor(PIEL_OCU);
        img.fillOval(20, 28, 20, 20);
        img.setColor(pelo);
        img.fillOval(18, 24, 24, 13);
        if (melena) {
            img.fillRect(17, 30, 6, 20);
            img.fillRect(37, 30, 6, 20);
        }

        if (miraIzquierda) img.mirrorHorizontally();
        return img;
    }

    /**
     * Persona sentada en el suelo, llorando con la cara entre las manos.
     * frame 0/1 le da el temblor del sollozo y mueve las lagrimas.
     */
    public static GreenfootImage personaEnSuelo(int frame, boolean miraIzquierda, Color pelo, boolean melena)
    {
        int W = 74, H = 120;
        GreenfootImage img = new GreenfootImage(W, H);
        int s = frame == 0 ? 0 : 2;

        img.setColor(new Color(0, 0, 0, 80));
        img.fillOval(6, H - 14, 62, 12);

        img.setColor(pantDe(pelo));
        img.fillRect(14, H - 44, 18, 32);
        img.fillRect(42, H - 44, 18, 32);
        img.fillOval(10, H - 52, 24, 24);
        img.fillOval(40, H - 52, 24, 24);

        img.setColor(ropaDe(pelo));
        img.fillRect(21, H - 74 + s, 32, 34);
        img.fillRect(18, H - 70 + s, 9, 22);
        img.fillRect(47, H - 70 + s, 9, 22);

        img.setColor(PIEL_OCU);
        img.fillOval(25, H - 90 + s, 24, 24);
        img.setColor(pelo);
        img.fillOval(22, H - 95 + s, 30, 16);
        if (melena) {
            img.fillRect(21, H - 86 + s, 7, 20);
            img.fillRect(46, H - 86 + s, 7, 20);
        }

        img.setColor(PIEL_OCU);
        img.fillOval(22, H - 78 + s, 13, 13);
        img.fillOval(39, H - 78 + s, 13, 13);

        img.setColor(new Color(150, 205, 255, 235));
        if (frame == 0) {
            img.fillOval(26, H - 62, 4, 9);
            img.fillOval(45, H - 60, 4, 9);
        } else {
            img.fillOval(24, H - 52, 4, 10);
            img.fillOval(47, H - 50, 4, 10);
        }

        if (miraIzquierda) img.mirrorHorizontally();
        return img;
    }

    /** Mezcla dos colores; util para sombras y brillos. */
    public static Color mezclar(Color a, Color b, double f)
    {
        int r = (int) (a.getRed()   * (1 - f) + b.getRed()   * f);
        int g = (int) (a.getGreen() * (1 - f) + b.getGreen() * f);
        int z = (int) (a.getBlue()  * (1 - f) + b.getBlue()  * f);
        return new Color(r, g, z);
    }
}
