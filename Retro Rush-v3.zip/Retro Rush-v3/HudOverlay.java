import greenfoot.*;

/**
 * Capa transparente encima de todo: puntaje, tiempo, velocimetro,
 * energia, barra de NITRO/ULTI, municion, vida del jefe, mensajes
 * y el panel de pausa.
 */
public class HudOverlay extends Actor
{
    private GreenfootImage img;

    public HudOverlay()
    {
        img = new GreenfootImage(GameData.ANCHO, GameData.ALTO);
        setImage(img);
    }

    public void actualizar(RaceWorld w)
    {
        img.clear();
        LevelConfig cfg = w.getConfig();
        PlayerCar j = w.getJugador();

        img.setColor(new Color(0, 0, 0, 140));
        img.fillRect(0, 0, GameData.ANCHO, 44);

        img.setFont(new Font("Monospaced", true, false, 19));
        img.setColor(Color.WHITE);
        if (GameData.modoChallenge) {
            img.setColor(new Color(255, 190, 90));
            img.drawString("CHALLENGE  V" + (GameData.vuelta + 1)
                           + "-" + cfg.nivel + "  " + cfg.paleta.nombre, 12, 28);
            img.setColor(Color.WHITE);
        } else {
            img.drawString("NIVEL " + cfg.nivel + "/" + GameData.NIVEL_MAX
                           + "  " + cfg.paleta.nombre, 12, 28);
        }
        img.drawString("PTS " + GameData.puntajeCarrera, 300, 28);
        img.drawString("T " + GameData.formatoTiempo(GameData.tiempoActualMs()), 452, 28);
        img.setColor(new Color(255, 190, 90));
        img.drawString(cfg.heli.nombre, 600, 28);
        if (!GameData.mejorasElegidas.isEmpty()) {
            img.setColor(new Color(190, 140, 255));
            img.drawString("+" + GameData.mejorasElegidas.size(), 748, 28);
        }

        double p = GameData.modoChallenge
                 ? w.getFramesTramo() / (double) GameData.FRAMES_POR_TRAMO
                 : Math.min(1.0, w.getDistancia() / cfg.distanciaObjetivo);
        p = Math.min(1.0, p);
        img.setColor(new Color(255, 255, 255, 70));
        img.fillRect(12, 50, GameData.ANCHO - 24, 8);
        img.setColor(new Color(90, 230, 130));
        img.fillRect(12, 50, (int) ((GameData.ANCHO - 24) * p), 8);

        dibujarReloj(w);
        if (w.getJefe() != null) barraJefe(w.getJefe());
        dibujarAviso(w);

        dibujarVelocimetro(w);

        if (j != null) {
            int emax = j.getEnergiaMax();
            barra(12, GameData.ALTO - 80, 210, 18, j.getEnergia() / (double) emax,
                  colorEnergia(j.getEnergia() * 100 / Math.max(1, emax)),
                  "ENERGIA " + j.getEnergia() + "/" + emax);

            String etiqueta;
            Color colorUlti;
            String ultiN = GameData.auto().ultiNombre();
            if (j.ultiTemporalActiva())  { etiqueta = ultiN + "!!";      colorUlti = new Color(255, 230, 120); }
            else if (j.nitroEncendido()) { etiqueta = "NITRO!!";         colorUlti = new Color(120, 220, 255); }
            else if (j.getUlti() >= 100) { etiqueta = ultiN + "  (X)";   colorUlti = new Color(255, 120, 60); }
            else                         { etiqueta = "NITRO / " + ultiN; colorUlti = new Color(255, 190, 40); }
            barra(12, GameData.ALTO - 56, 210, 18, j.getUlti() / 100.0, colorUlti, etiqueta);

            dibujarMunicion(j);
        }

        if (w.isPausa()) {
            panelPausa();
        } else if (w.getIntroTimer() > 0) {
            mensajeCentral("NIVEL " + cfg.nivel, cfg.paleta.nombre);
        } else if (w.getEstado() == 3 && w.getJefe() != null) {
            Boss b = w.getJefe();
            if (b.entrando())
                mensajeCentral(b.nombre(), "DERRIBALO");
        } else if (w.getEstado() == 1) {
            boolean ultimo = GameData.nivelActual >= GameData.NIVEL_MAX;
            mensajeCentral(ultimo ? "EL DON CAYO" : "NIVEL SUPERADO",
                           ultimo ? "FINAL" : "SIGUIENTE NIVEL");
        } else if (w.getEstado() == 2 && w.getContador() < 150) {
            String comoMoriste = (j != null) ? j.nombreMuerte() : "DESTRUIDO";
            mensajeCentral(comoMoriste, "PUNTAJE " + GameData.puntajeCarrera);
        }
    }

    /** Cuenta atras del nivel. Parpadea en rojo en los ultimos 10 segundos. */
    private void dibujarReloj(RaceWorld w)
    {
        if (GameData.modoChallenge) { dibujarSupervivencia(); return; }

        int frames = Math.max(0, w.getTiempoRestante());
        int seg = frames / 50;
        boolean critico = seg <= 10;

        String txt = String.format("%01d:%02d", seg / 60, seg % 60);
        int x = GameData.ANCHO / 2 - 46;

        img.setColor(new Color(0, 0, 0, 165));
        img.fillRect(x - 10, 64, 112, 34);

        img.setFont(new Font("Monospaced", true, false, 28));
        if (critico && (frames / 12) % 2 == 0) img.setColor(new Color(255, 80, 80));
        else if (critico)                      img.setColor(new Color(255, 190, 190));
        else                                   img.setColor(Color.WHITE);
        img.drawString(txt, x, 90);

        double p = frames / (double) Math.max(1, w.getTiempoLimite());
        img.setColor(new Color(255, 255, 255, 55));
        img.fillRect(x - 8, 100, 108, 6);
        img.setColor(critico ? new Color(255, 80, 80) : new Color(120, 210, 255));
        img.fillRect(x - 8, 100, (int) (108 * Math.min(1, p)), 6);
    }

    /** En challenge el reloj sube: la gracia es aguantar lo mas posible. */
    private void dibujarSupervivencia()
    {
        String txt = GameData.formatoTiempo(GameData.tiempoActualMs());
        int x = GameData.ANCHO / 2 - 62;

        img.setColor(new Color(0, 0, 0, 165));
        img.fillRect(x - 12, 64, 150, 40);

        img.setFont(new Font("Monospaced", true, false, 13));
        img.setColor(new Color(255, 190, 90));
        img.drawString("SOBREVIVIENDO", x, 78);

        img.setFont(new Font("Monospaced", true, false, 26));
        img.setColor(Color.WHITE);
        img.drawString(txt, x, 100);
    }

    /**
     * Flecha de advertencia en el carril donde va a aparecer un auto
     * que viene por detras. Sin esto salen de la nada.
     */
    private void dibujarAviso(RaceWorld w)
    {
        int carril = w.getAvisoCarril();
        if (carril < 0) return;
        if ((w.getAvisoTimer() / 6) % 2 != 0) return;      // parpadeo

        int cx = Camara.px(Camara.centroCarril(carril), Camara.Z_JUGADOR);
        int cy = GameData.ALTO - 150;

        img.setColor(new Color(255, 60, 60, 220));
        int[] xs = { cx, cx - 34, cx + 34 };
        int[] ys = { cy - 34, cy + 18, cy + 18 };
        img.fillPolygon(xs, ys, 3);

        img.setColor(Color.WHITE);
        img.setFont(new Font("Monospaced", true, false, 22));
        img.drawString("!", cx - 6, cy + 14);

        img.setFont(new Font("Monospaced", true, false, 18));
        img.setColor(new Color(255, 120, 120));
        img.drawString("AUTO POR DETRAS", cx - 92, cy + 46);
    }

    /** Balas disponibles, como cartuchos. */
    private void dibujarMunicion(PlayerCar j)
    {
        int x = 12, y = GameData.ALTO - 32;

        img.setFont(new Font("Monospaced", true, false, 13));
        img.setColor(Color.WHITE);
        img.drawString(j.estaRecargando() ? "RECARGANDO" : "BALAS", x, y + 13);

        if (j.estaRecargando()) {
            img.setColor(new Color(255, 255, 255, 60));
            img.fillRect(x + 106, y + 2, 104, 12);
            img.setColor(new Color(255, 190, 60));
            img.fillRect(x + 106, y + 2, (int) (104 * j.progresoRecarga()), 12);
            return;
        }

        int bmax = j.getBalasMax();
        int w = bmax > 8 ? 8 : 12;        // cartuchos mas finos si hay muchos
        for (int i = 0; i < bmax; i++) {
            boolean tiene = i < j.getBalas();
            img.setColor(tiene ? new Color(255, 225, 120) : new Color(255, 255, 255, 45));
            img.fillRect(x + 66 + i * (w + 2), y + 2, w - 1, 13);
        }
    }

    private void barraJefe(Boss b)
    {
        int an = 560, x = (GameData.ANCHO - an) / 2, y = 112;

        img.setColor(new Color(0, 0, 0, 180));
        img.fillRect(x - 8, y - 24, an + 16, 46);

        img.setFont(new Font("Monospaced", true, false, 16));
        img.setColor(Color.WHITE);
        img.drawString(b.nombre() + "   fase " + b.getFase(), x, y - 8);
        img.setColor(new Color(255, 180, 180));
        img.drawString(b.getVida() + " / " + b.getVidaMax(), x + an - 120, y - 8);

        img.setColor(new Color(255, 255, 255, 60));
        img.fillRect(x, y, an, 12);
        img.setColor(b.getFase() >= 3 ? new Color(255, 200, 60) : new Color(230, 60, 60));
        img.fillRect(x, y, (int) (an * b.getVida() / (double) Math.max(1, b.getVidaMax())), 12);
        img.setColor(Color.BLACK);
        img.drawRect(x, y, an, 12);
    }

    private void dibujarVelocimetro(RaceWorld w)
    {
        int kmh = (int) (w.getVelocidad() * 1.35);
        double p = Math.min(1.0, w.getVelocidad() / (w.velocidadObjetivo() + 40));
        double acc = w.getAceleracion();

        int x = GameData.ANCHO - 216, y = GameData.ALTO - 68;

        img.setColor(new Color(0, 0, 0, 150));
        img.fillRect(x - 4, y - 4, 208, 56);

        img.setFont(new Font("Monospaced", true, false, 32));
        if (acc < -0.25)      img.setColor(new Color(255, 110, 90));   // frenando
        else if (acc > 0.25)  img.setColor(new Color(140, 255, 180));  // acelerando
        else if (p > 0.85)    img.setColor(new Color(140, 255, 180));
        else                  img.setColor(Color.WHITE);
        img.drawString(kmh + " km/h", x + 6, y + 28);

        img.setFont(new Font("Monospaced", true, false, 22));
        if (acc < -0.25)     img.drawString("v", x + 176, y + 26);
        else if (acc > 0.25) img.drawString("^", x + 176, y + 26);

        img.setColor(new Color(255, 255, 255, 60));
        img.fillRect(x, y + 36, 200, 10);
        img.setColor(new Color(255, 120 + (int) (p * 100), 60));
        img.fillRect(x, y + 36, (int) (200 * p), 10);
    }

    private void panelPausa()
    {
        img.setColor(new Color(0, 0, 0, 200));
        img.fillRect(0, 0, GameData.ANCHO, GameData.ALTO);

        img.setColor(new Color(250, 205, 40));
        img.setFont(new Font("Monospaced", true, false, 46));
        img.drawString("PAUSA", centrado("PAUSA", 46), 120);

        // con MODO ADMIN el panel tiene 2 botones extra: bajamos lo de abajo
        int off = GameData.adminMenu ? 26 : 0;

        // ---- SONIDO: dos barras que se arrastran ----
        pausaSlider("MUSICA",  Sonido.volMusica,  388 + off);
        pausaSlider("EFECTOS", Sonido.volEfectos, 432 + off);

        // ---- CONTROLES ----
        img.setFont(new Font("Monospaced", true, false, 14));
        img.setColor(new Color(255, 220, 120));
        img.drawString("CONTROLES", GameData.ANCHO / 2 - 210, 484 + off);
        img.setFont(new Font("Monospaced", false, false, 13));
        img.setColor(new Color(210, 210, 220));
        String[] c = {
            "FLECHAS / A D  cambiar de carril      ARRIBA / W  saltar",
            "SPACE  disparar     X  ULTI del auto     SHIFT  turbo",
            "P / ESC  pausa     M  silenciar     R  reiniciar     Q  menu",
        };
        for (int i = 0; i < c.length; i++)
            img.drawString(c[i], GameData.ANCHO / 2 - 210, 504 + off + i * 20);
    }

    private void pausaSlider(String etiqueta, int valor, int y)
    {
        int x = GameData.ANCHO / 2 - 150, w = 300;
        img.setFont(new Font("Monospaced", true, false, 15));
        img.setColor(Color.WHITE);
        img.drawString(etiqueta + "  " + valor + "%", x, y - 12);
        img.setColor(new Color(255, 255, 255, 50));
        img.fillRect(x, y, w, 12);
        img.setColor(new Color(120, 210, 255));
        img.fillRect(x, y, (int) (w * valor / 100.0), 12);
        int kx = x + (int) (w * valor / 100.0);
        img.setColor(new Color(250, 205, 40));
        img.fillRect(kx - 6, y - 8, 12, 28);
        img.setColor(Color.BLACK);
        img.drawRect(kx - 6, y - 8, 12, 28);
    }

    private Color colorEnergia(int e)
    {
        if (e > 60) return new Color(90, 220, 110);
        if (e > 30) return new Color(240, 190, 60);
        return new Color(235, 70, 70);
    }

    private void barra(int x, int y, int an, int al, double p, Color color, String texto)
    {
        img.setColor(new Color(0, 0, 0, 150));
        img.fillRect(x - 2, y - 2, an + 4, al + 4);
        img.setColor(new Color(255, 255, 255, 60));
        img.fillRect(x, y, an, al);
        img.setColor(color);
        img.fillRect(x, y, (int) (an * Math.max(0, Math.min(1, p))), al);
        img.setColor(Color.WHITE);
        img.setFont(new Font("Monospaced", true, false, 13));
        img.drawString(texto, x + 6, y + 14);
    }

    private void mensajeCentral(String titulo, String sub)
    {
        img.setColor(new Color(0, 0, 0, 160));
        img.fillRect(0, 230, GameData.ANCHO, 130);
        img.setColor(Color.WHITE);
        // titulo: achica la fuente si el nombre es largo (algunas muertes lo son)
        int tam = titulo.length() > 22 ? 22 : titulo.length() > 15 ? 32 : 50;
        img.setFont(new Font("Monospaced", true, false, tam));
        img.drawString(titulo, centrado(titulo, tam), 292);
        img.setFont(new Font("Monospaced", true, false, 22));
        img.drawString(sub, centrado(sub, 22), 332);
    }

    private int centrado(String s, int tam)
    {
        return GameData.ANCHO / 2 - (int) (s.length() * tam * 0.30);
    }
}
