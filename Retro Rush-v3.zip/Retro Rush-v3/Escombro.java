import greenfoot.*;

/**
 * Prop estatico en la ruta (un arbol contra el que chocas, un poste, etc.).
 * Solo se proyecta; no se mueve. Se limpia solo al cambiar de mundo.
 */
public class Escombro extends Objeto3D
{
    public Escombro(GreenfootImage sprite, double x, double z, double anchoMundo, double altoMundo)
    {
        this.x = x;
        this.z = z;
        this.altura = 0;
        inicializar(sprite, anchoMundo, altoMundo);
    }

    public void act()
    {
        if (getWorld() == null) return;
        proyectar();
    }
}
