import greenfoot.*;

/**
 * Camara pseudo-3D estilo Out Run.
 *
 * El mundo usa 3 coordenadas:
 *   x      = desplazamiento lateral (0 = centro de la ruta)
 *   altura = altura sobre el asfalto (0 = suelo)
 *   z      = profundidad, cuanto mas lejos hacia el horizonte
 *
 * La camara esta en z = 0, a una altura ALTURA, mirando hacia z positivo.
 * La proyeccion es la clasica division por la distancia:
 *
 *   escala   = FOCAL / z
 *   pantallaX = centro + (x - camX) * escala
 *   pantallaY = HORIZONTE + (ALTURA - altura) * escala
 *
 * SENSACION DE VELOCIDAD
 * ----------------------
 * Tres cosas se mueven con la velocidad, y todas de golpe cuando frenas
 * o metes turbo:
 *   - FOCAL   : mas velocidad -> mas gran angular (el mundo se abre y pasa
 *               volando). Un frenazo la sube de golpe: efecto "zoom".
 *   - ALTURA  : a toda velocidad la camara baja un poco, pega al asfalto.
 *   - sacudida: golpes puntuales (choques) que hacen temblar TODO el cuadro.
 */
public class Camara
{
    /** Linea del horizonte en pixeles. */
    public static final int HORIZONTE = 235;

    /** Distancia focal dinamica (ver arriba). */
    public static double FOCAL = 280;
    public static final double FOCAL_BASE = 280;

    /** Altura de la camara sobre el asfalto (tambien dinamica). */
    public static double ALTURA = 900;
    public static final double ALTURA_BASE = 900;

    public static final int    CARRILES     = 4;
    public static final double ANCHO_CARRIL = 600;
    public static final double SEMI_RUTA    = ANCHO_CARRIL * CARRILES / 2.0;

    /** Profundidad fija a la que se dibuja el auto del jugador. */
    public static final double Z_JUGADOR = 820;

    /** Desplazamiento lateral de la camara (lo que lee todo el dibujo). */
    public static double camX = 0;

    /** Posicion suave que persigue al jugador, sin el temblor encima. */
    private static double seguido = 0;

    /** Temblor de camara: magnitud y frames que le quedan. */
    private static double sacudida = 0;
    private static int    sacudidaT = 0;

    public static void reset()
    {
        camX = 0;
        seguido = 0;
        sacudida = 0;
        sacudidaT = 0;
        FOCAL = FOCAL_BASE;
        ALTURA = ALTURA_BASE;
    }

    /**
     * Ajusta campo de vision y altura segun la velocidad.
     * Responde rapido (0.16) para que un cambio brusco se note en el acto.
     */
    public static void ajustarPorVelocidad(double velocidad)
    {
        double t = velocidad / 260.0;
        if (t < 0) t = 0;
        if (t > 1) t = 1;

        double objFocal  = 302 - t * 104;          // 302 (parado) -> 198 (a fondo)
        double objAltura = ALTURA_BASE - t * 52;    // baja hasta ~52 px al maximo

        FOCAL  += (objFocal  - FOCAL)  * 0.16;
        ALTURA += (objAltura - ALTURA) * 0.10;
    }

    /**
     * Golpe instantaneo a la focal. Positivo = "zoom" (frenazo, choque),
     * negativo = se abre de golpe (turbo). Vuelve sola con ajustarPorVelocidad.
     */
    public static void golpeFocal(double delta)
    {
        FOCAL += delta;
        if (FOCAL < 168) FOCAL = 168;
        if (FOCAL > 344) FOCAL = 344;
    }

    /** Dispara un temblor de camara (choques, explosiones cerca). */
    public static void sacudir(double fuerza)
    {
        if (fuerza > sacudida) sacudida = fuerza;
        int frames = (int) (10 + fuerza * 0.9);
        if (frames > sacudidaT) sacudidaT = frames;
    }

    /** La camara persigue al jugador y aplica el temblor encima. */
    public static void seguir(double xJugador)
    {
        seguido += (xJugador - seguido) * 0.10;

        double off = 0;
        if (sacudidaT > 0) {
            sacudidaT--;
            sacudida *= 0.84;
            off = Math.sin(sacudidaT * 1.9) * sacudida;
            if (sacudidaT == 0) sacudida = 0;
        }
        camX = seguido + off;
    }

    public static double escala(double z)
    {
        if (z < 150) z = 150;
        return FOCAL / z;
    }

    public static int px(double x, double z)
    {
        return (int) Math.round(GameData.ANCHO / 2.0 + (x - camX) * escala(z));
    }

    public static int py(double altura, double z)
    {
        return (int) Math.round(HORIZONTE + (ALTURA - altura) * escala(z));
    }

    /** Centro del carril indicado (0 = el de mas a la izquierda). */
    public static double centroCarril(int c)
    {
        return -SEMI_RUTA + ANCHO_CARRIL * c + ANCHO_CARRIL / 2.0;
    }
}
