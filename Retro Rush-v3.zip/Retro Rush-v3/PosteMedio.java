import greenfoot.*;

/**
 * Farol del separador central de las autopistas de doble calzada (puentes).
 * Se planta en el medio (x = 0), viene hacia el jugador con el scroll y es
 * CHOCABLE: hay que esquivarlo o saltarlo. Lo gestiona PlayerCar.
 */
public class PosteMedio extends Objeto3D
{
    public PosteMedio(double z)
    {
        this.x = 0;
        this.altura = 0;
        this.z = z;
        inicializar(Sprites.faroleMedio(), 240, 1400);
    }

    public void act()
    {
        RaceWorld w = (RaceWorld) getWorld();
        if (w == null || w.congelado()) return;

        z -= w.getVelocidad();
        if (z < 180) { w.removeObject(this); return; }

        proyectar();
    }
}
