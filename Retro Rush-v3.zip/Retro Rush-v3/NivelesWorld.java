import greenfoot.*;

/**
 * Menu oculto de seleccion de nivel (modo admin). CLICK en un numero -> empieza
 * una partida de campana desde ese nivel. Los niveles 5/15/25/35 son mini-jefes,
 * 10/20/30 jefes con nombre y 40 el jefe final.
 */
public class NivelesWorld extends World
{
    private MenuButton volver;
    private int hover = -1;

    private static final int COLS = 8;
    private static final int CW = 90, CH = 46, GAP = 8;
    private static final int X0 = (GameData.ANCHO - (COLS * CW + (COLS - 1) * GAP)) / 2;
    private static final int Y0 = 130;

    public NivelesWorld()
    {
        super(GameData.ANCHO, GameData.ALTO, 1);
        Sonido.pararMotor();
        Sonido.musica("musica_menu.wav");
        volver = new MenuButton("VOLVER", "back", 170, 48);
        addObject(volver, 105, GameData.ALTO - 34);
        dibujar();
    }

    public void act()
    {
        if (volver.fueClickeado()) { Greenfoot.setWorld(new MenuWorld()); return; }

        MouseInfo m = Greenfoot.getMouseInfo();
        int nh = (m != null) ? celda(m.getX(), m.getY()) : -1;
        if (nh != hover) { hover = nh; dibujar(); }

        if (Greenfoot.mouseClicked(null) && hover >= 1) {
            GameData.nuevaPartida(false);
            GameData.nivelActual = hover;
            GameData.runAdmin = true;
            Sonido.efecto("boton.wav");
            Greenfoot.setWorld(new RaceWorld());
        }
        if ("escape".equals(Greenfoot.getKey())) Greenfoot.setWorld(new MenuWorld());
    }

    private int celda(int mx, int my)
    {
        for (int i = 0; i < GameData.NIVEL_MAX; i++) {
            int cx = X0 + (i % COLS) * (CW + GAP);
            int cy = Y0 + (i / COLS) * (CH + GAP);
            if (mx >= cx && mx <= cx + CW && my >= cy && my <= cy + CH) return i + 1;
        }
        return -1;
    }

    private void dibujar()
    {
        GreenfootImage f = getBackground();
        f.setColor(new Color(16, 16, 24));
        f.fill();
        f.setColor(new Color(26, 24, 38));
        for (int y = 0; y < GameData.ALTO; y += 26) f.fillRect(0, y, GameData.ANCHO, 12);

        f.setFont(new Font("Monospaced", true, false, 36));
        f.setColor(new Color(250, 205, 40));
        f.drawString("NIVELES", 40, 60);
        f.setFont(new Font("Monospaced", true, false, 13));
        f.setColor(Color.WHITE);
        f.drawString("MODO ADMIN  -  empieza desde el nivel que quieras", 40, 88);

        for (int i = 0; i < GameData.NIVEL_MAX; i++) {
            int n = i + 1;
            int cx = X0 + (i % COLS) * (CW + GAP);
            int cy = Y0 + (i / COLS) * (CH + GAP);
            boolean h = (hover == n);
            int cat = categoria(n);

            f.setColor(new Color(0, 0, 0, 150));
            f.fillRect(cx + 3, cy + 4, CW, CH);
            f.setColor(h ? new Color(255, 235, 100)
                        : cat == 4 ? new Color(120, 24, 30)
                        : cat == 3 ? new Color(120, 60, 30)
                        : cat >= 1 ? new Color(70, 50, 90)
                        : new Color(34, 34, 48));
            f.fillRect(cx, cy, CW, CH);
            f.setColor(cat >= 1 ? new Color(255, 120, 100) : new Color(110, 110, 140));
            f.drawRect(cx, cy, CW, CH);

            f.setFont(new Font("Monospaced", true, false, 22));
            f.setColor(h ? new Color(20, 20, 24) : Color.WHITE);
            f.drawString((n < 10 ? " " : "") + n, cx + 20, cy + 30);

            if (cat >= 1) {
                f.setFont(new Font("Monospaced", true, false, 9));
                f.setColor(h ? new Color(30, 20, 20) : new Color(255, 160, 150));
                f.drawString(nombreJefe(n), cx + 6, cy + CH - 5);
            }
        }

        f.setFont(new Font("Monospaced", false, false, 12));
        f.setColor(new Color(150, 150, 160));
        f.drawString("5/15/25/35 mini-jefe   10 SOLDADO   20 SICARIO   30 CAPO   40 EL DON", 240, GameData.ALTO - 26);
    }

    /** 0 nada, 1 mini, 2 SOLDADO, 3 SICARIO/CAPO..., 4 final. */
    private int categoria(int n)
    {
        if (n >= GameData.NIVEL_MAX) return 4;
        if (n == 30) return 3;
        if (n == 10 || n == 20) return 2;
        if (n % GameData.NIVELES_POR_JEFE == 0) return 1;
        return 0;
    }

    private String nombreJefe(int n)
    {
        if (n >= GameData.NIVEL_MAX) return "EL DON";
        if (n == 10) return "SOLDADO";
        if (n == 20) return "SICARIO";
        if (n == 30) return "CAPO";
        if (n == 5)  return "RECLUTA";
        if (n == 15) return "PUNTERO";
        if (n == 25) return "COBRADOR";
        if (n == 35) return "TENIENTE";
        return "MINI";
    }
}
