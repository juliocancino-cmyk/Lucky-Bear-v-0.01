import greenfoot.GreenfootSound;
import java.util.HashMap;
import java.util.Map;
import java.io.*;

/**
 * Audio del juego. Los .wav viven en la carpeta "sounds".
 *
 *  - efecto(nombre)          -> efecto corto (con voces solapadas y anti-spam)
 *  - musica(nombre)          -> pista en bucle (no reinicia si ya suena esa)
 *  - pararMusica()           -> corta la pista
 *  - motor(intensidad,nitro) -> bucle del motor, volumen segun la velocidad
 *  - pararMotor()            -> corta el motor
 *  - alternar()              -> silencia / reactiva todo (tecla M)
 *  - pausar()/reanudar()     -> menu de pausa o barra de Greenfoot
 */
public class Sonido
{
    /** Interruptor general. La tecla M lo alterna. */
    public static boolean activado = true;

    /** Volumen 0..100 (ajustable desde AJUSTES > SONIDO). */
    public static int volMusica  = 55;
    public static int volEfectos = 72;
    private static final String CONFIG = "config.txt";

    static {
        try {
            File f = new File(CONFIG);
            if (f.exists()) {
                BufferedReader br = new BufferedReader(new FileReader(f));
                String l = br.readLine();
                br.close();
                if (l != null) {
                    String[] p = l.trim().split(" ");
                    if (p.length >= 1) volMusica  = clamp(Integer.parseInt(p[0]));
                    if (p.length >= 2) volEfectos = clamp(Integer.parseInt(p[1]));
                }
            }
        } catch (Exception ignorada) {}
    }

    private static int clamp(int v) { return v < 0 ? 0 : (v > 100 ? 100 : v); }

    private static void guardarConfig()
    {
        try {
            PrintWriter pw = new PrintWriter(new FileWriter(CONFIG));
            pw.println(volMusica + " " + volEfectos);
            pw.close();
        } catch (Exception ignorada) {}
    }

    /** Fija el volumen de musica (0..100) y lo guarda. */
    public static void fijarMusica(int v)
    {
        int nv = clamp(v);
        if (nv == volMusica) return;
        volMusica = nv;
        if (musicaSonido != null) musicaSonido.setVolume(volMusica);
        guardarConfig();
    }

    public static void fijarEfectos(int v)
    {
        int nv = clamp(v);
        if (nv == volEfectos) return;
        volEfectos = nv;
        for (GreenfootSound[] voces : efectos.values())
            for (GreenfootSound s : voces) if (s != null) s.setVolume(volEfectos);
        guardarConfig();
    }

    /** Copias de cada efecto para poder solaparlas (disparos, tics). */
    private static final int VOCES = 3;

    private static final Map<String, GreenfootSound[]> efectos   = new HashMap<String, GreenfootSound[]>();
    private static final Map<String, Integer>          turno     = new HashMap<String, Integer>();
    private static final Map<String, Long>             ultimoUso = new HashMap<String, Long>();

    private static GreenfootSound musicaSonido;
    private static String musicaActual;

    private static GreenfootSound motorSonido;
    private static boolean motorSonando = false;

    private static boolean pausado = false;

    // ------------------------------------------------------------------
    // EFECTOS
    // ------------------------------------------------------------------
    public static void efecto(String archivo)
    {
        if (!activado || pausado || archivo == null) return;

        // anti-spam: si el mismo efecto se pidio hace nada, lo ignoramos.
        // Los choques se disparan en rafaga y se pisaban entre si (distorsion).
        long ahora = System.currentTimeMillis();
        long minGap = archivo.startsWith("choque") || archivo.startsWith("impacto")
                    || archivo.startsWith("explosion") ? 200 : 55;
        Long prev = ultimoUso.get(archivo);
        if (prev != null && ahora - prev < minGap) return;
        ultimoUso.put(archivo, ahora);

        GreenfootSound[] voces = efectos.get(archivo);
        if (voces == null) {
            voces = new GreenfootSound[VOCES];
            for (int i = 0; i < VOCES; i++) voces[i] = cargar(archivo);
            if (voces[0] == null) return;
            efectos.put(archivo, voces);
            turno.put(archivo, 0);
        }

        int i = turno.get(archivo);
        turno.put(archivo, (i + 1) % VOCES);

        GreenfootSound s = voces[i];
        if (s == null) return;
        s.stop();
        s.setVolume(volEfectos);
        s.play();
    }

    // ------------------------------------------------------------------
    // MUSICA
    // ------------------------------------------------------------------
    public static void musica(String archivo)
    {
        if (archivo == null) return;

        // pedir musica = ya no estamos pausados (arregla el audio que
        // desaparecia al reiniciar un nivel desde el menu de pausa).
        pausado = false;

        if (archivo.equals(musicaActual) && musicaSonido != null && musicaSonido.isPlaying())
            return;

        pararMusica();
        musicaActual = archivo;
        musicaSonido = cargar(archivo);
        if (musicaSonido == null) { musicaActual = null; return; }

        musicaSonido.setVolume(volMusica);
        if (activado) musicaSonido.playLoop();
    }

    public static void pararMusica()
    {
        if (musicaSonido != null) musicaSonido.stop();
        musicaSonido = null;
        musicaActual = null;
    }

    // ------------------------------------------------------------------
    // MOTOR — desactivado a proposito: el loop del motor sonaba a estatica
    // y cansaba. El turbo se marca solo con el efecto "turbo.wav".
    // ------------------------------------------------------------------
    private static boolean turboPrev = false;

    public static void motor(double intensidad, boolean nitro)
    {
        if (nitro && !turboPrev) efecto("turbo.wav");
        turboPrev = nitro;
    }

    public static void pararMotor()
    {
        turboPrev = false;
        if (motorSonido != null) motorSonido.stop();
        motorSonando = false;
    }

    // ------------------------------------------------------------------
    // SILENCIO GLOBAL (tecla M)
    // ------------------------------------------------------------------
    public static void alternar()
    {
        activado = !activado;
        if (activado) {
            if (musicaSonido != null && !pausado) musicaSonido.playLoop();
        } else {
            if (musicaSonido != null) musicaSonido.pause();
            pararMotor();
        }
    }

    // ------------------------------------------------------------------
    // PAUSA
    // ------------------------------------------------------------------
    public static void pausar()
    {
        pausado = true;
        if (musicaSonido != null) musicaSonido.pause();
        if (motorSonido != null)  motorSonido.pause();
        motorSonando = false;
    }

    public static void reanudar()
    {
        pausado = false;
        if (activado && musicaSonido != null) musicaSonido.playLoop();
    }

    // ------------------------------------------------------------------
    private static GreenfootSound cargar(String archivo)
    {
        try {
            return new GreenfootSound(archivo);
        } catch (Exception ex) {
            System.out.println("No se pudo cargar el sonido: " + archivo
                               + " (" + ex.getMessage() + ")");
            return null;
        }
    }
}
