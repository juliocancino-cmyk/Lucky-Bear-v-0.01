import greenfoot.*;

/**
 * Nave que se lleva el auto en las muertes OVNI (platillo) y GARRA
 * (helicoptero). Baja desde muy arriba, espera un momento y sube.
 * El movimiento del auto lo hace PlayerCar; esto es solo el visual.
 *
 * No se congela con el mundo.
 */
public class Ovni extends Objeto3D
{
    private final int tipo;   // 0 platillo, 1 helicoptero-garra
    private int fase = 0, espera = 0, t = 0;

    public Ovni(int tipo, double x)
    {
        this.tipo = tipo;
        this.x = x;
        this.z = Camara.Z_JUGADOR - 60;
        this.altura = 4600;
        if (tipo == 0) inicializar(Sprites.ovni(), 1500, 750);
        else           inicializar(Sprites.helicoptero(HeliTipo.paraNivel(20)), 1300, 650);
    }

    public void act()
    {
        RaceWorld w = (RaceWorld) getWorld();
        if (w == null) return;
        t++;

        if (fase == 0) {
            altura += (360 - altura) * 0.06;
            if (altura < 470) { fase = 1; espera = 40; }
        } else if (fase == 1) {
            altura += Math.sin(t * 0.3) * 3;          // flota
            if (--espera <= 0) fase = 2;
        } else {
            altura += 40;
            if (altura > 5200) { w.removeObject(this); return; }
        }

        // haz tractor
        if (fase >= 1 && t % 3 == 0)
            w.addObject(new Explosion(x + Greenfoot.getRandomNumber(160) - 80,
                                      altura - 260, z, 200), -500, -500);
        proyectar();
    }
}
