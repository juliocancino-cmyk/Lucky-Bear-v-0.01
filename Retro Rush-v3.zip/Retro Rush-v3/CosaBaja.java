import greenfoot.*;

/**
 * Algo que BAJA del cielo, se queda un rato flotando y despues sube (a veces
 * llevandose el auto): platillos, garras de helicoptero, gruas, dirigibles,
 * drones, brazos roboticos... El movimiento del auto lo hace PlayerCar.
 * No se congela con el mundo.
 */
public class CosaBaja extends Objeto3D
{
    private int fase = 0, espera, t = 0;
    private final int esperaTotal;
    private final boolean sube;
    private final double alturaFlote;

    public CosaBaja(GreenfootImage sp, double x, double w, double h,
                    double alturaFlote, int espera, boolean sube)
    {
        this.x = x;
        this.z = Camara.Z_JUGADOR - 60;
        this.altura = 4800;
        this.alturaFlote = alturaFlote;
        this.esperaTotal = espera;
        this.espera = espera;
        this.sube = sube;
        inicializar(sp, w, h);
    }

    public void act()
    {
        RaceWorld w = (RaceWorld) getWorld();
        if (w == null) return;
        t++;

        if (fase == 0) {
            altura += (alturaFlote - altura) * 0.06;
            if (Math.abs(altura - alturaFlote) < 40) fase = 1;
        } else if (fase == 1) {
            altura += Math.sin(t * 0.3) * 3;
            if (--espera <= 0) fase = sube ? 2 : 3;
        } else if (fase == 2) {
            altura += 42;
            if (altura > 5400) { w.removeObject(this); return; }
        } else {
            altura += Math.sin(t * 0.3) * 3;   // se queda flotando hasta que cambie el mundo
        }

        if (fase >= 1 && t % 3 == 0)
            w.addObject(new Explosion(x + Greenfoot.getRandomNumber(160) - 80,
                                      altura - 240, z, 190), -500, -500);
        proyectar();
    }
}
