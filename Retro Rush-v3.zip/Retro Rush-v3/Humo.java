import greenfoot.*;

/**
 * Nube de humo que sube y se desvanece. La sueltan el auto averiado en la
 * animacion de derrota, un vehiculo en llamas, y el SLIDE-X al derrapar
 * (humo de neumatico: pequeno y mas gris).
 *
 * No se congela con el mundo: tiene que seguir animando durante la derrota,
 * cuando RaceWorld.congelado() ya devuelve true.
 */
public class Humo extends Objeto3D
{
    private int frame = 0;
    private int vida = 36;
    private double crece = 7;
    private final double subida;
    private final double deriva;

    public Humo(double x, double altura, double z)
    {
        this(x, altura, z, 1.0);
    }

    /** escala < 1 = humo chico y rapido (neumatico); > 1 = humazo. */
    public Humo(double x, double altura, double z, double escala)
    {
        this.x = x;
        this.altura = altura;
        this.z = z;
        this.subida = (2.0 + Greenfoot.getRandomNumber(12) / 10.0) * escala;
        this.deriva = Greenfoot.getRandomNumber(9) - 4;
        this.crece = 7 * escala;
        this.vida = (int) (36 * Math.max(0.4, Math.min(1.0, escala)) + 8);
        inicializar(nube(escala < 0.8), (int) (150 * escala), (int) (150 * escala));
    }

    public void act()
    {
        RaceWorld w = (RaceWorld) getWorld();
        if (w == null) return;

        frame++;
        altura += subida;
        x += deriva;
        anchoMundo += crece;
        altoMundo  = anchoMundo;

        proyectar();
        getImage().setTransparency(Math.max(0, 150 - frame * (150 / vida)));

        if (frame > vida) w.removeObject(this);
    }

    private GreenfootImage nube(boolean gris)
    {
        GreenfootImage g = new GreenfootImage(80, 80);
        Color a = gris ? new Color(150, 150, 156, 150) : new Color(92, 92, 98, 160);
        Color b = gris ? new Color(185, 185, 190, 110) : new Color(128, 128, 134, 120);
        g.setColor(a);
        g.fillOval(0, 8, 64, 58);
        g.fillOval(20, 0, 58, 54);
        g.setColor(b);
        g.fillOval(14, 16, 34, 32);
        return g;
    }
}
