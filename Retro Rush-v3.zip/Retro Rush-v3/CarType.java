import greenfoot.*;

/**
 * Definicion de un auto jugable: estadisticas, habilidad especial,
 * modelo (silueta), tripulacion y puntaje de desbloqueo.
 */
public class CarType
{
    public static final int NITRO  = 0;   // acelera con SHIFT
    public static final int ESCUDO = 1;   // recibe la mitad de dano
    public static final int DOBLE  = 2;   // dispara dos balas a la vez

    // modelos (silueta propia, no un recoloreo) — ver Sprites.autoTrasero
    public static final int M_CLASICO  = 0;
    public static final int M_GT       = 1;
    public static final int M_DRIFT    = 2;
    public static final int M_PATRULLA = 3;
    public static final int M_PROTO    = 4;
    public static final int M_RALLY    = 5;
    public static final int M_SUPER    = 6;
    public static final int M_DERRAPA  = 7;

    public String nombre;
    public int velocidad;          // 1..10
    public int manejo;             // 1..10 (que tan rapido cambia de carril)
    public int habilidad;
    public int modelo;
    public int puntajeDesbloqueo;
    public Color cuerpo;
    public Color detalle;

    /** El SLIDE-X derrapa al cambiar de carril: se pasa y corrige. */
    public boolean derrapa = false;

    // tripulacion (colores de pelo y si llevan melena)
    public Color pelo1 = new Color(58, 42, 30);
    public Color pelo2 = new Color(234, 200, 72);
    public boolean melena1 = false;
    public boolean melena2 = true;

    // nombres de la tripulacion (los usa el final del juego)
    public String cond = "Marco";
    public String copi = "Lena";

    public CarType(String nombre, int velocidad, int manejo, int habilidad,
                   int modelo, int puntajeDesbloqueo, Color cuerpo, Color detalle)
    {
        this.nombre = nombre;
        this.velocidad = velocidad;
        this.manejo = manejo;
        this.habilidad = habilidad;
        this.modelo = modelo;
        this.puntajeDesbloqueo = puntajeDesbloqueo;
        this.cuerpo = cuerpo;
        this.detalle = detalle;
    }

    /** Fija la tripulacion de este auto (encadenable). */
    public CarType crew(Color p1, boolean m1, Color p2, boolean m2)
    {
        this.pelo1 = p1; this.melena1 = m1;
        this.pelo2 = p2; this.melena2 = m2;
        return this;
    }

    /** Nombres de la tripulacion (encadenable). */
    public CarType crewNombres(String conductor, String copiloto)
    {
        this.cond = conductor;
        this.copi = copiloto;
        return this;
    }

    public CarType conDerrape()
    {
        this.derrapa = true;
        return this;
    }

    public boolean desbloqueado()
    {
        return GameData.adminTodo || GameData.puntajeTotal >= puntajeDesbloqueo;
    }

    public String nombreHabilidad()
    {
        if (habilidad == NITRO)  return "TURBO";
        if (habilidad == ESCUDO) return "ESCUDO";
        return "DOBLE DISPARO";
    }

    public String descripcionHabilidad()
    {
        if (habilidad == NITRO)  return "SHIFT: nitro que rinde el doble y gasta la mitad";
        if (habilidad == ESCUDO) return "Recibe la mitad de dano y de frenazo al chocar";
        return "SPACE dispara DOS balas gastando solo 1";
    }

    /** Nombre de la ULTI (tecla X). Cada auto tiene la suya. */
    public String ultiNombre()  { return ultiNombre(modelo); }
    public String ultiDesc()    { return ultiDesc(modelo); }

    public static String ultiNombre(int modelo)
    {
        switch (modelo) {
            case M_CLASICO:  return "EMBESTIDA";
            case M_RALLY:    return "APLANADORA";
            case M_GT:       return "SOBRECARGA";
            case M_DRIFT:    return "LLUVIA DE PLOMO";
            case M_PATRULLA: return "BLOQUEO POLICIAL";
            case M_DERRAPA:  return "TROMPO ARMADO";
            case M_SUPER:    return "FASE";
            case M_PROTO:    return "PULSO EM";
            default:         return "ULTI";
        }
    }

    public static String ultiDesc(int modelo)
    {
        switch (modelo) {
            case M_CLASICO:  return "Embiste hacia adelante y revienta todos los autos que tengas delante";
            case M_RALLY:    return "Onda expansiva: limpia autos y animales de la ruta y te cura 15";
            case M_GT:       return "4 s de turbo extremo e intocable";
            case M_DRIFT:    return "Abanico de 8 balas contra todos los helicopteros y el jefe";
            case M_PATRULLA: return "Todos los rivales frenan y se descontrolan; ganas puntos y escudo 3 s";
            case M_DERRAPA:  return "Giras 360 disparando en todas direcciones y dejas un muro de humo";
            case M_SUPER:    return "4 s intangible y al doble de velocidad: atraviesas todo";
            case M_PROTO:    return "Destruye TODOS los helicopteros en pantalla y aturde a los rivales";
            default:         return "";
        }
    }

    public GreenfootImage imagen()
    {
        GreenfootImage img = Sprites.autoTrasero(cuerpo, detalle, modelo);
        new Pilotos(this).dibujar(img);
        return img;
    }

    /** Lista de autos del juego, en orden de desbloqueo. */
    public static CarType[] crearLista()
    {
        // El puntaje de desbloqueo es ACUMULADO entre carreras (puntajeTotal).
        return new CarType[] {
            new CarType("CLASICO 84",   4,  7, ESCUDO, M_CLASICO,        0, new Color(200, 40, 40),  new Color(240,240,240))
                .crew(new Color(58,42,30), false, new Color(234,200,72), true).crewNombres("Marco", "Lena"),

            new CarType("RALLY RS",      6,  8, ESCUDO, M_RALLY,      20000, new Color(235,235,240),  new Color(30,120,70))
                .crew(new Color(90,60,40), false, new Color(175,60,40), false).crewNombres("Bruno", "Sasha"),

            new CarType("TURBO GT",      6,  6, NITRO,  M_GT,         45000, new Color(240,160, 30),  new Color(40, 40, 60))
                .crew(new Color(30,30,34), false, new Color(225,225,230), true).crewNombres("Nico", "Vera"),

            new CarType("DRIFT KING",    7,  9, DOBLE,  M_DRIFT,      90000, new Color(30, 190, 190), new Color(120, 60, 200))
                .crew(new Color(40,150,150), false, new Color(150,80,200), true).crewNombres("Kaito", "Mika"),

            new CarType("PATRULLA X",    8,  6, ESCUDO, M_PATRULLA,  150000, new Color(40, 60, 200),  new Color(250,250,250))
                .crew(new Color(40,40,45), false, new Color(52,52,58), false).crewNombres("Rex", "Nadia"),

            new CarType("SLIDE-X",       7, 10, DOBLE,  M_DERRAPA,   230000, new Color(20, 22, 28),   new Color(255, 70, 150))
                .crew(new Color(255,80,160), false, new Color(0,200,220), false).conDerrape().crewNombres("Ziggy", "Nova"),

            new CarType("HYPER S9",      9,  7, NITRO,  M_SUPER,     340000, new Color(255,110, 30),  new Color(30, 30, 40))
                .crew(new Color(200,200,205), false, new Color(40,35,50), true).crewNombres("Dante", "Iris"),

            new CarType("PROTOTIPO Z",  10,  8, NITRO,  M_PROTO,     520000, new Color(120, 20, 160), new Color(0, 255, 180))
                .crew(new Color(240,240,245), false, new Color(0,255,180), true).crewNombres("Orion", "Echo")
        };
    }
}
