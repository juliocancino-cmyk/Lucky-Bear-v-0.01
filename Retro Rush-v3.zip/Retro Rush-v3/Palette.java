import greenfoot.*;

/**
 * Ambientacion de cada nivel: colores, clima animado y que animal
 * cruza la ruta. Es lo que hace que el fondo cambie y se mueva.
 */
public class Palette
{
    // climas animados
    public static final int SECO      = 0;
    public static final int NIEVE     = 1;
    public static final int LLUVIA    = 2;
    public static final int CENIZA    = 3;
    public static final int HOJAS     = 4;
    public static final int ESTRELLAS = 5;
    public static final int ARENA     = 6;

    public String nombre;
    public Color cieloAlto, cieloBajo, suelo, ruta, linea, bordeRuta, copa, tronco;

    public int clima = SECO;
    public boolean relampagos = false;

    // animal que cruza
    public Color faunaCuerpo = new Color(120, 90, 60);
    public Color faunaDetalle = new Color(70, 50, 34);
    public boolean faunaVuela = false;

    public Palette(String nombre, Color cieloAlto, Color cieloBajo, Color suelo,
                   Color ruta, Color linea, Color bordeRuta, Color copa, Color tronco)
    {
        this.nombre = nombre;
        this.cieloAlto = cieloAlto;
        this.cieloBajo = cieloBajo;
        this.suelo = suelo;
        this.ruta = ruta;
        this.linea = linea;
        this.bordeRuta = bordeRuta;
        this.copa = copa;
        this.tronco = tronco;
    }

    private Palette clima(int c) { this.clima = c; return this; }
    private Palette rayos()      { this.relampagos = true; return this; }
    private Palette fauna(Color cuerpo, Color detalle, boolean vuela)
    {
        this.faunaCuerpo = cuerpo;
        this.faunaDetalle = detalle;
        this.faunaVuela = vuela;
        return this;
    }

    /**
     * Oscurece y enrojece la paleta a medida que te acercas al jefe.
     * Nivel 1 = sin cambio; ultimo nivel = casi noche roja.
     * Muta esta instancia (Palette.get() siempre devuelve una nueva).
     */
    public void oscurecerHaciaJefe(int nivel)
    {
        double t = (nivel - 1) / (double) Math.max(1, GameData.NIVEL_MAX - 1);
        if (t <= 0.02) return;
        if (t > 1) t = 1;

        double dark = t * 0.55;
        Color rojo = new Color(120, 22, 16);

        cieloAlto = Sprites.mezclar(Sprites.mezclar(cieloAlto, Color.BLACK, dark),        rojo, t * 0.40);
        cieloBajo = Sprites.mezclar(Sprites.mezclar(cieloBajo, Color.BLACK, dark * 0.7),  rojo, t * 0.45);
        suelo     = Sprites.mezclar(Sprites.mezclar(suelo,     Color.BLACK, dark),        rojo, t * 0.25);
        ruta      = Sprites.mezclar(ruta,   Color.BLACK, dark * 0.6);
        copa      = Sprites.mezclar(Sprites.mezclar(copa, Color.BLACK, dark),             rojo, t * 0.20);
        tronco    = Sprites.mezclar(tronco, Color.BLACK, dark * 0.5);
        linea     = Sprites.mezclar(linea,     new Color(255, 120, 90), t * 0.5);
        bordeRuta = Sprites.mezclar(bordeRuta, new Color(255, 110, 80), t * 0.45);
    }

    public static Palette get(int nivel)
    {
        if (nivel >= GameData.NIVEL_MAX) return finalTorre();

        int n = ((nivel - 1) % 19 + 19) % 19 + 1;   // 19 escenarios, ciclicos

        switch (n) {
            case 1: return new Palette("PLAYA",
                new Color(60,150,235), new Color(160,215,250), new Color(70,165,85),
                new Color(78,78,88), Color.WHITE, new Color(225,225,225),
                new Color(35,150,75), new Color(125,85,45))
                .fauna(new Color(240,240,245), new Color(230,170,60), true);      // gaviota

            case 2: return new Palette("CIUDAD",
                new Color(95,120,165), new Color(175,190,210), new Color(105,110,120),
                new Color(65,65,72), new Color(240,240,180), new Color(210,210,210),
                new Color(70,120,80), new Color(90,80,70))
                .fauna(new Color(90,90,96), new Color(60,60,66), false);          // perro

            case 3: return new Palette("ATARDECER",
                new Color(215,80,60), new Color(255,175,90), new Color(120,70,60),
                new Color(70,55,60), new Color(255,230,180), new Color(255,200,150),
                new Color(60,50,40), new Color(70,45,30))
                .clima(HOJAS)
                .fauna(new Color(150,110,70), new Color(90,65,40), false);        // ciervo

            case 4: return new Palette("DESIERTO",
                new Color(120,180,225), new Color(230,215,170), new Color(215,185,120),
                new Color(95,90,85), new Color(250,245,220), new Color(240,230,200),
                new Color(120,150,80), new Color(140,105,60))
                .clima(ARENA)
                .fauna(new Color(205,175,120), new Color(150,120,80), false);     // camello

            case 5: return new Palette("BOSQUE",
                new Color(80,140,180), new Color(150,195,200), new Color(45,110,60),
                new Color(60,62,66), Color.WHITE, new Color(215,220,215),
                new Color(20,105,55), new Color(85,60,35))
                .clima(HOJAS)
                .fauna(new Color(96,68,44), new Color(58,40,26), false);          // oso

            case 6: return new Palette("NOCHE",
                new Color(10,12,40), new Color(35,40,85), new Color(25,45,35),
                new Color(38,38,45), new Color(230,230,120), new Color(160,160,180),
                new Color(20,70,45), new Color(55,40,25))
                .clima(ESTRELLAS)
                .fauna(new Color(70,72,84), new Color(200,210,230), false);       // lobo

            case 7: return new Palette("NEON",
                new Color(25,0,50), new Color(90,20,120), new Color(40,10,70),
                new Color(30,30,45), new Color(0,255,220), new Color(255,60,200),
                new Color(150,0,220), new Color(60,0,90))
                .clima(ESTRELLAS)
                .fauna(new Color(255,90,220), new Color(0,255,220), true);        // dron

            case 8: return new Palette("NIEVE",
                new Color(150,180,215), new Color(220,232,245), new Color(235,240,248),
                new Color(85,88,95), Color.WHITE, new Color(200,215,235),
                new Color(70,110,90), new Color(90,75,60))
                .clima(NIEVE)
                .fauna(new Color(245,245,250), new Color(90,95,110), false);      // reno

            case 9: return new Palette("VOLCAN",
                new Color(60,20,20), new Color(180,60,30), new Color(70,45,40),
                new Color(45,40,42), new Color(255,180,60), new Color(255,120,40),
                new Color(90,50,30), new Color(60,35,25))
                .clima(CENIZA)
                .fauna(new Color(60,40,38), new Color(255,140,40), false);        // jabali

            case 10: return new Palette("ORBITA",
                new Color(5,5,20), new Color(20,20,60), new Color(45,45,80),
                new Color(28,28,40), new Color(120,220,255), new Color(180,140,255),
                new Color(60,60,140), new Color(40,40,90))
                .clima(ESTRELLAS)
                .fauna(new Color(190,200,230), new Color(120,140,255), true);     // satelite

            case 11: return new Palette("SELVA",
                new Color(40,110,120), new Color(130,190,160), new Color(25,95,50),
                new Color(52,56,54), new Color(230,255,210), new Color(200,230,190),
                new Color(15,130,60), new Color(70,55,30))
                .clima(HOJAS)
                .fauna(new Color(210,170,60), new Color(60,45,30), false);        // jaguar

            case 12: return new Palette("TORMENTA",
                new Color(28,32,44), new Color(70,78,96), new Color(50,58,60),
                new Color(40,42,50), new Color(200,215,255), new Color(150,170,210),
                new Color(35,60,50), new Color(50,45,40))
                .clima(LLUVIA).rayos()
                .fauna(new Color(60,64,72), new Color(200,215,255), true);        // cuervo

            case 13: return new Palette("CANON",
                new Color(150,90,60), new Color(240,175,110), new Color(170,95,60),
                new Color(78,60,54), new Color(255,235,190), new Color(255,200,140),
                new Color(120,110,60), new Color(110,70,40))
                .clima(ARENA)
                .fauna(new Color(140,100,70), new Color(80,60,40), true);         // condor

            case 14: return new Palette("CRISTAL",
                new Color(60,40,110), new Color(150,130,225), new Color(120,140,200),
                new Color(58,60,90), new Color(230,245,255), new Color(190,210,255),
                new Color(120,160,230), new Color(80,90,150))
                .clima(NIEVE)
                .fauna(new Color(200,225,255), new Color(120,160,230), false);

            case 15: return new Palette("PANTANO",
                new Color(70,95,80), new Color(140,160,120), new Color(45,70,45),
                new Color(50,54,48), new Color(200,225,160), new Color(170,200,150),
                new Color(40,80,45), new Color(60,55,35))
                .clima(LLUVIA)
                .fauna(new Color(90,110,70), new Color(50,65,40), false);          // cocodrilo

            case 16: return new Palette("AUTOPISTA",
                new Color(12,14,30), new Color(45,40,70), new Color(30,30,38),
                new Color(34,34,42), new Color(255,220,120), new Color(255,150,90),
                new Color(40,45,60), new Color(35,35,40))
                .clima(ESTRELLAS)
                .fauna(new Color(70,74,86), new Color(220,220,120), true);         // dron patrulla

            case 17: return new Palette("SALAR",
                new Color(120,175,215), new Color(238,242,248), new Color(240,244,250),
                new Color(120,124,132), new Color(255,255,255), new Color(210,222,235),
                new Color(150,175,180), new Color(120,110,95))
                .clima(ARENA)
                .fauna(new Color(235,238,245), new Color(150,160,175), true);      // flamenco

            case 18: return new Palette("RUINAS",
                new Color(90,130,140), new Color(180,200,180), new Color(90,120,80),
                new Color(70,72,66), new Color(235,240,210), new Color(205,215,185),
                new Color(30,120,55), new Color(90,80,55))
                .clima(HOJAS)
                .fauna(new Color(150,140,100), new Color(90,80,55), false);        // tigre

            case 19: return new Palette("AURORA",
                new Color(8,14,34), new Color(30,60,90), new Color(210,225,235),
                new Color(40,46,58), new Color(150,255,210), new Color(120,180,255),
                new Color(60,110,120), new Color(70,70,80))
                .clima(NIEVE)
                .fauna(new Color(240,245,250), new Color(120,180,255), false);     // zorro polar

            default: return new Palette("INFIERNO",
                new Color(70,0,10), new Color(220,60,20), new Color(60,20,20),
                new Color(34,28,30), new Color(255,210,90), new Color(255,90,40),
                new Color(80,30,20), new Color(50,25,20))
                .clima(CENIZA).rayos()
                .fauna(new Color(40,20,20), new Color(255,120,40), true);
        }
    }

    /** Ultimo nivel: al pie de la torre de la Organizacion. Noche roja. */
    private static Palette finalTorre()
    {
        return new Palette("LA TORRE",
            new Color(24,4,8), new Color(90,14,16), new Color(30,14,16),
            new Color(26,22,24), new Color(255,120,80), new Color(255,70,50),
            new Color(50,18,16), new Color(35,18,14))
            .clima(CENIZA).rayos()
            .fauna(new Color(30,16,16), new Color(255,90,40), true);
    }
}
