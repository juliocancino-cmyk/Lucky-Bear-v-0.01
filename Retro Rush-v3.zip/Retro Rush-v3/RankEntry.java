/**
 * Una fila del ranking: que auto uso, cuanto puntaje hizo,
 * cuanto tardo y si termino los 10 niveles.
 */
public class RankEntry
{
    public String auto;
    public int puntaje;
    public long tiempoMs;
    public boolean completado;
    public boolean challenge;

    public RankEntry(String auto, int puntaje, long tiempoMs, boolean completado)
    {
        this(auto, puntaje, tiempoMs, completado, false);
    }

    public RankEntry(String auto, int puntaje, long tiempoMs,
                     boolean completado, boolean challenge)
    {
        this.challenge = challenge;
        this.auto = auto;
        this.puntaje = puntaje;
        this.tiempoMs = tiempoMs;
        this.completado = completado;
    }

    /**
     * Puntaje final = puntaje + bonus por rapidez.
     * Si tardaste menos de 10 minutos, cada segundo ahorrado suma 20 puntos.
     */
    public int puntajeFinal()
    {
        // En challenge no hay bonus por rapidez: aguantar mas ya da mas puntos.
        if (challenge) return puntaje;
        if (!completado) return puntaje / 2;
        int segundos = (int)(tiempoMs / 1000);
        int bonus = Math.max(0, (600 - segundos) * 20);
        return puntaje + bonus;
    }
}
