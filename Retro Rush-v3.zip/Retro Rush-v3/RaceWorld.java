import greenfoot.*;

/**
 * Mundo de la carrera con camara pseudo-3D.
 *
 * La ruta se dibuja fila por fila: para cada linea de pixeles se calcula
 * a que profundidad z corresponde y se pinta el asfalto de ese ancho.
 *
 * Estados: 0 corriendo, 1 nivel superado, 2 destruido, 3 pelea del jefe.
 */
public class RaceWorld extends World
{
    private LevelConfig cfg;
    private PlayerCar jugador;
    private HudOverlay hud;
    private Ambiente ambiente;
    private Boss jefe;

    private double scrollZ = 0;
    private double distancia = 0;
    private double velocidad = 0;

    private int timerTrafico = 60;
    private int timerEnemigo = 90;

    private int estado = 0;
    private int contador = 0;
    private int introTimer = 110;

    private boolean pausa = false;
    private MenuButton btnSeguir, btnReiniciar, btnSalir, btnAdmin, btnDios;

    private int tiempoRestante;
    private int ticAviso = 0;

    // modo challenge: no hay meta, solo aguantar. Cada tramo endurece todo.
    private int framesTramo = 0;


    // sensacion de velocidad: cuanto cambio la velocidad este frame
    private double velocidadPrev = 0;
    private double aceleracion   = 0;
    private int    flashChoque   = 0;   // destello rojo al chocar

    // aviso previo de un auto que va a aparecer por detras
    private int avisoCarril = -1;
    private int avisoTimer = 0;

    private GreenfootImage imgArbol, imgCartel, imgLado;

    public RaceWorld()
    {
        super(GameData.ANCHO, GameData.ALTO, 1);

        cfg = LevelConfig.get(GameData.nivelActual);
        if (GameData.modoChallenge) cfg.aplicarVuelta(GameData.vuelta);
        Camara.reset();

        // MenuButton va PRIMERO: el HUD ocupa toda la pantalla y, si se pinta
        // encima, Greenfoot le entrega a el todos los clics y los botones
        // de la pausa dejan de funcionar.
        setPaintOrder(MenuButton.class, HudOverlay.class, PopText.class, Explosion.class,
                      Humo.class, Ocupante.class, Ovni.class, Cae.class,
                      CosaCae.class, CosaBaja.class, Rocket.class,
                      Bullet.class, EnemyBullet.class,
                      PlayerCar.class, MafiaVehiculo.class, Escombro.class,
                      RivalCar.class, AutoSicario.class, Sicario.class, Fauna.class,
                      PosteMedio.class, GrietaCalle.class,
                      Boss.class, EnemyHeli.class);

        ambiente  = new Ambiente(cfg.paleta);
        imgArbol  = Sprites.arbol(cfg.paleta.copa, cfg.paleta.tronco);
        imgCartel = Sprites.cartel(cfg.paleta.linea);
        imgLado   = Sprites.decorLado(cfg.paleta.nombre, cfg.paleta.copa, cfg.paleta.tronco);

        jugador = new PlayerCar();
        addObject(jugador, GameData.ANCHO / 2, 500);

        hud = new HudOverlay();
        addObject(hud, GameData.ANCHO / 2, GameData.ALTO / 2);

        tiempoRestante = GameData.modoChallenge ? GameData.tiempoCarry : cfg.tiempoLimite;

        velocidad = cfg.velocidadBase * 0.32;   // arranca lento: la salida "lanza"
        velocidadPrev = velocidad;
        Sonido.musica("musica_carrera.wav");
        dibujarEscenario();
    }

    /** Greenfoot pausado desde la barra de abajo: callamos el audio. */
    public void stopped() { Sonido.pausar(); }
    public void started() { Sonido.reanudar(); }

    public void act()
    {
        if (flashChoque > 0) flashChoque--;
        revisarPausa();
        sonarMotor();

        if (pausa) { dibujarEscenario(); hud.actualizar(this); return; }

        if (introTimer > 0) {
            introTimer--;
            dibujarEscenario();
            hud.actualizar(this);
            return;
        }

        if (estado == 0 || estado == 3) {
            correrReloj();
            gestionarAvisos();
            acelerar();

            aceleracion   = velocidad - velocidadPrev;
            velocidadPrev = velocidad;

            // la focal respira con la aceleracion: acelerar abre el angulo,
            // frenar lo cierra (efecto zoom). Chico por frame, pero constante.
            double kick = -aceleracion * 4.0;
            if (kick >  6) kick =  6;
            if (kick < -6) kick = -6;
            Camara.golpeFocal(kick);

            scrollZ += velocidad;
            Camara.seguir(jugador.getX3D());
            Camara.ajustarPorVelocidad(velocidad);
            generarTrafico();
            generarEnemigos();
            generarPostes();

            if (estado == 0) {
                distancia += velocidad / 100.0;

                if (GameData.modoChallenge) {
                    correrTramo();                       // infinito: solo sube dificultad
                } else if (distancia >= cfg.distanciaObjetivo) {
                    finDeNivel();
                }
            }
        } else {
            if (estado == 2) animarDerrota();
            else if (estado == 1) animarSalida();
            contador--;
            if (contador <= 0) avanzar();
        }

        dibujarEscenario();
        hud.actualizar(this);
    }

    // ==================================================================
    // PAUSA
    // ==================================================================
    /**
     * Cuenta atras del nivel. Si llega a cero se pierde igual que si
     * te destruyen: el tiempo es un rival mas.
     */
    private void correrReloj()
    {
        if (GameData.modoChallenge) return;      // el challenge no tiene limite

        tiempoRestante--;

        if (tiempoRestante <= 500 && tiempoRestante > 0) {
            ticAviso++;
            if (ticAviso >= 25) { ticAviso = 0; Sonido.efecto("tic.wav"); }
        }

        if (tiempoRestante <= 0) {
            tiempoRestante = 0;
            addObject(new PopText("SE ACABO EL TIEMPO", new Color(255, 90, 90), 30),
                      GameData.ANCHO / 2, 300);
            gameOver(PlayerCar.C_TIEMPO);
        }
    }

    /**
     * En challenge la partida no termina nunca por si sola: cada
     * FRAMES_POR_TRAMO se pasa al siguiente escenario y, al completar los 15,
     * empieza una vuelta nueva con todo mas rapido y mas duro.
     */
    private void correrTramo()
    {
        framesTramo++;
        if (framesTramo < GameData.FRAMES_POR_TRAMO) return;

        framesTramo = 0;
        distancia = 0;

        GameData.nivelActual++;
        if (GameData.nivelActual > GameData.NIVEL_MAX) {
            GameData.nivelActual = 1;
            GameData.vuelta++;
            addObject(new PopText("VUELTA " + (GameData.vuelta + 1) + "  -  MAS DIFICIL",
                                  new Color(255, 140, 60), 30),
                      GameData.ANCHO / 2, 300);
        }

        cfg = LevelConfig.get(GameData.nivelActual);
        cfg.aplicarVuelta(GameData.vuelta);

        // el escenario cambia en caliente, sin cortar la partida
        ambiente  = new Ambiente(cfg.paleta);
        imgArbol  = Sprites.arbol(cfg.paleta.copa, cfg.paleta.tronco);
        imgCartel = Sprites.cartel(cfg.paleta.linea);
        imgLado   = Sprites.decorLado(cfg.paleta.nombre, cfg.paleta.copa, cfg.paleta.tronco);

        addObject(new PopText(cfg.paleta.nombre, new Color(150, 235, 255), 26),
                  GameData.ANCHO / 2, 360);
    }

    /**
     * Los autos que vienen por detras aparecen pegados a la camara, asi que
     * primero se anuncia con una flecha en su carril y recien despues salen.
     */
    private void gestionarAvisos()
    {
        if (avisoTimer <= 0) return;

        avisoTimer--;
        if (avisoTimer == 0 && avisoCarril >= 0) {
            addObject(new RivalCar(avisoCarril, cfg, true), -500, -500);
            avisoCarril = -1;
        }
    }

    /** El motor sube de tono con la velocidad y mete el turbo con SHIFT. */
    private void sonarMotor()
    {
        if (pausa || estado == 2) { Sonido.pararMotor(); return; }
        double p = velocidad / Math.max(1, velocidadObjetivo());
        Sonido.motor(p, jugador != null && jugador.nitroEncendido());
    }

    private void revisarPausa()
    {
        String t = Greenfoot.getKey();
        if ("m".equals(t)) Sonido.alternar();

        // atajos de admin (solo en juego, no en pausa ni en derrota)
        if (GameData.adminMenu && !pausa && estado != 2) {
            if ("k".equals(t) && GameData.adminInstakill) { gameOver(PlayerCar.C_CHOQUE); return; }
            if ("l".equals(t) && GameData.adminNextLevel) { saltarNivel(); return; }
        }

        if ("p".equals(t) || "escape".equals(t)) {
            if (pausa) quitarPausa(); else ponerPausa();
        }

        if (!pausa) return;

        // barras de sonido arrastrables en la pausa
        MouseInfo mi = Greenfoot.getMouseInfo();
        if (mi != null && (Greenfoot.mousePressed(null) || Greenfoot.mouseDragged(null))) {
            int v = (int) Math.round((mi.getX() - (GameData.ANCHO / 2 - 150)) * 100.0 / 300);
            v = Math.max(0, Math.min(100, v));
            int soff = GameData.adminMenu ? 26 : 0;
            if (Math.abs(mi.getY() - (388 + soff)) < 22)      Sonido.fijarMusica(v);
            else if (Math.abs(mi.getY() - (432 + soff)) < 22) Sonido.fijarEfectos(v);
        }

        // atajos de teclado, por si el mouse falla
        if ("r".equals(t) && !GameData.modoChallenge) {
            Greenfoot.setWorld(new RaceWorld()); return;
        }
        if ("q".equals(t)) { Greenfoot.setWorld(new MenuWorld()); return; }

        if (btnSeguir.fueClickeado()) {
            quitarPausa();
        } else if (btnReiniciar.fueClickeado() && !GameData.modoChallenge) {
            Greenfoot.setWorld(new RaceWorld());
        } else if (btnSalir.fueClickeado()) {
            Greenfoot.setWorld(new MenuWorld());
        } else if (btnAdmin != null && btnAdmin.fueClickeado()) {
            Greenfoot.setWorld(new NivelesWorld());
        } else if (btnDios != null && btnDios.fueClickeado()) {
            Greenfoot.setWorld(new DiosWorld(true));
        }
    }

    /**
     * MODO ADMIN + tecla L: salta el nivel.
     *   - nivel normal   -> lo da por completado
     *   - nivel con jefe  -> 1a L salta el recorrido y aparece el jefe; 2a L mata al jefe
     */
    private void saltarNivel()
    {
        if (estado == 3 && jefe != null) { jefe.recibirDano(9000000); return; }
        if (estado != 0) return;

        Sonido.efecto("nivel.wav");
        finDeNivel();
    }

    private void ponerPausa()
    {
        if (estado == 2 || pausa) return;
        pausa = true;
        Sonido.pausar();

        btnSeguir    = new MenuButton("SEGUIR",          "seguir",  280, 46);
        btnReiniciar = new MenuButton(GameData.modoChallenge ? "SIN REINTENTOS" : "REINICIAR NIVEL",
                                      "reinic", 280, 46);
        btnReiniciar.setActivo(!GameData.modoChallenge);
        btnSalir     = new MenuButton("SALIR AL MENU",   "salir",   280, 46);

        addObject(btnSeguir,    400, 176);
        addObject(btnReiniciar, 400, 224);
        addObject(btnSalir,     400, 272);

        if (GameData.adminMenu) {
            btnAdmin = new MenuButton("ADMIN: IR A OTRO NIVEL", "padmin", 300, 38);
            btnDios  = new MenuButton("ADMIN: MODO DIOS",       "pdios",  300, 38);
            addObject(btnAdmin, 400, 314);
            addObject(btnDios,  400, 354);
        }
    }

    private void quitarPausa()
    {
        pausa = false;
        Sonido.reanudar();
        if (btnSeguir    != null) removeObject(btnSeguir);
        if (btnReiniciar != null) removeObject(btnReiniciar);
        if (btnSalir     != null) removeObject(btnSalir);
        if (btnAdmin     != null) removeObject(btnAdmin);
        if (btnDios      != null) removeObject(btnDios);
        btnSeguir = btnReiniciar = btnSalir = btnAdmin = btnDios = null;
    }

    /** Todo lo que se mueve consulta esto para quedarse quieto. */
    public boolean congelado()
    {
        return pausa || introTimer > 0 || estado == 1 || estado == 2;
    }

    public boolean isPausa() { return pausa; }

    /** true durante la cinematica de derrota (para que humo/explosiones animen). */
    public boolean enDerrota() { return estado == 2; }

    // ==================================================================
    // VELOCIDAD
    // ==================================================================
    private void acelerar()
    {
        double objetivo = velocidadObjetivo();
        if (velocidad < objetivo) {
            // La velocidad sube COMO MUCHO ACEL_MAX por frame. Este es EL
            // numero para tunear la aceleracion:
            //   mas alto  -> retoma la velocidad antes
            //   mas bajo  -> cuesta mucho mas, sobre todo tras un frenazo
            final double ACEL_MAX = 0.42;
            double delta = (objetivo - velocidad) * 0.02;
            if (delta > ACEL_MAX) delta = ACEL_MAX;
            velocidad += delta;
        } else {
            velocidad += (objetivo - velocidad) * 0.07;
        }
    }

    public double velocidadObjetivo()
    {
        // velocidad de crucero con techo (~340 km/h). El nitro/ulti va POR ENCIMA
        // del techo, pero es temporal.
        double base = cfg.velocidadBase + GameData.auto().velocidad * 6 + GameData.modVelocidad;
        base = Math.min(base, 252);
        if (jugador != null) base += jugador.bonusVelocidad();
        return Math.max(40, base);
    }

    /**
     * Frenazo. 'factor' multiplica la velocidad; 'piso' es el minimo al que
     * puede caer (unidades internas). Un choque normal deja ~la mitad; un
     * choque multiple o un animal la mandan casi (o del todo) a cero.
     */
    public void frenazo(double factor, double piso)
    {
        if (GameData.diosInmune) { flashChoque = 8; return; }   // admin: los golpes no frenan

        double antes = velocidad;
        // mejora INERCIA: conservas mas velocidad al chocar
        double factReal = Math.min(0.95, factor * GameData.modFrenazo);
        velocidad *= factReal;
        if (velocidad < piso) velocidad = piso;

        // el frenazo se ve y se siente: zoom + temblor + destello
        double perdida = antes - velocidad;
        Camara.golpeFocal(Math.min(54, 12 + perdida * 0.6));
        Camara.sacudir(Math.min(32, 6 + perdida * 0.45));
        flashChoque = 16;
        velocidadPrev = velocidad;   // no contar el golpe otra vez el proximo frame
    }

    /** Frenazo simple: usa el piso "de siempre". */
    public void frenazo(double factor)
    {
        frenazo(factor, cfg.velocidadBase * 0.30);
    }

    // ==================================================================
    // DIBUJO
    // ==================================================================
    private void dibujarEscenario()
    {
        GreenfootImage f = getBackground();
        Palette p = cfg.paleta;

        dibujarCielo(f, p);
        dibujarRuta(f, p);
        dibujarPaisaje(f, p);
        dibujarSombraJugador(f);
        dibujarLineasDeVelocidad(f);

        if (!congelado() && ambiente.actualizar(f, velocidad)) soltarFauna();
        else if (congelado()) ambiente.actualizar(f, 0);

        if (flashChoque > 0) {
            int a = (int) (115 * (flashChoque / 16.0));
            f.setColor(new Color(255, 45, 45, a));
            f.fillRect(0, 0, GameData.ANCHO, GameData.ALTO);
        }
    }

    private void soltarFauna()
    {
        if (getObjects(Fauna.class).size() > 0) return;
        addObject(new Fauna(cfg.paleta, 9000 + Greenfoot.getRandomNumber(4000)), -500, -500);
    }

    private void dibujarCielo(GreenfootImage f, Palette p)
    {
        int H = Camara.HORIZONTE;

        int bandas = 8;
        for (int i = 0; i < bandas; i++) {
            double t = i / (double) (bandas - 1);
            f.setColor(Sprites.mezclar(p.cieloAlto, p.cieloBajo, t));
            f.fillRect(0, i * H / bandas, GameData.ANCHO, H / bandas + 1);
        }

        int solX = 560 - (int) (Camara.camX * 0.02);
        f.setColor(Sprites.mezclar(p.linea, p.cieloBajo, 0.15));
        f.fillOval(solX, H - 175, 165, 165);
        f.setColor(p.cieloBajo);
        for (int y = H - 95; y < H; y += 14) f.fillRect(solX - 10, y, 190, 6);

        // silueta lejana del horizonte: tenue, casi quieta (solo se mueve un
        // poco al cambiar de carril). NO se desplaza con el scroll: el fondo
        // moviendose atras queda feo; el movimiento lo dan los costados.
        f.setColor(Sprites.mezclar(p.suelo, p.cieloBajo, 0.45));
        int desfase = (int) (Camara.camX * 0.04) % 160;
        for (int i = -1; i < 8; i++) {
            int bx = i * 160 - desfase;
            int alto = 34 + ((i * 37) % 5) * 12;
            f.fillRect(bx, H - alto, 120, alto);
        }
    }

    private void dibujarRuta(GreenfootImage f, Palette p)
    {
        Color pastoA = p.suelo;
        Color pastoB = Sprites.mezclar(p.suelo, Color.BLACK, 0.18);
        Color rutaA  = p.ruta;
        Color rutaB  = Sprites.mezclar(p.ruta, Color.WHITE, 0.10);

        // en un puente el "afuera" es el vacio / el bosque de abajo: mas oscuro
        if (cfg.puente) {
            pastoA = Sprites.mezclar(p.suelo, Color.BLACK, 0.58);
            pastoB = Sprites.mezclar(p.suelo, Color.BLACK, 0.72);
        }

        int H = Camara.HORIZONTE;

        // BASE solida de todo el suelo: sin esto quedan filas sin pintar
        // justo bajo el horizonte y se ve una linea fea.
        f.setColor(pastoA);
        f.fillRect(0, H, GameData.ANCHO, GameData.ALTO - H);

        // neblina de horizonte: funde el cielo con el suelo en pocos pixeles
        Color cb = p.cieloBajo;
        for (int i = 0; i < 7; i++) {
            int a = 150 - i * 22;
            if (a <= 0) break;
            f.setColor(new Color(cb.getRed(), cb.getGreen(), cb.getBlue(), a));
            f.fillRect(0, H - 2 + i, GameData.ANCHO, 1);
        }

        int paso = 2;
        for (int sy = H + paso; sy < GameData.ALTO; sy += paso) {

            double z = Camara.ALTURA * Camara.FOCAL / (sy - H);
            double e = Camara.FOCAL / z;
            double zt = z + scrollZ;

            // cerca del horizonte NO alternamos franjas: a esa distancia el
            // patron cambia cada fila y hace un hervidero de pixeles.
            boolean lejos   = sy < H + 18;
            boolean franja  = lejos || ((int) (zt / 2600)) % 2 == 0;
            boolean franja2 = !lejos && ((int) (zt / 1300)) % 2 == 0;

            if (!franja) {
                f.setColor(pastoB);
                f.fillRect(0, sy, GameData.ANCHO, paso);
            }

            double cx   = GameData.ANCHO / 2.0 - Camara.camX * e;
            double semi = Camara.SEMI_RUTA * e;
            f.setColor(franja ? rutaA : rutaB);
            f.fillRect((int) (cx - semi), sy, (int) (semi * 2), paso);

            // los bordes y las lineas solo cuando la ruta ya tiene ancho:
            // asi no aparecen pixeles de color sueltos en el punto de fuga.
            if (semi > 3) {
                int anchoB = Math.max(1, (int) (semi * 0.09));
                f.setColor(franja ? p.bordeRuta : Color.WHITE);
                f.fillRect((int) (cx - semi), sy, anchoB, paso);
                f.fillRect((int) (cx + semi) - anchoB, sy, anchoB, paso);

                if (franja2) {
                    int anchoL = Math.max(1, (int) (36 * e));
                    f.setColor(p.linea);
                    for (int c = 1; c < Camara.CARRILES; c++) {
                        double lx = cx + (-Camara.SEMI_RUTA + c * Camara.ANCHO_CARRIL) * e;
                        f.fillRect((int) lx - anchoL / 2, sy, anchoL, paso);
                    }
                }

                // PUENTE: barrera de hormigon que separa las 2 calzadas
                // (izquierda contramano / derecha sentido normal)
                if (cfg.puente && semi > 12) {
                    int bw = Math.max(2, (int) (26 * e));
                    int bh = paso + Math.max(2, (int) (72 * e));
                    f.setColor(new Color(138, 138, 146));
                    f.fillRect((int) (cx - bw / 2.0), sy - bh + paso, bw, bh);
                    f.setColor(new Color(205, 200, 70));
                    f.fillRect((int) (cx - bw / 2.0), sy - bh + paso, bw, Math.max(1, (int) (6 * e)));
                }
            }
        }
    }

    /**
     * Costados de la ruta: dos columnas de arboles/props DENSAS a cada lado.
     * El tamano y el tipo de cada uno varian con un hash de su posicion de
     * mundo (estable mientras se acerca), asi no se ve todo igual y el
     * desfile por los costados da la sensacion de velocidad. TODO el
     * movimiento del fondo pasa aca; el horizonte queda quieto a proposito.
     */
    private void dibujarPaisaje(GreenfootImage f, Palette p)
    {
        double periodo = 1200;
        double borde   = Camara.SEMI_RUTA + 470;
        long   base    = (long) (scrollZ / periodo);

        for (int i = 13; i >= 1; i--) {
            double z = i * periodo - (scrollZ % periodo);
            if (z < 340) continue;

            for (int lado = -1; lado <= 1; lado += 2) {
                for (int col = 0; col < 2; col++) {
                    long h = (base + i) * 131 + (lado > 0 ? 61 : 0) + col * 7;
                    int  k = (int) (h % 7);
                    double b = lado * (borde + col * 560);

                    if (k == 0) {                         // de vez en cuando un cartel
                        dibujarEnSuelo(f, imgCartel, b, z, 620, 950);
                        continue;
                    }
                    double esc = 0.66 + ((h / 7) % 8) * 0.10;      // 0.66 .. 1.36
                    GreenfootImage sp = (k <= 3) ? imgArbol : imgLado;
                    dibujarEnSuelo(f, sp, b, z, 720 * esc, 1320 * esc);
                }
            }
        }
    }

    /** Mancha en el asfalto que marca donde caera el auto al saltar. */
    private void dibujarSombraJugador(GreenfootImage f)
    {
        if (jugador == null || !jugador.enElAire()) return;

        double e = Camara.escala(Camara.Z_JUGADOR);
        int w = (int) (420 * e);
        int h = Math.max(4, (int) (150 * e));
        int sx = Camara.px(jugador.getX3D(), Camara.Z_JUGADOR) - w / 2;
        int sy = Camara.py(0, Camara.Z_JUGADOR) - h / 2;

        f.setColor(new Color(0, 0, 0, 110));
        f.fillOval(sx, sy, w, h);
    }

    private void dibujarLineasDeVelocidad(GreenfootImage f)
    {
        double base = cfg.velocidadBase + GameData.auto().velocidad * 8;
        double exceso = (velocidad - base * 0.75) / 150.0;
        exceso += Math.max(0, aceleracion) * 0.9;            // acelerar suma lineas
        if (jugador != null && jugador.nitroEncendido()) exceso += 0.5;
        if (exceso <= 0.04) return;
        if (exceso > 1.4) exceso = 1.4;

        int alpha = (int) Math.min(185, exceso * 150);
        int cx = (int) (GameData.ANCHO / 2.0 - Camara.camX * Camara.escala(Camara.Z_JUGADOR));
        int cy = Camara.HORIZONTE;

        f.setColor(new Color(255, 255, 255, alpha));
        int n = 18;
        for (int i = 0; i < n; i++) {
            double ang = i * (Math.PI * 2 / n) + (scrollZ % 360) * 0.0006;
            double r1 = 220 + ((i * 53) % 90);
            double r2 = r1 + 70 + exceso * 150;
            f.drawLine(cx + (int) (Math.cos(ang) * r1), cy + (int) (Math.sin(ang) * r1 * 0.55),
                       cx + (int) (Math.cos(ang) * r2), cy + (int) (Math.sin(ang) * r2 * 0.55));
        }
    }

    private void dibujarEnSuelo(GreenfootImage f, GreenfootImage sp,
                                double x, double z, double anchoMundo, double altoMundo)
    {
        double e = Camara.FOCAL / z;
        int w = (int) (anchoMundo * e);
        int h = (int) (altoMundo * e);
        if (w < 3 || h < 3) return;

        GreenfootImage copia = new GreenfootImage(sp);
        copia.scale(w, h);
        f.drawImage(copia, Camara.px(x, z) - w / 2, Camara.py(0, z) - h);
    }

    // ==================================================================
    // SPAWNS
    // ==================================================================
    private void generarTrafico()
    {
        timerTrafico--;
        if (timerTrafico > 0) return;
        timerTrafico = cfg.framesTrafico + Greenfoot.getRandomNumber(cfg.framesTrafico);

        // PUENTE: 2 calzadas. Izquierda (carriles 0-1) = CONTRAMANO (vienen de
        // frente); derecha (2-3) = tu sentido. Sin autos por detras.
        if (cfg.puente) {
            boolean contra = Greenfoot.getRandomNumber(100) < 45;
            int c = contra ? Greenfoot.getRandomNumber(2) : 2 + Greenfoot.getRandomNumber(2);
            for (RivalCar r : getObjects(RivalCar.class))
                if (r.getCarril() == c && r.getZ() > 12000) return;
            RivalCar rc = new RivalCar(c, cfg, false);
            if (contra) rc.deFrente();
            addObject(rc, -500, -500);
            return;
        }

        int carril = Greenfoot.getRandomNumber(Camara.CARRILES);

        // castigo a quedarse quieto: si llevas ~2 s sin cambiar de carril,
        // empiezan a venir autos por atras justo en el tuyo
        boolean amodorrado = jugador != null && jugador.framesEnMismoCarril() > 110;
        boolean nosRebasa = amodorrado && avisoTimer == 0
                            && Greenfoot.getRandomNumber(100) < 45;

        if (nosRebasa) {
            avisoCarril = jugador.getCarril();
            avisoTimer = 55;
            Sonido.efecto("tic.wav");
            return;                       // el auto sale cuando termina el aviso
        }

        for (RivalCar r : getObjects(RivalCar.class)) {
            if (r.getCarril() != carril) continue;
            if (r.getZ() > 13000) return;
        }

        addObject(new RivalCar(carril, cfg, false), -500, -500);
    }

    private int timerPoste = 120;

    /** Puentes de doble calzada: farol chocable en el separador central. */
    private void generarPostes()
    {
        if (!cfg.puente || estado != 0) return;
        if (--timerPoste > 0) return;
        timerPoste = 150 + Greenfoot.getRandomNumber(120);
        addObject(new PosteMedio(24000), -500, -500);
    }

    /**
     * Los enemigos entran de a poco:
     *   - niveles 1-3  : solo helis debiles
     *   - desde nivel 4 : ademas autos de sicarios, cada vez mas seguido
     *   - niveles altos : el heli del nivel, pero 1 de cada 4 es de un tramo
     *                     anterior (asi no son todos iguales)
     */
    private void generarEnemigos()
    {
        if (estado == 3) return;      // durante el jefe los manda el jefe
        timerEnemigo--;
        if (timerEnemigo > 0) return;
        timerEnemigo = cfg.framesEnemigo + Greenfoot.getRandomNumber(90);

        int n = GameData.nivelActual;

        // autos de sicarios: recien desde el nivel 4, subiendo del 12% al 45%
        if (n >= 4 && Greenfoot.getRandomNumber(100) < Math.min(45, 8 + n)) {
            addObject(new AutoSicario(Greenfoot.getRandomNumber(Camara.CARRILES)), -500, -500);
            return;
        }

        // helis: casi siempre el del nivel; a veces uno de un tramo anterior
        if (n > 4 && Greenfoot.getRandomNumber(4) == 0) {
            int menor = 1 + Greenfoot.getRandomNumber(Math.max(1, n - 3));
            addObject(new EnemyHeli(HeliTipo.paraNivel(menor)), -500, -500);
        } else {
            addObject(new EnemyHeli(cfg.heli), -500, -500);
        }
    }

    // ==================================================================
    // NIVELES Y JEFE
    // ==================================================================
    private void finDeNivel()
    {
        int cat = categoriaJefe(GameData.nivelActual);
        if (cat >= 0 && !GameData.modoChallenge) { iniciarJefe(cat); return; }
        if (GameData.nivelActual >= GameData.NIVEL_MAX) { iniciarJefe(Boss.DON); return; }

        estado = 1;
        contador = 175;
        Sonido.efecto("nivel.wav");
        sumarPuntaje(1000 + GameData.nivelActual * 250);
        if (jugador != null) jugador.iniciarSalida(Greenfoot.getRandomNumber(3));
        addObject(new PopText("NIVEL " + GameData.nivelActual + " COMPLETO", new Color(140, 255, 180), 30),
                  GameData.ANCHO / 2, 150);

        // lo que sobra del reloj se paga en puntos
        int bonus = (tiempoRestante / 50) * 20;
        if (bonus > 0) {
            sumarPuntaje(bonus);
            addObject(new PopText("+" + bonus + " POR TIEMPO", new Color(140, 255, 180), 24),
                      GameData.ANCHO / 2, 380);
        }

        if (GameData.modoChallenge) {
            GameData.energiaCarry = jugador.getEnergia();
            GameData.tiempoCarry  = tiempoRestante + GameData.TIEMPO_CHALLENGE_BONUS;
        }
    }

    /** -1 = sin jefe; si no, Boss.MINI/SOLDADO/SICARIO/CAPO/DON. */
    private int categoriaJefe(int n)
    {
        if (n >= GameData.NIVEL_MAX) return Boss.DON;
        if (n == 30) return Boss.CAPO;
        if (n == 20) return Boss.SICARIO;
        if (n == 10) return Boss.SOLDADO;
        if (n % GameData.NIVELES_POR_JEFE == 0) return Boss.MINI;
        return -1;
    }

    private void iniciarJefe(int cat)
    {
        estado = 3;
        Sonido.efecto("jefe.wav");
        // mas tiempo para pelear (los jefes con nombre aguantan mucho)
        tiempoRestante = Math.max(tiempoRestante, 900) + (cat == Boss.MINI ? 400 : 1400);
        jefe = new Boss(cat);
        addObject(jefe, -500, -500);
        addObject(new PopText(jefe.nombre(), new Color(255, 90, 90), 36), GameData.ANCHO / 2, 300);
    }

    public void jefeDerrotado() { jefeDerrotado(true, false); }

    public void jefeDerrotado(boolean mini, boolean cartaRara)
    {
        jefe = null;
        estado = 1;
        contador = mini ? 165 : 205;
        if (jugador != null) jugador.iniciarSalida(Greenfoot.getRandomNumber(3));
        Sonido.efecto("victoria.wav");
        sumarPuntaje((mini ? 1500 : 4000) + GameData.nivelActual * 250);
        addObject(new PopText((mini ? "MINI-JEFE" : "JEFE") + " DERRIBADO", new Color(140, 255, 180), 28),
                  GameData.ANCHO / 2, 340);
        GameData.cartaGarantizada = cartaRara ? 2 : 1;   // 1 rara-o-mejor tras mini, 2 tras jefe con nombre
    }

    // ---- ataques de jefe llamados desde Boss ----
    public void tirarAuto()
    {
        int carril = Greenfoot.getRandomNumber(Camara.CARRILES);
        RivalCar r = new RivalCar(carril, cfg, true);
        addObject(r, -500, -500);
        Sonido.efecto("aviso.wav");
    }

    public void romperCalle()
    {
        addObject(new PopText("LA CALLE SE ROMPE  -  SALTA", new Color(255, 150, 60), 26),
                  GameData.ANCHO / 2, 260);
        Camara.sacudir(18);
        Sonido.efecto("choque.wav");
        // una grieta VISIBLE que se acerca: se salta o te parte
        addObject(new GrietaCalle(21000), -500, -500);
    }

    public void gameOver() { gameOver(PlayerCar.C_CHOQUE); }

    public void gameOver(int causa)
    {
        if (estado == 2) return;
        estado = 2;
        contador = 290;            // da tiempo a la cinematica de derrota
        Sonido.pararMotor();
        Sonido.efecto("derrota.wav");
        if (jugador != null) jugador.iniciarDerrota(causa);
    }

    /**
     * Mientras el contador corre, el auto sigue rodando y frena solo:
     * la ruta no se congela de golpe, se apaga.
     */
    /** Nivel ya ganado: la ruta sigue corriendo mientras el auto se va por su salida. */
    private void animarSalida()
    {
        double obj = velocidadObjetivo();
        if (velocidad < obj) velocidad += (obj - velocidad) * 0.05;
        scrollZ += velocidad;
        Camara.ajustarPorVelocidad(velocidad);
    }

    private void animarDerrota()
    {
        if (velocidad > 0.5) {
            velocidad *= 0.93;
            scrollZ += velocidad;
            Camara.ajustarPorVelocidad(velocidad);
        } else {
            velocidad = 0;
        }
        Camara.seguir(jugador != null ? jugador.getX3D() : 0);
    }

    private void avanzar()
    {
        if (estado == 2) {
            // con MODO ADMIN morir solo reinicia el nivel actual (no vuelve al nivel 1)
            if (GameData.adminMenu) { Greenfoot.setWorld(new RaceWorld()); return; }
            GameData.terminarPartida(false);
            Greenfoot.setWorld(new DefeatWorld());
            return;
        }
        if (GameData.nivelActual >= GameData.NIVEL_MAX) {
            GameData.terminarPartida(true);
            GameData.desbloquearFinal();
            Greenfoot.setWorld(new FinalComic());   // el final -> luego ResultWorld
            return;
        }
        GameData.nivelActual++;
        // roguelite: una mejora antes de CADA nivel (campana)
        if (!GameData.modoChallenge)
            Greenfoot.setWorld(new MejoraWorld());
        else
            Greenfoot.setWorld(new RaceWorld());
    }

    // ==================================================================
    // UTILIDADES
    // ==================================================================
    public void sumarPuntaje(int p)
    {
        p = (int) Math.round(p * GameData.modPuntaje);   // mejoras de puntaje
        if (GameData.modoChallenge) p *= 2;              // el challenge paga el doble
        GameData.puntajeCarrera += p;
        if (jugador != null) jugador.cargarUlti(p / 45.0);
    }

    public EnemyHeli heliMasCercano()
    {
        EnemyHeli mejor = null;
        double mejorZ = Double.MAX_VALUE;
        for (EnemyHeli h : getObjects(EnemyHeli.class)) {
            if (h.getZ() < Camara.Z_JUGADOR) continue;
            if (h.getZ() < mejorZ) { mejorZ = h.getZ(); mejor = h; }
        }
        return mejor;
    }

    public RivalCar autoMasCercano()
    {
        RivalCar mejor = null;
        double mejorZ = Double.MAX_VALUE;
        for (RivalCar r : getObjects(RivalCar.class)) {
            if (r.getZ() < Camara.Z_JUGADOR + 500) continue;
            if (r.getZ() > 14000) continue;
            if (r.getZ() < mejorZ) { mejorZ = r.getZ(); mejor = r; }
        }
        return mejor;
    }

    public int getTiempoRestante()   { return tiempoRestante; }
    public int getTiempoLimite()     { return GameData.modoChallenge
                                              ? GameData.TIEMPO_CHALLENGE_INICIAL
                                              : cfg.tiempoLimite; }
    public int getFramesTramo()      { return framesTramo; }
    public int getAvisoCarril()      { return avisoTimer > 0 ? avisoCarril : -1; }
    public int getAvisoTimer()       { return avisoTimer; }
    public Boss getJefe()            { return jefe; }
    public LevelConfig getConfig()   { return cfg; }
    public PlayerCar   getJugador()  { return jugador; }
    public double getVelocidad()     { return velocidad; }
    public double getAceleracion()   { return aceleracion; }
    public double getDistancia()     { return distancia; }
    public int    getEstado()        { return estado; }
    public int    getContador()      { return contador; }
    public int    getIntroTimer()    { return introTimer; }
}
