import greenfoot.*;

/**
 * "La calle se rompe": ataque del CAPO / EL DON. En vez de explosiones
 * que aparecen de la nada, es una GRIETA visible que se acerca con el
 * scroll. Se ve venir: hay que SALTARLA. Si te agarra en el piso, te
 * parte (dano fuerte + frenazo). Si estas en el aire, pasas limpio.
 */
public class GrietaCalle extends Objeto3D
{
    private boolean resuelta = false;

    public GrietaCalle(double z)
    {
        this.x = 0;
        this.altura = 0;
        this.z = z;
        inicializar(Sprites.grietaCalle(), 2800, 900);
    }

    public void act()
    {
        RaceWorld w = (RaceWorld) getWorld();
        if (w == null || w.congelado()) return;

        z -= w.getVelocidad();

        if (!resuelta && z <= Camara.Z_JUGADOR + 120) {
            resuelta = true;
            PlayerCar j = w.getJugador();
            if (j != null && !j.enElAire()) {
                j.recibirDano(16);
                w.frenazo(0.4);
                Camara.sacudir(26);
                Camara.golpeFocal(36);
                Sonido.efecto("choque.wav");
                w.addObject(new PopText("TE PARTIO LA CALLE", new Color(255, 90, 60), 26),
                            GameData.ANCHO / 2, 320);
                for (int i = 0; i < 6; i++)
                    w.addObject(new Humo(Greenfoot.getRandomNumber(1600) - 800, 20, z, 1.0), -500, -500);
            } else {
                w.sumarPuntaje(150);
                w.addObject(new PopText("+150  LA SALTASTE", new Color(140, 255, 180), 22),
                            GameData.ANCHO / 2, 300);
            }
        }

        if (z < Camara.Z_JUGADOR - 1500) { w.removeObject(this); return; }
        proyectar();
    }
}
