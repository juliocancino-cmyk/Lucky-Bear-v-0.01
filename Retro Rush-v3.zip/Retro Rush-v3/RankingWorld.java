import greenfoot.*;
import java.util.List;

/**
 * Ranking con las 3 secciones pedidas:
 *  - MEJOR TIEMPO (solo partidas que completaron los 10 niveles)
 *  - MEJOR PUNTAJE
 *  - GENERAL (puntaje + bonus por rapidez)
 */
public class RankingWorld extends World
{
    private MenuButton volver;

    public RankingWorld()
    {
        super(GameData.ANCHO, GameData.ALTO, 1);
        Sonido.pararMotor();
        Sonido.musica("musica_menu.wav");

        volver = new MenuButton("VOLVER", "back", 180, 54);
        addObject(volver, 120, 560);
        dibujar();
    }

    public void act()
    {
        if (volver.fueClickeado()) Greenfoot.setWorld(new MenuWorld());
    }

    private void dibujar()
    {
        GreenfootImage f = getBackground();
        f.setColor(new Color(24, 26, 38));
        f.fill();

        f.setColor(new Color(250, 205, 40));
        f.setFont(new Font("Monospaced", true, false, 40));
        f.drawString("RANKING", 40, 62);

        columna(f, 12,  "MEJOR TIEMPO",  GameData.topTiempo(),        0);
        columna(f, 210, "MEJOR PUNTAJE", GameData.topPuntaje(),       1);
        columna(f, 408, "SUPERVIVENCIA", GameData.topSupervivencia(), 3);
        columna(f, 606, "GENERAL",       GameData.topFinal(),         2);

        f.setFont(new Font("Monospaced", false, false, 15));
        f.setColor(new Color(200, 200, 210));
        f.drawString("SUPERVIVENCIA: challenge, gana quien aguanta MAS.   C = partida de challenge",
                     220, 566);
    }

    private void columna(GreenfootImage f, int x, String titulo, List<RankEntry> lista, int tipo)
    {
        f.setColor(new Color(255, 255, 255, 22));
        f.fillRect(x, 90, 182, 430);
        f.setColor(tipo == 3 ? new Color(255, 180, 90) : new Color(250, 205, 40));
        f.setFont(new Font("Monospaced", true, false, 15));
        f.drawString(titulo, x + 8, 116);

        f.setFont(new Font("Monospaced", false, false, 14));
        f.setColor(Color.WHITE);

        if (lista.isEmpty()) {
            f.drawString("sin registros", x + 8, 148);
            return;
        }

        int y = 152;
        int max = Math.min(9, lista.size());
        for (int i = 0; i < max; i++) {
            RankEntry e = lista.get(i);
            String valor;
            if (tipo == 0 || tipo == 3) valor = GameData.formatoTiempo(e.tiempoMs);
            else if (tipo == 1)         valor = "" + e.puntaje;
            else                        valor = "" + e.puntajeFinal();

            f.setColor(i == 0 ? new Color(255, 220, 90) : Color.WHITE);
            f.drawString((i + 1) + ". " + valor, x + 8, y);

            f.setFont(new Font("Monospaced", false, false, 12));
            f.setColor(e.challenge ? new Color(255, 180, 90) : new Color(170, 175, 190));
            f.drawString((e.challenge && tipo != 3 ? "C " : "") + e.auto, x + 10, y + 14);
            f.setFont(new Font("Monospaced", false, false, 14));

            y += 38;
        }
    }
}
