import greenfoot.*;

/**
 * Jefe. Cada categoria es DISTINTA (modo + aspecto + ataques):
 *
 *   MINI (5/15/25/35) - los rangos bajos de la mafia, ninguno es igual:
 *        5  EL RECLUTA  - moto, chico y nervioso, zigzaguea muy rapido
 *        15 EL PUNTERO  - camioneta con un tipo parado en la caja disparando rafagas
 *        25 EL COBRADOR - muscle blindado que se te viene encima y te tira autos
 *        35 EL TENIENTE - helicoptero ligero (mas chico que los jefes con nombre)
 *
 *   SOLDADO (10)       - helicoptero con un sicario SENTADO ATRAS disparando
 *   SICARIO (20)       - va en un auto SIEMPRE adelante tuyo, zigzagueando
 *   CAPO    (30)       - camion blindado adelante, rompe la calle y tira autos
 *   EL DON  (40, final)- una figura GIGANTE de fondo; el punto debil es su pecho
 *
 * Su barra de vida sale arriba. No se puede rebasar.
 */
public class Boss extends Objeto3D
{
    public static final int MINI = 0, SOLDADO = 1, SICARIO = 2, CAPO = 3, DON = 4;
    public static final int M_HELI = 0, M_CAR = 1, M_GIGANTE = 2;
    public static final int VIDA_MAX = 130;

    private static final String[] NOMBRES = { "MINI-JEFE", "EL SOLDADO", "EL SICARIO", "EL CAPO", "EL DON" };
    private static final String[] MINIS   = { "EL RECLUTA", "EL PUNTERO", "EL COBRADOR", "EL TENIENTE" };

    private final int cat, modo;
    private final int mini;          // 0..3 si cat==MINI; si no, -1
    private final int vidaMax;
    private int vida;
    private int fase = 1;
    private int entrada;
    private int flash = 0;
    private double t = 0;
    private double dirX = 1;
    private int carrilObj = 1, timerCarril = 60;
    private int zHold = 2400;        // a que distancia por delante se queda (modo auto)

    private int tDisp = 60, tEsc = 200, tAuto = 240, tCalle = 380;
    private int raf = 0, tRaf = 0;

    public Boss()             { this(MINI); }
    public Boss(boolean mini) { this(mini ? MINI : DON); }

    public Boss(int cat)
    {
        this.cat = cat;
        this.mini = (cat == MINI) ? idxMini() : -1;
        int n = GameData.nivelActual;

        switch (cat) {
            case SOLDADO: vidaMax = 150; modo = M_HELI;    break;
            case SICARIO: vidaMax = 230; modo = M_CAR;     break;
            case CAPO:    vidaMax = 340; modo = M_CAR;     break;
            case DON:     vidaMax = 520; modo = M_GIGANTE; break;
            default:      // MINI
                vidaMax = 40 + n * 2;
                modo = (mini == 3) ? M_HELI : M_CAR;
                break;
        }
        vida = vidaMax;

        if (cat == MINI) {
            switch (mini) {
                case 0:  // EL RECLUTA - moto
                    inicializar(Sprites.motoSicario(), 1000, 1400);
                    x = Camara.centroCarril(1); altura = 0; z = Camara.Z_JUGADOR + 8000;
                    zHold = 1900; entrada = 80;
                    break;
                case 1:  // EL PUNTERO - camioneta
                    inicializar(Sprites.camionetaBoss(), 1900, 1450);
                    x = Camara.centroCarril(2); altura = 0; z = Camara.Z_JUGADOR + 9000;
                    zHold = 2600; entrada = 90;
                    break;
                case 2:  // EL COBRADOR - muscle blindado que embiste
                    inicializar(Sprites.muscleBoss(), 1900, 1350);
                    x = Camara.centroCarril(1); altura = 0; z = Camara.Z_JUGADOR + 8000;
                    zHold = 1200; entrada = 80;
                    break;
                default: // EL TENIENTE - heli ligero
                    inicializar(Sprites.heliMini(1), 2600, 1300);
                    x = 0; altura = 1500; z = 22000;
                    zHold = 0; entrada = 90;
                    break;
            }
        } else {
            switch (modo) {
                case M_CAR:
                    inicializar(cat == CAPO ? Sprites.camionBoss() : Sprites.autoBoss(),
                                cat == CAPO ? 2600 : 2000, cat == CAPO ? 1900 : 1500);
                    x = Camara.centroCarril(1); altura = 0; z = Camara.Z_JUGADOR + 10000;
                    zHold = 2400; entrada = 90;
                    break;
                case M_GIGANTE:
                    inicializar(Sprites.donGigante(1), 20000, 13500);
                    x = 0; altura = 0; z = 34000;
                    zHold = 0; entrada = 160;
                    break;
                default:  // M_HELI (SOLDADO)
                    inicializar(Sprites.heliBoss(1), 4400, 2200);
                    x = 0; altura = 2100; z = 26000;
                    zHold = 0; entrada = 130;
                    break;
            }
        }
    }

    private static int idxMini()
    {
        int n = GameData.nivelActual;
        switch (n) { case 5: return 0; case 15: return 1; case 25: return 2; case 35: return 3; }
        int k = (n / 5) - 1;                 // fallback (challenge / niveles sueltos)
        return ((k % 4) + 4) % 4;
    }

    public boolean esMini()   { return cat == MINI; }
    public boolean esGigante(){ return modo == M_GIGANTE; }
    public boolean entrando() { return entrada > 0; }
    public String  nombre()   { return (cat == MINI) ? MINIS[mini] : NOMBRES[cat]; }
    public int getVida()      { return vida; }
    public int getVidaMax()   { return vidaMax; }
    public int getFase()      { return fase; }

    public void act()
    {
        RaceWorld w = (RaceWorld) getWorld();
        if (w == null || w.congelado()) return;
        t += 0.03;

        if (entrada > 0) {
            entrada--;
            double zDestino = modo == M_CAR ? Camara.Z_JUGADOR + zHold
                            : modo == M_GIGANTE ? 11500
                            : (cat == MINI ? 9000 : 7200);
            z += (zDestino - z) * 0.025;
        }

        actualizarFase();
        mover();
        atacar(w);
        proyectar();

        if (flash > 0) flash--;
        getImage().setTransparency((flash > 0 && flash % 6 < 3) ? 150 : 255);
    }

    private void mover()
    {
        if (modo == M_CAR) {
            boolean moto = (cat == MINI && mini == 0);
            boolean embiste = (cat == MINI && mini == 2);
            int periodo = moto ? 26 : 60;
            if (--timerCarril <= 0) {
                timerCarril = Math.max(24, periodo - fase * 10);
                carrilObj = Greenfoot.getRandomNumber(Camara.CARRILES);
            }
            double destino = Camara.centroCarril(carrilObj);
            double paso = 10 + fase * 6 + (moto ? 7 : 0);
            if (Math.abs(destino - x) > paso) x += (destino > x) ? paso : -paso;
            if (entrada == 0) {
                double amp = embiste ? 460 : 900;
                z = Camara.Z_JUGADOR + zHold + Math.sin(t) * amp;
            }
        } else if (modo == M_GIGANTE) {
            x = Math.sin(t * 0.5) * 1600;
            altura = Math.sin(t) * 120;
        } else {  // HELI
            double vel = (cat == MINI ? 9 : 11) + fase * 7;
            x += dirX * vel;
            if (Math.abs(x) > 2500) dirX = -dirX;
            altura = (cat == MINI ? 1500 : 2100) + Math.sin(t) * 200;
            z += Math.cos(t * 0.7) * 24;
        }
    }

    private void actualizarFase()
    {
        int maxFase = (cat == MINI) ? 2 : 3;
        int nueva = vida > vidaMax * 0.66 ? 1 : (vida > vidaMax * 0.33 ? 2 : 3);
        if (nueva > maxFase) nueva = maxFase;
        if (nueva != fase) {
            fase = nueva;
            if (modo == M_HELI)
                setBase(cat == MINI ? Sprites.heliMini(fase) : Sprites.heliBoss(fase));
            else if (modo == M_GIGANTE)
                setBase(Sprites.donGigante(fase));

            // los jefes con nombre anuncian la fase (mas agresivos cada una)
            if (cat >= SOLDADO && getWorld() != null) {
                ((RaceWorld) getWorld()).addObject(
                    new PopText(nombre() + "  -  FASE " + fase, new Color(255, 120, 120), 26),
                    GameData.ANCHO / 2, 150);
                Sonido.efecto("jefe.wav");
            }
        }
    }

    private void atacar(RaceWorld w)
    {
        PlayerCar j = w.getJugador();
        if (j == null || entrada > 40) return;

        // rafagas de balas
        if (raf > 0) {
            if (--tRaf <= 0) {
                tRaf = (cat == MINI && mini != 1) ? 9 : 6;
                raf--;
                double desvio = Greenfoot.getRandomNumber(1300) - 650;
                int dano = (cat == MINI ? 7 : 10) + fase * 3;
                w.addObject(new EnemyBullet(x + desvio, modo == M_CAR ? 260 : altura, z, j, dano), -500, -500);
            }
        } else if (--tDisp <= 0) {
            tDisp = Math.max(cat == MINI ? 46 : 26, 90 - fase * 18) + Greenfoot.getRandomNumber(24);
            int base = (cat == MINI) ? (mini == 1 ? 2 : mini == 0 ? 0 : 1) : 2;
            raf = base + fase;
            tRaf = 1;
        }

        // SOLDADO / DON: sicarios en autos
        if ((cat == SOLDADO || cat == DON) && --tEsc <= 0) {
            tEsc = Math.max(120, 260 - fase * 40);
            w.addObject(new AutoSicario(Greenfoot.getRandomNumber(Camara.CARRILES)), -500, -500);
        } else if (cat != SOLDADO && cat != DON && --tEsc <= 0) {
            tEsc = Math.max(cat == MINI ? 260 : 150, 300 - fase * 50);
            w.addObject(new EnemyHeli(HeliTipo.paraNivel(cat == MINI ? GameData.nivelActual : GameData.NIVEL_MAX)),
                        -500, -500);
        }

        // SICARIO / CAPO / DON y el COBRADOR: te tiran autos
        boolean tiraAutos = (cat == SICARIO || cat == CAPO || cat == DON || (cat == MINI && mini == 2));
        if (tiraAutos && --tAuto <= 0) {
            tAuto = Math.max(cat == MINI ? 150 : 80, 220 - fase * 36);
            w.tirarAuto();
        }
        // CAPO / DON: rompe la calle
        if ((cat == CAPO || cat == DON) && --tCalle <= 0) {
            tCalle = Math.max(210, 440 - fase * 60);
            w.romperCalle();
        }
    }

    public void recibirDano(int d)
    {
        vida -= d;
        flash = 10;
        RaceWorld w = (RaceWorld) getWorld();
        if (w == null) return;

        if (vida <= 0) {
            vida = 0;
            w.sumarPuntaje(cat == MINI ? 2500 + GameData.nivelActual * 120
                         : cat == DON ? 25000 : 6000 + cat * 3500);
            int n = (cat == MINI) ? 3 : (cat == DON ? 10 : 7);
            for (int i = 0; i < n; i++)
                w.addObject(new Explosion(x + Greenfoot.getRandomNumber(3000) - 1500,
                                          altura + Greenfoot.getRandomNumber(1200) - 600,
                                          z, cat == MINI ? 1600 : 3000), -500, -500);
            w.jefeDerrotado(cat == MINI, cat >= SOLDADO);
            w.removeObject(this);
        }
    }
}
