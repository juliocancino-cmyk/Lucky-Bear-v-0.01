import greenfoot.*;

/**
 * Pantalla de derrota. Perder duele: se pierde el 25% del puntaje total
 * acumulado y la carrera vuelve a empezar desde el nivel 1.
 */
public class DefeatWorld extends World
{
    private MenuButton reintentar, alMenu;
    private int nivelCaido;
    private int penalizacion;
    private int puntajeCarrera;
    private boolean challenge;
    private String tiempo;

    public DefeatWorld()
    {
        super(GameData.ANCHO, GameData.ALTO, 1);

        nivelCaido     = Math.min(GameData.nivelActual, GameData.NIVEL_MAX);
        penalizacion   = GameData.ultimaPenalizacion;
        puntajeCarrera = GameData.puntajeCarrera;
        challenge      = GameData.modoChallenge;
        tiempo         = GameData.formatoTiempo(GameData.tiempoTotalMs);

        Sonido.pararMotor();
        Sonido.musica("musica_menu.wav");
        Sonido.efecto("derrota.wav");

        reintentar = new MenuButton(GameData.modoChallenge ? "OTRO CHALLENGE" : "DESDE EL NIVEL 1",
                                    "retry", 320, 60);
        alMenu     = new MenuButton("MENU",             "menu", 200, 56);

        addObject(reintentar, 400, 452);
        addObject(alMenu,     400, 522);

        dibujar();
    }

    public void act()
    {
        if (reintentar.fueClickeado()) {
            GameData.nuevaPartida(GameData.modoChallenge);
            Greenfoot.setWorld(new RaceWorld());
        } else if (alMenu.fueClickeado()) {
            Greenfoot.setWorld(new MenuWorld());
        }
    }

    private void dibujar()
    {
        GreenfootImage f = getBackground();
        f.setColor(new Color(26, 12, 14));
        f.fill();

        // franjas rojas de fondo
        f.setColor(new Color(60, 18, 22));
        for (int y = 0; y < GameData.ALTO; y += 26) f.fillRect(0, y, GameData.ANCHO, 12);

        String titulo = challenge ? "SE ACABO" : "DESTRUIDO";
        f.setFont(new Font("Monospaced", true, false, 66));
        f.setColor(new Color(0, 0, 0, 160));
        f.drawString(titulo, 174, 116);
        f.setColor(new Color(238, 70, 70));
        f.drawString(titulo, 170, 112);

        f.setFont(new Font("Monospaced", true, false, 24));
        f.setColor(Color.WHITE);

        if (challenge) {
            f.setFont(new Font("Monospaced", true, false, 34));
            f.setColor(new Color(255, 200, 90));
            f.drawString("AGUANTASTE  " + tiempo, 150, 186);

            f.setFont(new Font("Monospaced", true, false, 24));
            f.setColor(Color.WHITE);
            f.drawString("Llegaste a la vuelta " + (GameData.vuelta + 1)
                         + ", tramo " + nivelCaido, 150, 232);
            f.drawString("Puntaje: " + puntajeCarrera + "  (x2 por challenge)", 150, 268);
            f.setColor(new Color(140, 255, 180));
            f.drawString("Sumado entero al total: " + GameData.puntajeTotal, 150, 304);

            f.setFont(new Font("Monospaced", false, false, 17));
            f.setColor(new Color(210, 200, 190));
            f.drawString("El challenge no penaliza: aqui morir es parte del juego.", 150, 350);
            f.drawString("Tu tiempo queda en la tabla de SUPERVIVENCIA.", 150, 374);
        } else {
            f.drawString("Caiste en el nivel " + nivelCaido + " de " + GameData.NIVEL_MAX, 150, 176);
            f.drawString("Puntaje de la carrera: " + puntajeCarrera + "  (perdido)", 150, 212);

            f.setColor(new Color(255, 140, 140));
            f.drawString("PENALIZACION: -" + penalizacion + " puntos totales", 150, 262);
            f.setColor(Color.WHITE);
            f.drawString("Te quedan " + GameData.puntajeTotal + " puntos totales", 150, 296);

            f.setFont(new Font("Monospaced", false, false, 17));
            f.setColor(new Color(210, 190, 190));
            f.drawString("Si bajaste del umbral de un auto, se vuelve a bloquear.", 150, 344);
            f.drawString("La proxima carrera arranca otra vez desde el nivel 1.", 150, 368);
        }
    }
}
