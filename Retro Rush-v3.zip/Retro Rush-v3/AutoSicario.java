import greenfoot.*;

/**
 * Auto de la Organizacion que te ADELANTA y, mientras va a tu lado o
 * delante, un sicario asomado te dispara. Si le pegas un par de balazos,
 * matas al sicario y deja de disparar (el auto sigue de largo).
 *
 * Reemplaza a los sicarios a pie, que no se veian bien.
 */
public class AutoSicario extends Objeto3D
{
    private final int carril;
    private final double factor;
    private int vida = 3;
    private int timer = 30;
    private int flash = 0;
    private boolean muerto = false;

    public AutoSicario(int carril)
    {
        this.carril = carril;
        this.factor = 1.12 + Greenfoot.getRandomNumber(24) / 100.0;
        x = Camara.centroCarril(carril);
        altura = 0;
        z = 260;                                   // aparece pegado por detras
        inicializar(Sprites.autoSicario(false), 400, 300);
    }

    public void act()
    {
        RaceWorld w = (RaceWorld) getWorld();
        if (w == null || w.congelado()) return;

        double v = w.getVelocidad();
        z += v * factor - v;                        // te adelanta

        PlayerCar j = w.getJugador();
        if (!muerto && j != null && z > 400 && z < 10000) {
            if (--timer <= 0) {
                timer = 42 + Greenfoot.getRandomNumber(34);
                w.addObject(new EnemyBullet(x, 220, z, j, 8), -500, -500);
                Sonido.efecto("disparo.wav");
            }
        }

        if (z < 150 || z > 26000) { w.removeObject(this); return; }

        if (flash > 0) flash--;
        proyectar();
        getImage().setTransparency((flash > 0 && flash % 4 < 2) ? 140 : 255);
    }

    public void recibirDano(int d)
    {
        if (muerto) return;
        vida -= d;
        flash = 6;
        RaceWorld w = (RaceWorld) getWorld();
        if (w == null) return;
        if (vida <= 0) {
            muerto = true;
            w.sumarPuntaje(360);
            setBase(Sprites.autoSicario(true));
            w.addObject(new Explosion(x, 120, z, 340), -500, -500);
        }
    }
}
