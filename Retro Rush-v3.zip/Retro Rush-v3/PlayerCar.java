import greenfoot.*;

/**
 * Auto del jugador.
 *
 * IZQ / DER  cambiar de carril      ARRIBA / W  saltar
 * SPACE      disparar (municion)    X           bazuca      SHIFT  nitro
 *
 * Las mejoras roguelite (GameData.mod*) se leen aqui: energia, cadencia,
 * dano, turbo, salto, etc.
 */
public class PlayerCar extends Objeto3D
{
    public enum Estado { QUIETO, CAMBIANDO_IZQUIERDA, CAMBIANDO_DERECHA, SALTANDO, CAYENDO }
    private Estado estado = Estado.QUIETO;

    // causas de muerte -> deciden la cinematica de derrota
    public static final int C_CHOQUE = 0, C_ANIMAL = 1, C_DISPARO = 2, C_TIEMPO = 3;

    public static final double DIST_CHOQUE = 350;
    public static final double DIST_ROCE   = 540;

    public static final int BALAS_MAX     = 5;
    private static final int CADENCIA     = 10;
    private static final int REGENERACION = 115;
    private static final int RECARGA      = 165;

    private static final double ALTURA_SEGURA = 150;

    // ---- salto ----
    private boolean saltando = false;
    private int tiempoSalto = 0;
    private double yInicial = 0;
    private double velocidadInicial = 95.0;
    private double gravedad = 6.2;

    // ---- animacion ----
    private int contadorAnimacion = 0;
    private int animTick = 0;
    private static final int FRAMES_ANIMACION = 3;

    private int carril = 1;
    private int framesMismoCarril = 0;

    private int energia = 100;
    private int energiaMax = 100;
    private double ulti = 0;
    private int regenEneTimer = 0;
    private boolean primerGolpeBloqueado = false;

    private int balas;
    private int balasMax;
    private int cadenciaEf;
    private int regenEf;
    private int recargaEf;
    private int cooldownDisparo = 0;
    private int timerRegen = 0;
    private int recargando = 0;

    private int invulnerable = 0;
    private boolean nitroActivo = false;

    // ULTI temporizada: 1 sobrecarga (GT), 2 fase (HYPER), 3 escudo (PATRULLA)
    private int ultiActivo = 0;
    private int ultiEfecto = 0;

    // ---- derrota / cinematicas ----
    public static final int M_VAN=0, M_ARBOL=1, M_VUELCO=2, M_FUEGO=3, M_OVNI=4,
                            M_BARRANCO=5, M_METEORITO=6, M_RAYO=7, M_EXPLOTA=8,
                            M_HUNDE=9, M_POLVO=10, M_PORTAL=11, M_BESTIA=12,
                            M_ABANDONO=13, M_GARRA=14;
    public static final int TOTAL_MUERTES = 15;
    public static final int M_FIRMA = 99;    // muerte exclusiva del modelo de auto
    public static final int M_CATALOGO = 100; // una de las 130 del catalogo Muerte

    private Muerte muerteActual;

    private boolean modoDerrota = false;
    private int     tDerrota = 0;
    private int     tipoMuerte = 0;
    private double  xOrilla = 0;
    private boolean bajaron = false;
    private double  anguloVuelco = 0;
    private int     alphaDerrota = 255;
    private MafiaVehiculo van;

    // cinematica de FIN DE NIVEL (el auto se va): 0 salida derecha, 1 salida izquierda, 2 recto
    private boolean modoSalida = false;
    private int     salidaModo = 0, tSalida = 0;

    private Pilotos pilotos;
    private CarType tipo;

    private boolean izqPrev, derPrev, espPrev, xPrev, saltoPrev, nitroPrev;
    private double derrapeX = 0;

    public PlayerCar()
    {
        tipo = GameData.auto();
        pilotos = new Pilotos(tipo);
        inicializar(Sprites.autoTrasero(tipo.cuerpo, tipo.detalle, tipo.modelo), 470, 352);
        x = Camara.centroCarril(carril);
        altura = 0;
        z = Camara.Z_JUGADOR;

        // ---- aplicar mejoras roguelite ----
        energiaMax = Math.max(30, 100 + GameData.modEnergiaMax);
        energia = energiaMax;
        if (GameData.modoChallenge && GameData.energiaCarry > 0)
            energia = Math.min(energiaMax, GameData.energiaCarry);
        energia = Math.min(energiaMax, energia + GameData.modArranqueEnergia);
        ulti = GameData.modArranqueUlti;

        balasMax   = GameData.diosBalas ? 99 : Math.max(1, BALAS_MAX + GameData.modBalas);
        balas      = balasMax;
        cadenciaEf = GameData.diosBalas ? 4 : Math.max(3, (int) Math.round(CADENCIA * GameData.modCadencia));
        regenEf    = Math.max(12, (int) Math.round(REGENERACION * GameData.modRegenBalas));
        recargaEf  = Math.max(30, (int) Math.round(RECARGA * GameData.modRecarga));

        velocidadInicial *= (0.6 + 0.4 * GameData.modSalto);
        gravedad         /= Math.max(0.5, GameData.modSalto);
    }

    // ==================================================================
    public void act()
    {
        RaceWorld w = (RaceWorld) getWorld();
        if (w == null) return;

        if (modoDerrota) {
            animarDerrota(w);
            proyectar();
            if (alphaDerrota < 255) getImage().setTransparency(Math.max(0, alphaDerrota));
            return;
        }

        if (modoSalida) { animarSalidaCine(w); return; }

        if (w.getEstado() != 2 && !w.congelado()) {
            controlarEntradas(w);
            moverLateral();
            actualizarSalto();
            revisarColisiones(w);
            gestionarMunicion();

            // el SLIDE-X echa humo de neumatico mientras derrapa
            if (tipo.derrapa && Math.abs(derrapeX) > 40 && Greenfoot.getRandomNumber(2) == 0) {
                double lado = derrapeX > 0 ? -150 : 150;
                w.addObject(new Humo(x + lado, 14, z - 30, 0.55), -500, -500);
            }

            if (cooldownDisparo > 0) cooldownDisparo--;
            if (invulnerable > 0) invulnerable--;
            if (avisoBarrera > 0) avisoBarrera--;
            if (GameData.diosUlti) ulti = 100;               // ULTI infinita (admin)
            if (ultiActivo > 0 && --ultiActivo == 0) ultiEfecto = 0;
            framesMismoCarril++;
            pilotos.act();

            if (GameData.modRegenEnergia && ++regenEneTimer >= 120) {
                regenEneTimer = 0;
                if (energia < energiaMax) energia++;
            }
        }

        actualizarAnimacion();
        proyectar();
        getImage().setTransparency((invulnerable > 0 && invulnerable % 8 < 4) ? 120 : 255);
    }

    private void controlarEntradas(RaceWorld w)
    {
        boolean izq   = Greenfoot.isKeyDown("left")  || Greenfoot.isKeyDown("a");
        boolean der   = Greenfoot.isKeyDown("right") || Greenfoot.isKeyDown("d");
        boolean salto = Greenfoot.isKeyDown("up")    || Greenfoot.isKeyDown("w");
        boolean esp   = Greenfoot.isKeyDown("space");
        boolean equis = Greenfoot.isKeyDown("x");

        // en un PUENTE, la barrera central (entre carril 1 y 2) hay que
        // SALTARLA: no se puede cruzar por el piso.
        boolean muro = w.getConfig() != null && w.getConfig().puente && !enElAire();

        if (izq && !izqPrev && carril > 0) {
            if (muro && carril == 2) chocarBarrera(w);
            else                     cambiarCarril(-1);
        }
        if (der && !derPrev && carril < Camara.CARRILES - 1) {
            if (muro && carril == 1) chocarBarrera(w);
            else                     cambiarCarril(1);
        }
        if (salto && !saltoPrev)                             iniciarSalto();
        if (esp && !espPrev)                                 disparar(w);
        if (equis && !xPrev)                                 usarUlti(w);

        double gasto = (tipo.habilidad == CarType.NITRO) ? 0.55 : 1.10;
        nitroActivo = Greenfoot.isKeyDown("shift") && (ulti > 0 || GameData.diosTurbo);
        if (nitroActivo && !GameData.diosTurbo) { ulti -= gasto; if (ulti < 0) ulti = 0; }
        if (nitroActivo && !nitroPrev) { Camara.golpeFocal(-30); Camara.sacudir(6); }
        if (!nitroActivo && nitroPrev) Camara.golpeFocal(16);
        nitroPrev = nitroActivo;

        izqPrev = izq; derPrev = der; espPrev = esp; xPrev = equis; saltoPrev = salto;
    }

    private int avisoBarrera = 0;

    /** Intentaste cruzar la barrera del puente por el piso: rebotas. */
    private void chocarBarrera(RaceWorld w)
    {
        if (avisoBarrera > 0) return;
        avisoBarrera = 34;
        Sonido.efecto("choque.wav");
        Camara.sacudir(9);
        w.frenazo(0.86);
        w.addObject(new PopText("SALTA LA BARRERA", new Color(255, 180, 60), 24),
                    GameData.ANCHO / 2, 300);
    }

    private void cambiarCarril(int d)
    {
        carril += d;
        framesMismoCarril = 0;
        if (!saltando) {
            estado = (d < 0) ? Estado.CAMBIANDO_IZQUIERDA : Estado.CAMBIANDO_DERECHA;
            if (tipo.derrapa) derrapeX = d * 150;
        }
    }

    private void moverLateral()
    {
        derrapeX *= 0.85;
        if (Math.abs(derrapeX) < 1.5) derrapeX = 0;

        double destino = Camara.centroCarril(carril) + derrapeX;
        double paso = 8 + tipo.manejo * 2.4;
        if (tipo.derrapa) paso += 7;

        if (Math.abs(destino - x) <= paso) {
            x = destino;
            if (!saltando && derrapeX == 0) estado = Estado.QUIETO;
        } else {
            x += (destino > x) ? paso : -paso;
        }
    }

    public double getDerrape() { return derrapeX; }

    // ==================================================================
    // SALTO
    // ==================================================================
    private void iniciarSalto()
    {
        if (saltando) return;
        saltando = true;
        tiempoSalto = 0;
        yInicial = 0;
        estado = Estado.SALTANDO;
        Sonido.efecto("salto.wav");
    }

    private void actualizarSalto()
    {
        if (!saltando) { altura = 0; return; }
        tiempoSalto++;
        double y = yInicial - velocidadInicial * tiempoSalto
                 + 0.5 * gravedad * tiempoSalto * tiempoSalto;
        if (y >= yInicial && tiempoSalto > 1) {
            y = yInicial; saltando = false; estado = Estado.QUIETO;
        } else {
            estado = (tiempoSalto < velocidadInicial / gravedad) ? Estado.SALTANDO : Estado.CAYENDO;
        }
        altura = -y;
    }

    public boolean enElAire() { return altura > ALTURA_SEGURA; }
    public double alturaSalto() { return altura; }

    // ==================================================================
    // ANIMACION
    // ==================================================================
    private void actualizarAnimacion()
    {
        contadorAnimacion++;
        if (contadorAnimacion < FRAMES_ANIMACION) return;
        contadorAnimacion = 0;

        GreenfootImage img = Sprites.autoTrasero(tipo.cuerpo, tipo.detalle, tipo.modelo);
        efectoEspecial(img);
        pilotos.dibujar(img);

        if (estado == Estado.SALTANDO)     img.rotate(-4);
        else if (estado == Estado.CAYENDO) img.rotate(4);
        else if (Math.abs(derrapeX) > 24)  img.rotate(derrapeX > 0 ? 7 : -7);

        setBase(img);
    }

    private void efectoEspecial(GreenfootImage img)
    {
        animTick++;
        switch (tipo.habilidad) {
            case CarType.NITRO:  if (nitroActivo)                      postquemador(img);     break;
            case CarType.ESCUDO: if (invulnerable > 0)                 placasEscudo(img);     break;
            case CarType.DOBLE:  if (cooldownDisparo > cadenciaEf - 5) canonesLaterales(img); break;
        }
    }

    private void postquemador(GreenfootImage img)
    {
        int W = 200;
        int fr = animTick % 3;
        Color az = new Color(130, 205, 255, 235);
        Color bl = new Color(255, 244, 190, 235);
        if (tipo.modelo == CarType.M_PROTO) {
            img.setColor(new Color(130, 205, 255, 150));
            img.fillOval(50, 94, W - 100, 42 + fr * 4);
            img.setColor(az);
            img.fillOval(74, 98, W - 148, 34 + fr * 3);
            img.setColor(bl);
            img.fillOval(92, 102, W - 184, 24);
        } else {
            int[] xs = { 74, W - 90 };
            for (int i = 0; i < xs.length; i++) {
                int xx = xs[i];
                img.setColor(az);
                img.fillPolygon(new int[]{xx, xx + 16, xx + 8}, new int[]{118, 118, 148 - fr * 3}, 3);
                img.setColor(bl);
                img.fillPolygon(new int[]{xx + 4, xx + 12, xx + 8}, new int[]{120, 120, 140 - fr * 3}, 3);
            }
        }
    }

    private void placasEscudo(GreenfootImage img)
    {
        int W = 200, H = 150;
        if ((invulnerable / 3) % 2 == 0) {
            img.setColor(new Color(120, 205, 255, 115));
            img.drawOval(-8, 34, W + 16, H - 20);
            img.drawOval(-4, 38, W + 8, H - 28);
        }
        img.setColor(new Color(150, 215, 255, 210));
        img.fillRect(-2, 82, 12, 34);
        img.fillRect(W - 10, 82, 12, 34);
        img.setColor(new Color(120, 205, 255, 150));
        img.fillRect(40, 16, W - 80, 7);
    }

    private void canonesLaterales(GreenfootImage img)
    {
        int W = 200;
        img.setColor(new Color(45, 48, 55));
        img.fillRect(0, 90, 24, 16);
        img.fillRect(W - 24, 90, 24, 16);
        img.setColor(new Color(28, 30, 36));
        img.fillRect(18, 95, 12, 6);
        img.fillRect(W - 30, 95, 12, 6);
        if (cooldownDisparo > cadenciaEf - 3) {
            img.setColor(new Color(255, 220, 120, 235));
            img.fillOval(22, 90, 18, 16);
            img.fillOval(W - 40, 90, 18, 16);
        }
    }

    public Estado getEstadoActual() { return estado; }

    // ==================================================================
    // MUNICION
    // ==================================================================
    private void gestionarMunicion()
    {
        if (GameData.diosBalas) { balas = balasMax; recargando = 0; return; }
        if (recargando > 0) {
            recargando--;
            if (recargando == 0) balas = balasMax;
            return;
        }
        if (balas >= balasMax) return;
        timerRegen++;
        if (timerRegen >= regenEf) { timerRegen = 0; balas++; }
    }

    private void disparar(RaceWorld w)
    {
        if (cooldownDisparo > 0 || recargando > 0) return;

        if (balas <= 0 && !GameData.diosBalas) {
            recargando = recargaEf;
            Sonido.efecto("recarga.wav");
            w.addObject(new PopText("RECARGANDO", new Color(255, 200, 90), 22), GameData.ANCHO / 2, 300);
            return;
        }

        if (!GameData.diosBalas) balas--;
        cooldownDisparo = cadenciaEf;
        pilotos.forzar(Pilotos.DISPARAR, 16);
        Sonido.efecto("disparo.wav");

        Objeto3D objetivo = w.getJefe() != null ? w.getJefe() : w.heliMasCercano();
        w.addObject(new Bullet(x + 130, altura + 165, z + 130, objetivo), -500, -500);

        // DOBLE (o la mejora DOBLE CANON): dispara 2 balas gastando SOLO 1
        if (tipo.habilidad == CarType.DOBLE || GameData.modBalaDoble)
            w.addObject(new Bullet(x - 130, altura + 165, z + 130, objetivo), -500, -500);

        if (balas <= 0 && !GameData.diosBalas) { recargando = recargaEf; Sonido.efecto("recarga.wav"); }
    }

    /** ULTI (tecla X): cada auto tiene la suya. Ver CarType.ultiNombre/Desc. */
    private void usarUlti(RaceWorld w)
    {
        if (ulti < 100 || GameData.modSinUlti) return;
        ulti = 0;
        pilotos.forzar(Pilotos.BAZUCA, 34);
        Sonido.efecto("bazuca.wav");
        Camara.sacudir(16);
        w.addObject(new PopText(tipo.ultiNombre() + "!", new Color(255, 220, 90), 30),
                    GameData.ANCHO / 2, 300);

        switch (tipo.modelo) {
            case CarType.M_CLASICO:  ultiEmbestida(w, 4200);              break;
            case CarType.M_RALLY:    ultiEmbestida(w, 5200); energia = Math.min(energiaMax, energia + 15); break;
            case CarType.M_GT:       ultiTemporizada(1, 240);            break;
            case CarType.M_SUPER:    ultiTemporizada(2, 240);            break;
            case CarType.M_DRIFT:    ultiAbanico(w, 8);                  break;
            case CarType.M_DERRAPA:  ultiAbanico(w, 10); ultiHumo(w);    break;
            case CarType.M_PATRULLA: ultiBloqueo(w);                     break;
            case CarType.M_PROTO:    ultiPulso(w);                       break;
            default:                 ultiAbanico(w, 6);                  break;
        }
    }

    private void ultiTemporizada(int efecto, int frames)
    {
        ultiEfecto = efecto;
        ultiActivo = frames;
        invulnerable = frames + 12;
        Camara.golpeFocal(-40);
    }

    private void ultiEmbestida(RaceWorld w, double alcance)
    {
        invulnerable = Math.max(invulnerable, 90);
        for (RivalCar r : w.getObjects(RivalCar.class)) {
            if (r.getZ() > z && r.getZ() < z + alcance) r.destruir();
        }
        for (Fauna fx : w.getObjects(Fauna.class)) {
            if (fx.esAereo()) continue;
            if (fx.getZ() > z - 300 && fx.getZ() < z + alcance) w.removeObject(fx);
        }
        w.addObject(new Explosion(x, 150, z + 500, 1600), -500, -500);
        Camara.sacudir(22);
    }

    private void ultiAbanico(RaceWorld w, int n)
    {
        Objeto3D obj = w.getJefe();
        for (int i = 0; i < n; i++) {
            double off = (i - (n - 1) / 2.0) * 90;
            Objeto3D t = obj;
            if (t == null) {
                java.util.List<EnemyHeli> hs = w.getObjects(EnemyHeli.class);
                if (!hs.isEmpty()) t = hs.get(i % hs.size());
                else t = w.heliMasCercano();
            }
            w.addObject(new Bullet(x + off, altura + 165, z + 120, t), -500, -500);
        }
    }

    private void ultiHumo(RaceWorld w)
    {
        for (int i = -2; i <= 2; i++)
            w.addObject(new Humo(x + i * 220, 30, z - 60, 1.4), -500, -500);
    }

    private void ultiBloqueo(RaceWorld w)
    {
        int pts = 0;
        for (RivalCar r : w.getObjects(RivalCar.class)) { r.rebotar(); pts += 120; }
        w.sumarPuntaje(pts + 400);
        ultiEfecto = 3;            // escudo temporal
        ultiActivo = 180;
        invulnerable = Math.max(invulnerable, 60);
    }

    private void ultiPulso(RaceWorld w)
    {
        for (EnemyHeli h : w.getObjects(EnemyHeli.class)) h.recibirDano(999);
        for (RivalCar r : w.getObjects(RivalCar.class)) r.rebotar();
        w.sumarPuntaje(1500);
        w.addObject(new Explosion(x, 400, z + 200, 3200), -500, -500);
        Camara.sacudir(28);
        Camara.golpeFocal(30);
    }

    // ==================================================================
    // COLISIONES
    // ==================================================================
    private double distRoce() { return DIST_ROCE * (GameData.modImanPuntos ? 1.6 : 1.0); }

    private void revisarColisiones(RaceWorld w)
    {
        if (enElAire()) return;

        if (invulnerable == 0) {
            for (Fauna f : w.getObjects(Fauna.class)) {
                if (f.esAereo()) continue;
                if (Math.abs(f.getZ() - z) > 420) continue;
                if (Math.abs(f.getX3D() - x) > 500) continue;
                atropellar(w, f);
                return;
            }
        }

        double dr = distRoce();
        java.util.List<RivalCar> golpe = new java.util.ArrayList<RivalCar>();
        for (RivalCar r : w.getObjects(RivalCar.class)) {
            if (Math.abs(r.getZ() - z) > 320) continue;
            double dx = Math.abs(r.getX3D() - x);
            if (dx < DIST_CHOQUE) golpe.add(r);
            else if (dx < dr && !r.roceContado) { r.roceContado = true; rozar(w, r, dx); }
        }

        if (invulnerable == 0 && !golpe.isEmpty()) {
            if (golpe.size() >= 2) chocarMultiple(w, golpe);
            else                   chocar(w, golpe.get(0));
            return;
        }

        // farol del separador central (puentes): solo choca si vas cruzando
        // la barrera del medio. Se puede saltar por encima.
        if (invulnerable == 0) {
            for (PosteMedio pm : w.getObjects(PosteMedio.class)) {
                if (Math.abs(pm.getZ() - z) > 260) continue;
                if (Math.abs(pm.getX3D() - x) > 200) continue;
                chocarPoste(w, pm);
                return;
            }
        }
    }

    private void chocarPoste(RaceWorld w, PosteMedio pm)
    {
        invulnerable = 55 + GameData.modInvuln;
        Sonido.efecto("choque.wav");
        w.frenazo(0.42);
        w.addObject(new Explosion(pm.getX3D(), 120, pm.getZ(), 520), -500, -500);
        w.addObject(new PopText("LA BARRERA DEL MEDIO!", new Color(255, 150, 60), 24), GameData.ANCHO / 2, 322);
        w.removeObject(pm);
        x = (x >= 0) ? Camara.centroCarril(2) : Camara.centroCarril(1);   // te devuelve a un carril
        danar(18, C_CHOQUE);
    }

    private void rozar(RaceWorld w, RivalCar r, double dx)
    {
        double dr = distRoce();
        double cercania = (dr - dx) / (dr - DIST_CHOQUE);
        cercania = Math.max(0, Math.min(1, cercania));
        int puntos = (int) ((40 + cercania * 120) * GameData.modRoce);
        w.sumarPuntaje(puntos);
        Sonido.efecto("roce.wav");
        Color c = cercania > 0.65 ? new Color(255, 220, 80) : new Color(190, 240, 255);
        w.addObject(new PopText("+" + puntos + (cercania > 0.65 ? " ROCE!" : " ROCE"), c, 22),
                    r.getX(), r.getY() - 20);
    }

    /**
     * Dano central. Los que llaman ya comprobaron invulnerabilidad y pusieron
     * los frames de gracia; aqui solo se aplica escudo del auto + blindaje
     * roguelite + escudo de nivel + revivir.
     */
    private void danar(int base, int causa)
    {
        if (GameData.diosVida) return;   // vida infinita

        RaceWorld w = (RaceWorld) getWorld();

        // escudo temporal de la ULTI de la PATRULLA
        if (ultiActivo > 0 && ultiEfecto == 3) {
            if (w != null) w.addObject(new PopText("BLOQUEADO", new Color(150, 220, 255), 22),
                                       GameData.ANCHO / 2, 300);
            return;
        }

        if (GameData.modEscudoInicial && !primerGolpeBloqueado) {
            primerGolpeBloqueado = true;
            if (w != null) w.addObject(new PopText("BLOQUEADO", new Color(150, 220, 255), 24),
                                       GameData.ANCHO / 2, 300);
            return;
        }

        double f = (tipo.habilidad == CarType.ESCUDO ? 0.5 : 1.0) * GameData.modDanoRecibido;
        energia -= Math.max(1, (int) Math.round(base * f));
        if (energia > 0) return;

        if (GameData.modRevivir && !GameData.revivirUsado) {
            GameData.revivirUsado = true;
            energia = 40;
            invulnerable = 130 + GameData.modInvuln;
            if (w != null) w.addObject(new PopText("SEGUNDA VIDA", new Color(120, 255, 160), 30),
                                       GameData.ANCHO / 2, 300);
            return;
        }
        energia = 0;
        if (w != null) w.gameOver(causa);
    }

    private void chocar(RaceWorld w, RivalCar r)
    {
        boolean escudo = tipo.habilidad == CarType.ESCUDO;
        boolean encadenado = w.getVelocidad() < w.velocidadObjetivo() * 0.55;

        invulnerable = 60 + GameData.modInvuln;
        Sonido.efecto("choque.wav");
        r.rebotar();

        if (encadenado) {
            w.frenazo(escudo ? 0.32 : 0.16, escudo ? 42 : 26);
            w.addObject(new PopText("CHOQUE EN CADENA", new Color(255, 120, 60), 28), GameData.ANCHO / 2, 322);
        } else {
            w.frenazo(escudo ? 0.66 : 0.48);
            w.addObject(new PopText("CHOQUE", new Color(255, 90, 90), 30), GameData.ANCHO / 2, 330);
        }
        w.addObject(new Explosion(x, 140, z + 200, 500), -500, -500);
        if (GameData.modExplotaChoque)
            w.addObject(new Explosion(x, 150, z + 60, 1200), -500, -500);

        danar(22, C_CHOQUE);
    }

    private void chocarMultiple(RaceWorld w, java.util.List<RivalCar> autos)
    {
        boolean escudo = tipo.habilidad == CarType.ESCUDO;
        invulnerable = 72 + GameData.modInvuln;
        Sonido.efecto("choque.wav");
        w.frenazo(escudo ? 0.26 : 0.14, escudo ? 40 : 24);
        for (RivalCar r : autos) r.rebotar();
        w.addObject(new PopText("CHOQUE MULTIPLE", new Color(255, 80, 80), 32), GameData.ANCHO / 2, 320);
        w.addObject(new Explosion(x, 150, z + 200, 760), -500, -500);
        if (GameData.modExplotaChoque)
            w.addObject(new Explosion(x, 150, z + 60, 1400), -500, -500);
        danar(40, C_CHOQUE);
    }

    private void atropellar(RaceWorld w, Fauna f)
    {
        invulnerable = 78 + GameData.modInvuln;
        Sonido.efecto("choque.wav");
        w.frenazo(0.0, 0);
        w.addObject(new PopText("ANIMAL!", new Color(255, 140, 60), 32), GameData.ANCHO / 2, 322);
        w.addObject(new Explosion(f.getX3D(), 140, f.getZ(), 640), -500, -500);
        w.removeObject(f);
        danar(34, C_ANIMAL);
    }

    public void recibirDano(int d)
    {
        if (invulnerable > 0) return;
        Sonido.efecto("impacto.wav");
        invulnerable = 55 + GameData.modInvuln;
        danar(d, C_DISPARO);
    }

    // ==================================================================
    // DERROTA — cinematica segun la causa
    // ==================================================================
    public void iniciarDerrota() { iniciarDerrota(C_CHOQUE); }

    public void iniciarDerrota(int causa)
    {
        if (modoDerrota) return;
        modoDerrota = true;
        tDerrota = 0;
        invulnerable = 0;
        saltando = false;
        altura = 0;
        ultiActivo = 0;

        // 18% una muerte de FIRMA (propia del auto), 82% una del catalogo de 130
        if (Greenfoot.getRandomNumber(100) < 18) {
            tipoMuerte = M_FIRMA;
        } else {
            tipoMuerte = M_CATALOGO;
            RaceWorld rw = (RaceWorld) getWorld();
            String bioma = (rw != null && rw.getConfig() != null) ? rw.getConfig().paleta.nombre : null;
            muerteActual = Muerte.alAzar(causa, bioma);
        }

        double borde = Camara.SEMI_RUTA - 130;
        xOrilla = (x >= 0) ? borde : -borde;
        setBase(Sprites.autoRoto(tipo.cuerpo, tipo.detalle, tipo.modelo));
    }

    private int pick(int... o) { return o[Greenfoot.getRandomNumber(o.length)]; }

    // ==================================================================
    // FIN DE NIVEL - el auto se va (no es una derrota)
    // ==================================================================
    /** modo: 0 salida a la derecha, 1 salida a la izquierda, 2 sigue recto y se aleja. */
    public void iniciarSalida(int modo)
    {
        if (modoSalida || modoDerrota) return;
        modoSalida = true;
        salidaModo = ((modo % 3) + 3) % 3;
        tSalida = 0;
        saltando = false;
        altura = 0;
    }

    private void animarSalidaCine(RaceWorld w)
    {
        tSalida++;
        if (tSalida > 10) {
            if (salidaModo == 2) {                 // sigue recto y se hace chico
                z += 70 + tSalida * 3.0;
                if (tSalida > 42) alphaDerrota = Math.max(0, alphaDerrota - 7);
            } else {                               // toma una salida lateral
                int lado = (salidaModo == 0) ? 1 : -1;
                x += lado * (8 + tSalida * 0.7);
                z += 30;
                if (tSalida > 34) alphaDerrota = Math.max(0, alphaDerrota - 7);
            }
            if (w != null && tSalida % 5 == 0)
                w.addObject(new Humo(x, 12, z - 40, 0.5), -500, -500);
        }
        proyectar();
        if (alphaDerrota < 255) getImage().setTransparency(Math.max(0, alphaDerrota));
    }

    // ------------------------------------------------------------------
    // ROTACION SIN RECORTE
    // GreenfootImage.rotate() gira DENTRO del mismo lienzo: si el auto es
    // mas ancho que alto, al girarlo se le cortan las puntas (bug del
    // "se corta el vehiculo al dar vueltas"). Solucion: meterlo en un
    // lienzo cuadrado del tamano de la diagonal ANTES de rotar.
    // ------------------------------------------------------------------
    private boolean spriteCuadrado = false;
    private double  factorCuadrado = 1.0;

    private void setRotado(GreenfootImage sp, double ang) { setRotado(sp, ang, 1.0); }

    private void setRotado(GreenfootImage sp, double ang, double escala)
    {
        int d = (int) Math.ceil(Math.hypot(sp.getWidth(), sp.getHeight())) + 2;
        GreenfootImage lienzo = new GreenfootImage(d, d);
        lienzo.drawImage(sp, (d - sp.getWidth()) / 2, (d - sp.getHeight()) / 2);
        lienzo.rotate((int) ang);
        super.setBase(lienzo);
        spriteCuadrado = true;
        factorCuadrado = Math.max(0.05, escala);
    }

    /** Cualquier setBase "normal" vuelve a modo sprite sin cuadrar. */
    @Override
    protected void setBase(GreenfootImage nueva)
    {
        spriteCuadrado = false;
        factorCuadrado = 1.0;
        super.setBase(nueva);
    }

    @Override
    protected void proyectar()
    {
        if (!spriteCuadrado) { super.proyectar(); return; }

        double e = Camara.escala(z);
        int lado = (int) (Math.max(anchoMundo, altoMundo) * factorCuadrado * e);
        if (lado < 2) { setLocation(-500, -500); return; }

        GreenfootImage img = new GreenfootImage(base);
        img.scale(lado, lado);
        setImage(img);
        setLocation(Camara.px(x, z), Camara.py(altura, z) - lado / 2);
    }

    /** Nombre de la muerte que acaba de pasar (para el HUD). */
    public String nombreMuerte()
    {
        if (tipoMuerte == M_FIRMA) return "FIRMA: " + tipo.nombre;
        return muerteActual != null ? muerteActual.nombre : "DESTRUIDO";
    }

    private void animarDerrota(RaceWorld w)
    {
        tDerrota++;
        if (tipoMuerte == M_FIRMA) { firmaDeAuto(w); return; }

        switch (muerteActual.tmpl) {
            case Muerte.T_ORILLA:        mOrilla(w);        break;
            case Muerte.T_LLORA:         mOrilla(w);        break;
            case Muerte.T_PROP:          mProp(w);          break;
            case Muerte.T_VUELCO:        mVuelco(w);        break;
            case Muerte.T_INCENDIO:      mIncendio(w);      break;
            case Muerte.T_DETONA:        mDetona(w);        break;
            case Muerte.T_EXPLOTA:       mDetona(w);        break;
            case Muerte.T_CAIDA:         mCaida(w);         break;
            case Muerte.T_DESINTEGRA:    mDesintegra(w);    break;
            case Muerte.T_HUNDE:         mHunde(w);         break;
            case Muerte.T_PORTAL:        mPortal(w);        break;
            case Muerte.T_CAE:           mCae(w);           break;
            case Muerte.T_CRIATURA:      mCriatura(w);      break;
            case Muerte.T_MAQUINA:       mMaquina(w);       break;
            case Muerte.T_RAYO:          mRayo(w);          break;
            case Muerte.T_GIRA:          mGira(w);          break;
            case Muerte.T_ABANDONO:      mAbandono(w);      break;
            case Muerte.T_APLASTA:       mAplasta(w);       break;
            case Muerte.T_MOTOR:         mMotor(w);         break;
            case Muerte.T_MAFIA_BOX:     mMafiaBox(w);      break;
            case Muerte.T_MAFIA_KIDNAP:  mMafiaKidnap(w);   break;
            case Muerte.T_MAFIA_DRIVEBY: mMafiaDriveby(w);  break;
            case Muerte.T_CLIMA:         mClima(w);         break;
            case Muerte.T_CHISTE:        mChiste(w);        break;
            default:                     mOrilla(w);        break;
        }
    }

    // ==================================================================
    // MUERTES DE FIRMA — una exclusiva por modelo de auto
    // ==================================================================
    private void firmaDeAuto(RaceWorld w)
    {
        switch (tipo.modelo) {
            case CarType.M_CLASICO:  firmaClasico(w);  break;
            case CarType.M_RALLY:    firmaRally(w);    break;
            case CarType.M_GT:       firmaGT(w);       break;
            case CarType.M_DRIFT:    firmaDrift(w);    break;
            case CarType.M_PATRULLA: firmaPatrulla(w); break;
            case CarType.M_DERRAPA:  firmaSlide(w);    break;
            case CarType.M_SUPER:    firmaHyper(w);    break;
            case CarType.M_PROTO:    firmaProto(w);    break;
            default:                 derrotaFuego(w);  break;
        }
    }

    // CLASICO 84: el bloque del motor sale volando por el capo
    private void firmaClasico(RaceWorld w)
    {
        orillarse(6.0);
        if (tDerrota == 14) {
            w.addObject(new PopText("SE SALIO EL MOTOR", new Color(255, 170, 90), 24),
                        GameData.ANCHO / 2, 290);
            w.addObject(new Escombro(Sprites.bloqueMotor(), x, z + 2600, 320, 260), -500, -500);
            w.addObject(new Explosion(x, 150, z + 40, 700), -500, -500);
            Camara.sacudir(16);
        }
        humo(w, 5, 300);
        if (!bajaron && tDerrota > 60) { bajaron = true; bajarTripulacion(w, Ocupante.LLORA, Ocupante.ALEJARSE, 0); }
    }

    // RALLY RS: tonel lateral por el terraplen, polvareda
    private void firmaRally(RaceWorld w)
    {
        int fuera = (xOrilla >= 0) ? 1 : -1;
        x += fuera * 20;
        anguloVuelco += 20;
        altura += Math.sin(tDerrota * 0.4) * 4;
        setRotado(Sprites.autoRoto(tipo.cuerpo, tipo.detalle, tipo.modelo), anguloVuelco);
        if (tDerrota % 2 == 0)
            w.addObject(new Humo(x, 10 + Greenfoot.getRandomNumber(120), z, 1.1), -500, -500);
        if (tDerrota == 6) Sonido.efecto("choque.wav");
        if (!bajaron && tDerrota > 110) { bajaron = true; bajarTripulacion(w, Ocupante.CRAWL, Ocupante.CRAWL, 0); }
    }

    // TURBO GT: el turbo se sobrepresiona, mortal, y el auto da un mortal hacia atras
    private void firmaGT(RaceWorld w)
    {
        orillarse(4.0);
        if (tDerrota < 26) {
            anguloVuelco += 15;
            altura += (tDerrota < 13 ? 26 : -26);
            setRotado(Sprites.autoRoto(tipo.cuerpo, tipo.detalle, tipo.modelo), anguloVuelco);
        }
        if (tDerrota == 4) {
            w.addObject(new PopText("SOBREPRESION", new Color(140, 210, 255), 24), GameData.ANCHO / 2, 290);
            w.addObject(new Explosion(x, 120, z, 900), -500, -500);
            Camara.golpeFocal(-46);
        }
        if (tDerrota == 26) { setBase(aplastado()); w.addObject(new Explosion(x, 150, z, 1000), -500, -500); Camara.sacudir(24); }
        humo(w, 8, 300);
    }

    // DRIFT KING: trompo cada vez mas rapido hasta salir volando
    private void firmaDrift(RaceWorld w)
    {
        anguloVuelco += 6 + tDerrota * 0.7;
        setRotado(Sprites.autoRoto(tipo.cuerpo, tipo.detalle, tipo.modelo), anguloVuelco);
        if (tDerrota % 2 == 0)
            w.addObject(new Humo(x + Greenfoot.getRandomNumber(200) - 100, 12, z, 0.6), -500, -500);
        if (tDerrota > 70) {
            int fuera = (xOrilla >= 0) ? 1 : -1;
            x += fuera * 24;
            altura += 6;
            if (tDerrota > 84) alphaDerrota = Math.max(0, alphaDerrota - 8);
        }
        if (tDerrota == 70) Sonido.efecto("choque.wav");
    }

    // PATRULLA X: dos coches de la Organizacion la encierran y la mandan a girar
    private void firmaPatrulla(RaceWorld w)
    {
        orillarse(5.0);
        if (tDerrota == 10) {
            w.addObject(new MafiaVehiculo(MafiaVehiculo.TRUCK, x - 400, 0), -500, -500);
            w.addObject(new MafiaVehiculo(MafiaVehiculo.TRUCK, x + 400, 0), -500, -500);
            w.addObject(new PopText("LA ENCERRARON", new Color(255, 120, 120), 24), GameData.ANCHO / 2, 290);
        }
        if (tDerrota >= 30 && tDerrota < 70) {
            anguloVuelco += 12;
            setRotado(Sprites.autoRoto(tipo.cuerpo, tipo.detalle, tipo.modelo), anguloVuelco);
        }
        if (tDerrota == 30) { Camara.sacudir(20); Sonido.efecto("choque.wav"); }
        humo(w, 9, 300);
        if (!bajaron && tDerrota > 100) { bajaron = true; bajarTripulacion(w, Ocupante.LLORA, Ocupante.ESCOLTA, x); }
    }

    // SLIDE-X: derrapa demasiado ancho y se come un muro
    private void firmaSlide(RaceWorld w)
    {
        int fuera = (xOrilla >= 0) ? 1 : -1;
        if (tDerrota < 26) {
            x += fuera * 26;
            if (tDerrota % 2 == 0) w.addObject(new Humo(x, 12, z, 0.6), -500, -500);
        }
        if (tDerrota == 26) {
            w.addObject(new Escombro(Sprites.muro(), xOrilla + fuera * 260, z, 900, 620), -500, -500);
            for (int i = 0; i < 8; i++)
                w.addObject(new Explosion(x + Greenfoot.getRandomNumber(300) - 150, 120, z, 180), -500, -500);
            setBase(aplastado());
            Camara.sacudir(28);
            Sonido.efecto("choque.wav");
        }
        if (tDerrota > 26) humo(w, 7, 300);
        if (!bajaron && tDerrota > 80) { bajaron = true; bajarTripulacion(w, Ocupante.LLORA, Ocupante.ALEJARSE, 0); }
    }

    // HYPER S9: rompe la barrera del sonido y desaparece
    private void firmaHyper(RaceWorld w)
    {
        if (tDerrota == 6) {
            w.addObject(new PopText("BARRERA DEL SONIDO", new Color(255, 255, 255), 24), GameData.ANCHO / 2, 290);
            Camara.golpeFocal(-70);
        }
        if (tDerrota > 6 && tDerrota < 40) {
            x += (0 - x) * 0.1;
            for (int i = 0; i < 3; i++)
                w.addObject(new Humo(x + Greenfoot.getRandomNumber(200) - 100, 60, z, 0.5), -500, -500);
        }
        if (tDerrota == 40) {
            w.addObject(new Explosion(x, 200, z, 2400), -500, -500);   // el "boom"
            Camara.sacudir(30);
            Sonido.efecto("explosion.wav");
            alphaDerrota = 0;                                          // ya no esta
        }
    }

    // PROTOTIPO Z: falla la antigravedad, cae de golpe y se deshace en luz
    private void firmaProto(RaceWorld w)
    {
        if (tDerrota == 8) w.addObject(new PopText("FALLA ANTIGRAVEDAD", new Color(0, 255, 200), 24),
                                       GameData.ANCHO / 2, 290);
        if (tDerrota > 12 && tDerrota < 26) altura -= (tDerrota - 12) * 6;   // se cae
        if (tDerrota == 26) { Camara.sacudir(24); w.addObject(new Explosion(x, 60, z, 900), -500, -500); }
        if (tDerrota > 30) {
            alphaDerrota = Math.max(0, alphaDerrota - 5);
            if (tDerrota % 2 == 0)
                w.addObject(new Humo(x + Greenfoot.getRandomNumber(240) - 120, 30 + Greenfoot.getRandomNumber(120),
                                     z, 0.35), -500, -500);
        }
    }

    // ==================================================================
    // PLANTILLAS DEL CATALOGO DE 130 MUERTES (Muerte.T_*)
    // Leen muerteActual.prop / p1 / mafia / nombre.
    // ==================================================================
    private void mOrilla(RaceWorld w)
    {
        boolean parado = w.getVelocidad() <= 0.5;
        boolean llego = orillarse(7.0);
        humo(w, parado ? 12 : 6, 240);
        if (!bajaron && parado && llego && tDerrota > 40) {
            bajaron = true;
            int cond = (muerteActual.tmpl == Muerte.T_LLORA) ? Ocupante.LLORA : Ocupante.ALEJARSE;
            bajarTripulacion(w, cond, Ocupante.ALEJARSE, 0);
            if (muerteActual.p1 == 2) w.addObject(new Explosion(x, 140, z, 460), -500, -500);
        }
    }

    private void mAbandono(RaceWorld w)
    {
        boolean parado = w.getVelocidad() <= 0.5;
        orillarse(6.0);
        if (!bajaron && parado && tDerrota > 30) {
            bajaron = true;
            bajarTripulacion(w, Ocupante.ALEJARSE, Ocupante.ALEJARSE, 0);
            w.addObject(new PopText(muerteActual.nombre, new Color(200, 200, 205), 20), GameData.ANCHO / 2, 300);
        }
        if (bajaron && tDerrota > 90) {
            int f = (xOrilla >= 0) ? 1 : -1;
            x += f * 3; altura -= 1.4;
            if (tDerrota % 14 == 0) w.addObject(new Humo(x, 20, z, 0.5), -500, -500);
        }
    }

    private void mProp(RaceWorld w)
    {
        int fuera = (xOrilla >= 0) ? 1 : -1;
        if (tDerrota == 1) {
            xObstaculo = xOrilla + fuera * 360;
            w.addObject(new Escombro(Sprites.propLado(muerteActual.prop), xObstaculo, z, 260, 620), -500, -500);
        }
        if (Math.abs(xObstaculo - x) > 14) x += (xObstaculo > x) ? 14 : -14;
        else if (!bajaron) {
            bajaron = true;
            x = xObstaculo - fuera * 60;
            w.addObject(new PopText(muerteActual.nombre, new Color(255, 120, 90), 26), GameData.ANCHO / 2, 300);
            w.addObject(new Explosion(x, 130, z + 30, 420), -500, -500);
            Camara.sacudir(18); Sonido.efecto("choque.wav");
            if (muerteActual.mafia) w.addObject(new MafiaVehiculo(MafiaVehiculo.TRUCK, x, 0), -500, -500);
        }
        humo(w, 6, 300);
        if (bajaron && tDerrota == 90) bajarTripulacion(w, Ocupante.LLORA, Ocupante.ALEJARSE, 0);
    }

    private void mVuelco(RaceWorld w)
    {
        int giros = Math.max(1, muerteActual.p1);
        int dur = 12 + giros * 10;
        if (tDerrota < dur) {
            anguloVuelco += 360.0 / dur;
            x += (xOrilla > x) ? 6 : -6;
            if (muerteActual.prop == 1) altura += Math.sin(tDerrota * 0.4) * 4;
            setRotado(Sprites.autoTrasero(tipo.cuerpo, tipo.detalle, tipo.modelo), anguloVuelco);
        } else if (tDerrota == dur) {
            setRotado(Sprites.autoRoto(tipo.cuerpo, tipo.detalle, tipo.modelo), 180);
            w.addObject(new Explosion(x, 140, z + 30, 560), -500, -500);
            Camara.sacudir(24);
        }
        humo(w, 10, 300);
        if (!bajaron && tDerrota > dur + 60) { bajaron = true; bajarTripulacion(w, Ocupante.CRAWL, Ocupante.CRAWL, 0); }
    }

    private void mGira(RaceWorld w)
    {
        anguloVuelco += 6 + tDerrota * (muerteActual.p1 == 1 ? 0.9 : 0.5);
        setRotado(Sprites.autoRoto(tipo.cuerpo, tipo.detalle, tipo.modelo), anguloVuelco);
        if (tDerrota % 2 == 0) w.addObject(new Humo(x + Greenfoot.getRandomNumber(200) - 100, 12, z, 0.6), -500, -500);
        if (tDerrota > 70) {
            int f = (xOrilla >= 0) ? 1 : -1;
            x += f * 22; altura += 5;
            if (tDerrota > 84) alphaDerrota = Math.max(0, alphaDerrota - 8);
        }
        if (tDerrota == 70) Sonido.efecto("choque.wav");
    }

    private void mIncendio(RaceWorld w)
    {
        orillarse(6.0);
        humo(w, 3, 400);
        if (tDerrota % 16 == 0 && tDerrota < 200)
            w.addObject(new Explosion(x + Greenfoot.getRandomNumber(120) - 60, 150, z + 20, 320), -500, -500);
        if (!bajaron && tDerrota > 26) { bajaron = true; bajarTripulacion(w, Ocupante.ALEJARSE, Ocupante.ALEJARSE, 0); }
        if (tDerrota == 150) {
            w.addObject(new Explosion(x, 150, z, 1100), -500, -500);
            Camara.sacudir(30); Sonido.efecto("explosion.wav");
        }
    }

    private void mDetona(RaceWorld w)
    {
        int n = Math.max(4, muerteActual.p1);
        if (tDerrota == 4) {
            Sonido.efecto("explosion.wav"); Camara.sacudir(34); Camara.golpeFocal(50);
            for (int i = 0; i < n; i++)
                w.addObject(new Explosion(x + Greenfoot.getRandomNumber(500) - 250,
                                          100 + Greenfoot.getRandomNumber(300),
                                          z + Greenfoot.getRandomNumber(400) - 200, 900), -500, -500);
            setBase(aplastado());
            alphaDerrota = 160;
        }
        if (tDerrota > 4 && tDerrota % 10 == 0 && tDerrota < 130) {
            w.addObject(new Explosion(x + Greenfoot.getRandomNumber(300) - 150, 120, z, 500), -500, -500);
            if (alphaDerrota > 30) alphaDerrota -= 18;
        }
        humo(w, 5, 240);
        if (!bajaron && tDerrota > 70) { bajaron = true; bajarTripulacion(w, Ocupante.CRAWL, Ocupante.ALEJARSE, 0); }
    }

    private void mCaida(RaceWorld w)
    {
        int fuera = (xOrilla >= 0) ? 1 : -1;
        if (tDerrota < 40) x += fuera * 22;
        else {
            x += fuera * 8; altura -= (tDerrota - 40) * 3; anguloVuelco += 6;
            setRotado(Sprites.autoRoto(tipo.cuerpo, tipo.detalle, tipo.modelo), anguloVuelco);
        }
        if (!bajaron && tDerrota == 30) { bajaron = true; bajarTripulacion(w, Ocupante.ALEJARSE, Ocupante.ALEJARSE, 0); }
        if (tDerrota == 40) { Sonido.efecto("choque.wav"); Camara.sacudir(14); }
        if (tDerrota == 120) {
            for (int i = 0; i < 4; i++)
                w.addObject(new Humo(xOrilla + fuera * 400 + Greenfoot.getRandomNumber(300), -200, z + 200, 1.6), -500, -500);
            w.addObject(new Explosion(xOrilla + fuera * 500, -100, z + 200, 900), -500, -500);
            Camara.sacudir(20); Sonido.efecto("explosion.wav");
        }
    }

    private void mDesintegra(RaceWorld w)
    {
        orillarse(5.0);
        if (tDerrota == 24) { bajarTripulacion(w, Ocupante.ALEJARSE, Ocupante.ALEJARSE, 0); bajaron = true; }
        if (tDerrota > 30) {
            alphaDerrota = Math.max(0, alphaDerrota - 4);
            if (tDerrota % 2 == 0)
                w.addObject(new Humo(x + Greenfoot.getRandomNumber(300) - 150,
                                     30 + Greenfoot.getRandomNumber(160), z, 0.4), -500, -500);
        }
    }

    private void mHunde(RaceWorld w)
    {
        orillarse(4.0);
        if (tDerrota == 30) {
            bajarTripulacion(w, Ocupante.ALEJARSE, Ocupante.ALEJARSE, 0); bajaron = true;
            w.addObject(new PopText(muerteActual.nombre, new Color(200, 160, 120), 22), GameData.ANCHO / 2, 300);
        }
        if (tDerrota > 30) {
            altura -= 2.2;
            if (tDerrota % 9 == 0) w.addObject(new Explosion(x + Greenfoot.getRandomNumber(160) - 80, 40, z, 120), -500, -500);
        }
        if (altura < -260 && alphaDerrota > 0) alphaDerrota -= 8;
    }

    private void mPortal(RaceWorld w)
    {
        if (tDerrota < 32) orillarse(4.0);
        if (tDerrota == 20) {
            w.addObject(new Escombro(Sprites.portal(), x, z + 120, 1700, 1700), -500, -500);
            w.addObject(new PopText(muerteActual.nombre, new Color(180, 120, 255), 22), GameData.ANCHO / 2, 280);
            bajarTripulacion(w, Ocupante.ALEJARSE, Ocupante.ALEJARSE, 0); bajaron = true;
        }
        if (tDerrota == 34) { Camara.golpeFocal(-38); Sonido.efecto("turbo.wav"); }
        if (tDerrota > 34) {
            // el auto se LEVANTA girando y es succionado hacia el portal
            int k = tDerrota - 34;
            anguloVuelco += 14 + k * 1.4;
            altura += Math.min(9, 2 + k * 0.35);       // se eleva
            x += (0 - x) * 0.10;                        // se centra sobre el portal
            z += 3;                                     // se acerca al portal
            double escala = Math.max(0.12, 1.0 - k / 52.0);
            setRotado(Sprites.autoRoto(tipo.cuerpo, tipo.detalle, tipo.modelo), anguloVuelco, escala);
            if (k > 20) alphaDerrota = Math.max(0, alphaDerrota - 10);
            if (tDerrota % 3 == 0)
                w.addObject(new Humo(x + Greenfoot.getRandomNumber(140) - 70, altura, z, 0.4), -500, -500);
        }
    }

    private void mCae(RaceWorld w)
    {
        orillarse(5.0);
        humo(w, 14, 55);
        if (tDerrota == 18) {
            w.addObject(new CosaCae(Sprites.objetoCae(muerteActual.prop), x, z, 520, 520, 1700), -500, -500);
            w.addObject(new PopText("...algo cae del cielo", new Color(255, 180, 120), 22), GameData.ANCHO / 2, 250);
        }
        if (tDerrota == 58) { setBase(aplastado()); Camara.golpeFocal(40); }
        if (tDerrota > 62) humo(w, 6, 220);
        if (!bajaron && tDerrota > 92) { bajaron = true; bajarTripulacion(w, Ocupante.CRAWL, Ocupante.CRAWL, 0); }
    }

    private void mAplasta(RaceWorld w)
    {
        // PISADO: un pie gigante BAJA, aplasta el auto y se vuelve a levantar
        if (muerteActual.prop == 2) {
            orillarse(4.0);
            if (tDerrota == 6) {
                w.addObject(new CosaBaja(Sprites.aplastador(2), x, 2000, 1300, 30, 22, true), -500, -500);
                w.addObject(new PopText(muerteActual.nombre, new Color(255, 150, 90), 24), GameData.ANCHO / 2, 275);
            }
            if (tDerrota == 80) {                        // el pie toca el piso: crujido
                setBase(aplastado());
                Camara.sacudir(44); Camara.golpeFocal(40); Sonido.efecto("choque.wav");
                for (int i = 0; i < 12; i++)
                    w.addObject(new Humo(x + Greenfoot.getRandomNumber(440) - 220, 6, z, 1.2), -500, -500);
            }
            if (tDerrota > 84) humo(w, 9, 240);
            if (!bajaron && tDerrota > 124) { bajaron = true; bajarTripulacion(w, Ocupante.CRAWL, Ocupante.CRAWL, 0); }
            return;
        }

        orillarse(5.0);
        if (tDerrota == 10)
            w.addObject(new CosaCae(Sprites.aplastador(muerteActual.prop), x, z, 1400, 900, 2400), -500, -500);
        if (tDerrota == 46) { setBase(aplastado()); Camara.sacudir(34); Sonido.efecto("choque.wav"); }
        if (tDerrota > 46) humo(w, 8, 220);
        if (!bajaron && tDerrota > 100) { bajaron = true; bajarTripulacion(w, Ocupante.CRAWL, Ocupante.CRAWL, 0); }
    }

    private void mCriatura(RaceWorld w)
    {
        int fuera = (xOrilla >= 0) ? -1 : 1;
        orillarse(4.0);
        if (tDerrota == 10)
            w.addObject(new Escombro(Sprites.criatura(muerteActual.prop), x + fuera * 900, z + 300, 1900, 2200), -500, -500);
        if (tDerrota == 46) {
            Camara.sacudir(34); Sonido.efecto("choque.wav");
            w.addObject(new Explosion(x, 150, z, 1400), -500, -500);
            setBase(aplastado());
        }
        if (tDerrota > 46) humo(w, 8, 220);
        if (!bajaron && tDerrota > 100) { bajaron = true; bajarTripulacion(w, Ocupante.CRAWL, Ocupante.CRAWL, 0); }
    }

    private void mMaquina(RaceWorld w)
    {
        orillarse(4.0);
        if (tDerrota == 8)
            w.addObject(new CosaBaja(Sprites.maquinaBaja(muerteActual.prop), x, 1400, 700, 380, 40, true), -500, -500);
        humo(w, 12, 60);
        if (tDerrota > 90) {
            altura += 42; x += (0 - x) * 0.03;
            if (tDerrota % 3 == 0)
                w.addObject(new Explosion(x + Greenfoot.getRandomNumber(200) - 100, altura - 100, z, 220), -500, -500);
            if (tDerrota > 96 && alphaDerrota > 0) alphaDerrota -= 5;
        }
        if (!bajaron && tDerrota == 45) {
            bajaron = true;
            w.addObject(new PopText(muerteActual.nombre, new Color(150, 255, 200), 24), GameData.ANCHO / 2, 320);
            bajarTripulacion(w, Ocupante.ALEJARSE, Ocupante.ALEJARSE, 0);
        }
    }

    private void mRayo(RaceWorld w)
    {
        orillarse(6.0);
        Color[] cols = { new Color(255, 255, 255), new Color(120, 255, 180),
                         new Color(180, 120, 255), new Color(255, 90, 90) };
        if (tDerrota == 24) {
            Camara.sacudir(26); Sonido.efecto("explosion.wav");
            setBase(Sprites.autoRoto(new Color(28, 26, 26), new Color(20, 20, 20), tipo.modelo));
            for (int i = 0; i < 6; i++)
                w.addObject(new Explosion(x + Greenfoot.getRandomNumber(200) - 100, 200,
                                          z + Greenfoot.getRandomNumber(200) - 100, 200), -500, -500);
            w.addObject(new PopText(muerteActual.nombre, cols[muerteActual.prop % cols.length], 26),
                        GameData.ANCHO / 2, 260);
        }
        if (tDerrota > 24 && tDerrota % 8 == 0 && tDerrota < 150)
            w.addObject(new Explosion(x + Greenfoot.getRandomNumber(160) - 80, 120, z, 120), -500, -500);
        humo(w, 7, 260);
        if (!bajaron && tDerrota > 70) { bajaron = true; bajarTripulacion(w, Ocupante.ALEJARSE, Ocupante.ALEJARSE, 0); }
    }

    private void mMotor(RaceWorld w)
    {
        orillarse(6.0);
        if (tDerrota == 14) {
            w.addObject(new PopText("SE SALIO EL MOTOR", new Color(255, 170, 90), 24), GameData.ANCHO / 2, 290);
            w.addObject(new Escombro(Sprites.bloqueMotor(), x, z + 2600, 320, 260), -500, -500);
            w.addObject(new Explosion(x, 150, z + 40, 700), -500, -500);
            Camara.sacudir(16);
        }
        humo(w, 5, 300);
        if (!bajaron && tDerrota > 60) { bajaron = true; bajarTripulacion(w, Ocupante.LLORA, Ocupante.ALEJARSE, 0); }
    }

    private void mMafiaBox(RaceWorld w)
    {
        orillarse(5.0);
        if (tDerrota == 10) {
            w.addObject(new MafiaVehiculo(MafiaVehiculo.TRUCK, x - 400, 0), -500, -500);
            w.addObject(new MafiaVehiculo(MafiaVehiculo.TRUCK, x + 400, 0), -500, -500);
            w.addObject(new PopText(muerteActual.nombre, new Color(255, 120, 120), 24), GameData.ANCHO / 2, 290);
        }
        if (tDerrota >= 30 && tDerrota < 70) {
            anguloVuelco += 12;
            setRotado(Sprites.autoRoto(tipo.cuerpo, tipo.detalle, tipo.modelo), anguloVuelco);
        }
        if (tDerrota == 30) { Camara.sacudir(20); Sonido.efecto("choque.wav"); }
        humo(w, 9, 300);
        if (!bajaron && tDerrota > 100) { bajaron = true; bajarTripulacion(w, Ocupante.LLORA, Ocupante.ESCOLTA, x); }
    }

    private void mMafiaKidnap(RaceWorld w)
    {
        boolean parado = w.getVelocidad() <= 0.5;
        boolean llego = orillarse(7.0);
        humo(w, parado ? 12 : 6, 240);
        if (!bajaron && parado && llego && tDerrota > 40) {
            bajaron = true;
            int fuera = (xOrilla >= 0) ? 1 : -1;
            double xVan = xOrilla + fuera * 190;
            w.addObject(new MafiaVehiculo(MafiaVehiculo.VAN, xVan, Camara.Z_JUGADOR + 40), -500, -500);
            bajarTripulacion(w, Ocupante.LLORA, Ocupante.ESCOLTA, xVan);
        }
    }

    private void mMafiaDriveby(RaceWorld w)
    {
        orillarse(4.5);
        humo(w, 6, 300);
        if (tDerrota == 12) {
            w.addObject(new MafiaVehiculo(MafiaVehiculo.TRUCK, x, 0), -500, -500);
            w.addObject(new PopText(muerteActual.nombre, new Color(255, 90, 80), 26), GameData.ANCHO / 2, 290);
            Sonido.efecto("disparo.wav");
        }
        if (tDerrota % 10 == 0 && tDerrota > 12 && tDerrota < 120)
            w.addObject(new Explosion(x + Greenfoot.getRandomNumber(200) - 100, 130, z, 260), -500, -500);
        if (tDerrota == 40) setBase(aplastado());
        if (!bajaron && tDerrota == 150) { bajaron = true; bajarTripulacion(w, Ocupante.LLORA, Ocupante.ALEJARSE, 0); }
    }

    private void mClima(RaceWorld w)
    {
        int fx = (xOrilla >= 0) ? 1 : -1;
        if (muerteActual.prop == 0) {                // tornado
            anguloVuelco += 14; x += fx * 10;
            if (tDerrota > 40) altura += 20;
            double esc = tDerrota > 60 ? Math.max(0.25, 1.0 - (tDerrota - 60) / 60.0) : 1.0;
            setRotado(Sprites.autoRoto(tipo.cuerpo, tipo.detalle, tipo.modelo), anguloVuelco, esc);
            if (tDerrota > 70 && alphaDerrota > 0) alphaDerrota -= 5;
            if (tDerrota % 2 == 0)
                w.addObject(new Humo(x + Greenfoot.getRandomNumber(300) - 150, Greenfoot.getRandomNumber(300), z, 0.8), -500, -500);
        } else {                                     // ola / arena / granizo / alud / ventisca
            x += fx * (muerteActual.prop == 1 ? 22 : 4);
            if (tDerrota > 30) altura -= 1.6;
            if (tDerrota % 3 == 0)
                w.addObject(new Humo(x + Greenfoot.getRandomNumber(400) - 200, Greenfoot.getRandomNumber(200), z, 1.2), -500, -500);
            if (altura < -240 && alphaDerrota > 0) alphaDerrota -= 7;
        }
        if (tDerrota == 8) w.addObject(new PopText(muerteActual.nombre, new Color(220, 230, 255), 22), GameData.ANCHO / 2, 280);
        if (!bajaron && tDerrota == 20) { bajaron = true; bajarTripulacion(w, Ocupante.CRAWL, Ocupante.CRAWL, 0); }
    }

    private void mChiste(RaceWorld w)
    {
        orillarse(6.0);
        humo(w, 8, 220);
        if (tDerrota == 6) w.addObject(new PopText(muerteActual.nombre, new Color(255, 230, 150), 20), GameData.ANCHO / 2, 280);
        if (muerteActual.prop == 2 && tDerrota == 12) {   // se cruza un animal
            w.addObject(new Escombro(Sprites.criatura(6), x, z + 400, 900, 700), -500, -500);
            w.addObject(new Explosion(x, 120, z + 60, 400), -500, -500);
            Camara.sacudir(16);
        }
        if (muerteActual.prop == 3) {                     // se cae a un lago
            if (tDerrota > 20) altura -= 3;
            if (tDerrota % 3 == 0) w.addObject(new Humo(x + Greenfoot.getRandomNumber(240) - 120, 10, z, 0.7), -500, -500);
            if (altura < -220 && alphaDerrota > 0) alphaDerrota -= 6;
        }
        if (!bajaron && tDerrota > 40) { bajaron = true; bajarTripulacion(w, Ocupante.ALEJARSE, Ocupante.ALEJARSE, 0); }
    }

    /** true cuando el auto ya llego a la orilla. */
    private boolean orillarse(double vel)
    {
        if (Math.abs(xOrilla - x) > vel) { x += (xOrilla > x) ? vel : -vel; return false; }
        x = xOrilla;
        return true;
    }

    private void humo(RaceWorld w, int cada, int hasta)
    {
        if (tDerrota % cada == 0 && tDerrota < hasta)
            w.addObject(new Humo(x + Greenfoot.getRandomNumber(70) - 35, 90, z + 30), -500, -500);
    }

    private void bajarTripulacion(RaceWorld w, int modoConductor, int modoCopiloto, double metaCopiloto)
    {
        int fuera = (xOrilla >= 0) ? 1 : -1;
        Ocupante cond = new Ocupante(x - fuera * 250, z + 20, fuera, tipo.pelo1, tipo.melena1, modoConductor);
        Ocupante copi = new Ocupante(x + fuera * 90, z - 40, fuera, tipo.pelo2, tipo.melena2, modoCopiloto);
        if (modoCopiloto == Ocupante.ESCOLTA) copi.conMeta(metaCopiloto);
        w.addObject(cond, -500, -500);
        w.addObject(copi, -500, -500);
    }

    // ---- VAN: se orilla, bajan, la miniban se lleva a la copiloto ----
    private void derrotaVan(RaceWorld w)
    {
        boolean parado = w.getVelocidad() <= 0.5;
        boolean llego = orillarse(7.0);
        humo(w, parado ? 12 : 6, 240);

        if (!bajaron && parado && llego && tDerrota > 40) {
            bajaron = true;
            int fuera = (xOrilla >= 0) ? 1 : -1;
            double xVan = xOrilla + fuera * 190;      // parada por fuera del asfalto
            van = new MafiaVehiculo(MafiaVehiculo.VAN, xVan, Camara.Z_JUGADOR + 40);
            w.addObject(van, -500, -500);
            bajarTripulacion(w, Ocupante.LLORA, Ocupante.ESCOLTA, xVan);
        }
    }

    // ---- ARBOL: se descarrila hacia un arbol o farola del costado ----
    private double xObstaculo = 0;

    private void derrotaArbol(RaceWorld w)
    {
        int fuera = (xOrilla >= 0) ? 1 : -1;

        if (tDerrota == 1) {
            xObstaculo = xOrilla + fuera * 360;      // bien al costado, fuera del asfalto
            GreenfootImage sp = (Greenfoot.getRandomNumber(2) == 0)
                              ? Sprites.arbolChoque() : Sprites.farola();
            w.addObject(new Escombro(sp, xObstaculo, z, 300, 620), -500, -500);
        }

        // el auto derrapa hacia el obstaculo
        if (Math.abs(xObstaculo - x) > 14) {
            x += (xObstaculo > x) ? 14 : -14;
        } else if (!bajaron) {
            bajaron = true;
            x = xObstaculo - fuera * 60;              // clavado justo antes del obstaculo
            w.addObject(new PopText("SE DESCARRILO", new Color(255, 120, 90), 26), GameData.ANCHO / 2, 300);
            w.addObject(new Explosion(x, 130, z + 30, 420), -500, -500);
            Camara.sacudir(18);
            Sonido.efecto("choque.wav");
            // a veces pasa una camioneta de la mafia disparando, a veces no
            if (Greenfoot.getRandomNumber(2) == 0)
                w.addObject(new MafiaVehiculo(MafiaVehiculo.TRUCK, x, 0), -500, -500);
        }

        humo(w, 6, 300);
        if (bajaron && tDerrota == 90)
            bajarTripulacion(w, Ocupante.LLORA, Ocupante.ALEJARSE, 0);
    }

    // ---- VUELCO: el auto da una vuelta de campana ----
    private void derrotaVuelco(RaceWorld w)
    {
        if (tDerrota < 22) {
            anguloVuelco += 34;
            x += (xOrilla > x) ? 6 : -6;
            GreenfootImage img = new GreenfootImage(Sprites.autoTrasero(tipo.cuerpo, tipo.detalle, tipo.modelo));
            img.rotate((int) anguloVuelco);
            setBase(img);
        } else if (tDerrota == 22) {
            GreenfootImage img = new GreenfootImage(Sprites.autoRoto(tipo.cuerpo, tipo.detalle, tipo.modelo));
            img.rotate(180);
            setBase(img);
            w.addObject(new Explosion(x, 140, z + 30, 560), -500, -500);
            Camara.sacudir(24);
        }
        humo(w, 10, 300);
        if (!bajaron && tDerrota > 90) {
            bajaron = true;
            bajarTripulacion(w, Ocupante.CRAWL, Ocupante.CRAWL, 0);
        }
    }

    // ---- FUEGO: el motor se incendia y saltan del auto ----
    private void derrotaFuego(RaceWorld w)
    {
        boolean parado = w.getVelocidad() <= 0.5;
        orillarse(6.0);
        humo(w, parado ? 4 : 3, 400);

        if (tDerrota % 16 == 0 && tDerrota < 200)
            w.addObject(new Explosion(x + Greenfoot.getRandomNumber(120) - 60, 150, z + 20, 320), -500, -500);

        if (!bajaron && tDerrota > 26) {
            bajaron = true;
            bajarTripulacion(w, Ocupante.ALEJARSE, Ocupante.ALEJARSE, 0);
        }
        if (tDerrota == 150) {
            w.addObject(new Explosion(x, 150, z, 1100), -500, -500);
            Camara.sacudir(30);
            Sonido.efecto("explosion.wav");
        }
    }

    // ---- OVNI (tipo 0 platillo) / GARRA (tipo 1 helicoptero): se llevan el auto ----
    private void derrotaOvni(RaceWorld w, int tipoNave)
    {
        orillarse(4.0);
        if (tDerrota == 8) w.addObject(new Ovni(tipoNave, x), -500, -500);
        humo(w, 12, 90);

        if (tDerrota > 90) {
            altura += 42;                       // el auto sube enganchado
            x += (0 - x) * 0.03;
            if (tDerrota % 3 == 0)
                w.addObject(new Explosion(x + Greenfoot.getRandomNumber(200) - 100, altura - 100,
                                          z, 220), -500, -500);
            if (tDerrota > 96 && alphaDerrota > 0) alphaDerrota -= 5;
        }
        if (!bajaron && tDerrota == 45) {
            bajaron = true;
            Camara.sacudir(10);
            w.addObject(new PopText(tipoNave == 0 ? "ABDUCIDOS" : "LOS ENGANCHARON",
                                    new Color(150, 255, 200), 26), GameData.ANCHO / 2, 320);
            bajarTripulacion(w, Ocupante.ALEJARSE, Ocupante.ALEJARSE, 0);   // salen corriendo
        }
    }

    // ---- BARRANCO: el auto se sale de la ruta y cae al vacio ----
    private void derrotaBarranco(RaceWorld w)
    {
        int fuera = (xOrilla >= 0) ? 1 : -1;
        if (tDerrota < 40) {
            x += fuera * 22;                    // se sale de la ruta
        } else {
            x += fuera * 8;
            altura -= (tDerrota - 40) * 3;      // cae
            anguloVuelco += 6;
            GreenfootImage img = new GreenfootImage(Sprites.autoRoto(tipo.cuerpo, tipo.detalle, tipo.modelo));
            img.rotate((int) anguloVuelco);
            setBase(img);
        }
        if (!bajaron && tDerrota == 30) {       // saltan antes de que caiga
            bajaron = true;
            bajarTripulacion(w, Ocupante.ALEJARSE, Ocupante.ALEJARSE, 0);
        }
        if (tDerrota == 40) { Sonido.efecto("choque.wav"); Camara.sacudir(14); }
        if (tDerrota == 120) {                  // el estruendo de abajo
            for (int i = 0; i < 4; i++)
                w.addObject(new Humo(xOrilla + fuera * 400 + Greenfoot.getRandomNumber(300),
                                     -200, z + 200, 1.6), -500, -500);
            w.addObject(new Explosion(xOrilla + fuera * 500, -100, z + 200, 900), -500, -500);
            Camara.sacudir(20);
            Sonido.efecto("explosion.wav");
        }
    }

    // ---- METEORITO: cae una roca del cielo y borra el auto ----
    private void derrotaMeteorito(RaceWorld w)
    {
        orillarse(5.0);
        humo(w, 14, 60);
        if (tDerrota == 20) {
            w.addObject(new Cae(x, z), -500, -500);
            w.addObject(new PopText("...algo cae del cielo", new Color(255, 180, 120), 22),
                        GameData.ANCHO / 2, 260);
        }
        if (tDerrota == 60) {                   // impacto (Cae ya reventó todo)
            setBase(aplastado());
            Camara.golpeFocal(40);
        }
        if (tDerrota > 64) humo(w, 6, 220);
        if (!bajaron && tDerrota > 90) {        // salen a gatas del crater
            bajaron = true;
            bajarTripulacion(w, Ocupante.CRAWL, Ocupante.CRAWL, 0);
        }
    }

    // ---- RAYO: te parte un rayo, el auto queda carbonizado ----
    private void derrotaRayo(RaceWorld w)
    {
        orillarse(6.0);
        if (tDerrota == 30) {
            Camara.sacudir(26);
            Sonido.efecto("explosion.wav");
            GreenfootImage img = Sprites.autoRoto(new Color(28, 26, 26), new Color(20, 20, 20), tipo.modelo);
            setBase(img);
            for (int i = 0; i < 6; i++)
                w.addObject(new Explosion(x + Greenfoot.getRandomNumber(200) - 100, 200,
                                          z + Greenfoot.getRandomNumber(200) - 100, 200), -500, -500);
        }
        if (tDerrota > 30 && tDerrota % 8 == 0 && tDerrota < 160)
            w.addObject(new Explosion(x + Greenfoot.getRandomNumber(160) - 80, 120, z, 120), -500, -500);
        humo(w, 7, 260);
        if (!bajaron && tDerrota > 70) {
            bajaron = true;
            bajarTripulacion(w, Ocupante.ALEJARSE, Ocupante.ALEJARSE, 0);
        }
    }

    // ---- EXPLOTA: el auto detona al instante ----
    private void derrotaExplota(RaceWorld w)
    {
        if (tDerrota == 4) {
            Sonido.efecto("explosion.wav");
            Camara.sacudir(34);
            Camara.golpeFocal(50);
            for (int i = 0; i < 10; i++)
                w.addObject(new Explosion(x + Greenfoot.getRandomNumber(500) - 250, 100 + Greenfoot.getRandomNumber(300),
                                          z + Greenfoot.getRandomNumber(400) - 200, 900), -500, -500);
            setBase(aplastado());
            alphaDerrota = 180;
        }
        if (tDerrota > 4 && tDerrota % 10 == 0 && tDerrota < 120) {
            w.addObject(new Explosion(x + Greenfoot.getRandomNumber(300) - 150, 120, z, 500), -500, -500);
            if (alphaDerrota > 30) alphaDerrota -= 20;
        }
        humo(w, 5, 240);
        if (!bajaron && tDerrota > 60) {        // salen despedidos, aturdidos
            bajaron = true;
            bajarTripulacion(w, Ocupante.CRAWL, Ocupante.ALEJARSE, 0);
        }
    }

    // ---- HUNDE: el asfalto se lo traga ----
    private void derrotaHunde(RaceWorld w)
    {
        orillarse(4.0);
        if (tDerrota > 30) {
            altura -= 2.2;                      // baja lento
            if (tDerrota % 9 == 0)
                w.addObject(new Explosion(x + Greenfoot.getRandomNumber(160) - 80, 40, z, 120), -500, -500);
        }
        if (tDerrota == 30) {
            w.addObject(new PopText("EL ASFALTO CEDE", new Color(200, 160, 120), 24), GameData.ANCHO / 2, 300);
            bajarTripulacion(w, Ocupante.ALEJARSE, Ocupante.ALEJARSE, 0);   // saltan antes de hundirse
            bajaron = true;
        }
        if (altura < -260 && alphaDerrota > 0) alphaDerrota -= 8;
    }

    // ---- POLVO: el auto se desintegra ----
    private void derrotaPolvo(RaceWorld w)
    {
        orillarse(5.0);
        if (tDerrota == 24) {
            w.addObject(new PopText("...", new Color(220, 220, 230), 30), GameData.ANCHO / 2, 300);
            bajarTripulacion(w, Ocupante.ALEJARSE, Ocupante.ALEJARSE, 0);
            bajaron = true;
        }
        if (tDerrota > 30) {
            alphaDerrota = Math.max(0, alphaDerrota - 4);
            if (tDerrota % 2 == 0)
                w.addObject(new Humo(x + Greenfoot.getRandomNumber(300) - 150, 30 + Greenfoot.getRandomNumber(160),
                                     z, 0.4), -500, -500);
        }
    }

    // ---- PORTAL: se abre un portal y el auto entra ----
    private void derrotaPortal(RaceWorld w)
    {
        orillarse(4.0);
        if (tDerrota == 20) {
            w.addObject(new Escombro(Sprites.portal(), x, z + 120, 1500, 1500), -500, -500);
            w.addObject(new PopText("un portal se abre bajo el auto", new Color(180, 120, 255), 22),
                        GameData.ANCHO / 2, 280);
            bajarTripulacion(w, Ocupante.ALEJARSE, Ocupante.ALEJARSE, 0);   // saltan antes
            bajaron = true;
        }
        if (tDerrota > 55) {
            alphaDerrota = Math.max(0, alphaDerrota - 6);   // el auto cae por el portal
            altura -= 3;
            if (tDerrota == 70) { Camara.golpeFocal(-50); Sonido.efecto("turbo.wav"); }
        }
    }

    // ---- BESTIA: una criatura gigante lo pisa ----
    private void derrotaBestia(RaceWorld w)
    {
        int fuera = (xOrilla >= 0) ? -1 : 1;
        orillarse(4.0);
        if (tDerrota == 10)
            w.addObject(new Escombro(Sprites.bestia(), x + fuera * 900, z + 300, 1900, 2200), -500, -500);
        if (tDerrota == 46) {
            Camara.sacudir(34);
            Sonido.efecto("choque.wav");
            w.addObject(new Explosion(x, 150, z, 1400), -500, -500);
            setBase(aplastado());
        }
        if (tDerrota > 46) humo(w, 8, 220);
        if (!bajaron && tDerrota > 100) {
            bajaron = true;
            bajarTripulacion(w, Ocupante.CRAWL, Ocupante.CRAWL, 0);
        }
    }

    // ---- ABANDONO: se bajan tranquilos y el auto rueda a una zanja ----
    private void derrotaAbandono(RaceWorld w)
    {
        boolean parado = w.getVelocidad() <= 0.5;
        orillarse(6.0);
        if (!bajaron && parado && tDerrota > 30) {
            bajaron = true;
            bajarTripulacion(w, Ocupante.ALEJARSE, Ocupante.ALEJARSE, 0);
            w.addObject(new PopText("se bajan y se van...", new Color(200, 200, 205), 20),
                        GameData.ANCHO / 2, 300);
        }
        if (bajaron && tDerrota > 90) {
            int fuera = (xOrilla >= 0) ? 1 : -1;
            x += fuera * 3;
            altura -= 1.4;                      // el auto solo rueda a la zanja
            if (tDerrota % 14 == 0) w.addObject(new Humo(x, 20, z, 0.5), -500, -500);
        }
    }

    /** autoRoto aplastado (mitad de alto). */
    private GreenfootImage aplastado()
    {
        GreenfootImage base = Sprites.autoRoto(tipo.cuerpo, tipo.detalle, tipo.modelo);
        GreenfootImage img = new GreenfootImage(base.getWidth(), base.getHeight());
        GreenfootImage chico = new GreenfootImage(base);
        chico.scale(base.getWidth(), base.getHeight() / 2);
        img.drawImage(chico, 0, base.getHeight() / 2);
        return img;
    }

    // ==================================================================
    public void cargarUlti(double c) { ulti = Math.min(100, ulti + c * GameData.modUltiCarga); }

    public double bonusVelocidad()
    {
        double v = 0;
        if (nitroActivo) {
            double base = (tipo.habilidad == CarType.NITRO) ? 130 : 85;
            v += base * GameData.modNitro;
        }
        if (ultiActivo > 0 && ultiEfecto == 1) v += 240;   // SOBRECARGA
        if (ultiActivo > 0 && ultiEfecto == 2) v += 150;   // FASE
        return v;
    }

    public boolean ultiTemporalActiva() { return ultiActivo > 0; }
    public int getUltiEfecto()          { return ultiEfecto; }

    public boolean nitroEncendido()  { return nitroActivo; }
    public int getEnergia()          { return energia; }
    public int getEnergiaMax()       { return energiaMax; }
    public int getUlti()             { return (int) ulti; }
    public int getCarril()           { return carril; }
    public int getBalas()            { return balas; }
    public int getBalasMax()         { return balasMax; }
    public boolean estaRecargando()  { return recargando > 0; }
    public double progresoRecarga()  { return 1.0 - recargando / (double) Math.max(1, recargaEf); }
    public int framesEnMismoCarril() { return framesMismoCarril; }
}
