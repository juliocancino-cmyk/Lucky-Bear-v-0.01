import greenfoot.*;

/**
 * Pantalla de victoria: solo se llega aca completando los 15 niveles.
 * La derrota tiene su propia pantalla (DefeatWorld).
 */
public class ResultWorld extends World
{
    private MenuButton reintentar, alRanking, alMenu;

    public ResultWorld()
    {
        super(GameData.ANCHO, GameData.ALTO, 1);

        Sonido.pararMotor();
        Sonido.musica("musica_menu.wav");
        Sonido.efecto("victoria.wav");

        reintentar = new MenuButton("CORRER OTRA VEZ", "retry", 280, 56);
        alRanking  = new MenuButton("RANKING",    "rank",  230, 56);
        alMenu     = new MenuButton("MENU",       "menu",  230, 56);

        addObject(reintentar, 400, 400);
        addObject(alRanking,  400, 466);
        addObject(alMenu,     400, 532);

        dibujar();
    }

    public void act()
    {
        if (reintentar.fueClickeado()) {
            GameData.nuevaPartida(GameData.modoChallenge);
            Greenfoot.setWorld(new RaceWorld());
        } else if (alRanking.fueClickeado()) {
            Greenfoot.setWorld(new RankingWorld());
        } else if (alMenu.fueClickeado()) {
            Greenfoot.setWorld(new MenuWorld());
        }
    }

    private void dibujar()
    {
        GreenfootImage f = getBackground();
        f.setColor(new Color(20, 22, 34));
        f.fill();

        boolean gano = GameData.completado;

        f.setFont(new Font("Monospaced", true, false, 52));
        f.setColor(gano ? new Color(120, 240, 150) : new Color(240, 110, 110));
        f.drawString(gano ? "CARRERA COMPLETADA" : "FIN DE LA CARRERA", 90, 100);

        int bonus = 0;
        if (gano) {
            int seg = (int) (GameData.tiempoTotalMs / 1000);
            bonus = Math.max(0, (600 - seg) * 20);
        }

        f.setFont(new Font("Monospaced", true, false, 26));
        f.setColor(Color.WHITE);
        f.drawString("AUTO       : " + GameData.auto().nombre, 150, 180);
        f.drawString("NIVEL      : " + Math.min(GameData.nivelActual, GameData.NIVEL_MAX)
                     + " / " + GameData.NIVEL_MAX, 150, 216);
        f.drawString("PUNTAJE    : " + GameData.puntajeCarrera, 150, 252);
        f.drawString("TIEMPO     : " + GameData.formatoTiempo(GameData.tiempoTotalMs), 150, 288);
        f.setColor(new Color(250, 205, 40));
        f.drawString("FINAL      : " + (GameData.puntajeCarrera + bonus)
                     + (gano ? "  (bonus " + bonus + ")" : "  (sin bonus)"), 150, 330);
    }
}
